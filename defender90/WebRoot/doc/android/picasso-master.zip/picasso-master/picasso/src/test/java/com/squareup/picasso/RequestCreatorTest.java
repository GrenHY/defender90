/*
 * Copyright (C) 2013 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package it.sephiroth.android.library.picasso;

import android.R;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.RemoteViews;

import com.squareup.picasso.Cache;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Request;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

import static com.squareup.picasso.Picasso.LoadedFrom.MEMORY;
import static com.squareup.picasso.Picasso.Priority.LOW;
import static com.squareup.picasso.Picasso.Priority.HIGH;
import static com.squareup.picasso.Picasso.Priority.NORMAL;
import static com.squareup.picasso.Picasso.RequestTransformer.IDENTITY;
import static it.sephiroth.android.library.picasso.RemoteViewsAction.AppWidgetAction;
import static it.sephiroth.android.library.picasso.RemoteViewsAction.NotificationAction;
import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class RequestCreatorTest {

  @Mock
  Picasso picasso;
    @Captor
    ArgumentCaptor<Action> actionCaptor;

    @Before
    public void shutUp() throws Exception {
        initMocks(this);
        when(picasso.transformRequest(any(Request.class))).thenAnswer(TestUtils.TRANSFORM_REQUEST_ANSWER);
    }

    @Test
    public void getOnMainCrashes() throws Exception {
        try {
            new RequestCreator(picasso, TestUtils.URI_1, 0).get();
            fail("Calling get() on main thread should throw exception");
        } catch (IllegalStateException expected) {
        }
    }

    @Test
    public void loadWithShutdownCrashes() throws Exception {
        picasso.shutdown = true;
        try {
            new RequestCreator(picasso, TestUtils.URI_1, 0).fetch();
            fail("Should have crashed with a shutdown picasso.");
        } catch (IllegalStateException expected) {
        }
    }

    @Test
    public void getReturnsNullIfNullUriAndResourceId() throws Exception {
        final CountDownLatch latch = new CountDownLatch(1);
        final Bitmap[] result = new Bitmap[1];

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    result[0] = new RequestCreator(picasso, null, 0).get();
                } catch (IOException e) {
                    fail(e.getMessage());
                } finally {
                    latch.countDown();
                }
            }
        }).start();
        latch.await();

        assertThat(result[0]).isNull();
        verifyZeroInteractions(picasso);
    }

    @Test
    public void fetchSubmitsFetchRequest() throws Exception {
        new RequestCreator(picasso, TestUtils.URI_1, 0).fetch();
        verify(picasso).submit(actionCaptor.capture(), eq(0L));
        assertThat(actionCaptor.getValue()).isInstanceOf(FetchAction.class);
    }

    @Test
    public void fetchWithFitThrows() throws Exception {
        try {
            new RequestCreator(picasso, TestUtils.URI_1, 0).fit().fetch();
            fail("Calling fetch() with fit() should throw an exception");
        } catch (IllegalStateException expected) {
        }
    }

    @Test
    public void fetchWithDefaultPriority() throws Exception {
        new RequestCreator(picasso, TestUtils.URI_1, 0).fetch();
        verify(picasso).submit(actionCaptor.capture(), eq(0L));
        assertThat(actionCaptor.getValue().getPriority()).isEqualTo(LOW);
    }

    @Test
    public void fetchWithCustomPriority() throws Exception {
        new RequestCreator(picasso, TestUtils.URI_1, 0).priority(HIGH).fetch();
        verify(picasso).submit(actionCaptor.capture(), eq(0L));
        assertThat(actionCaptor.getValue().getPriority()).isEqualTo(HIGH);
    }

    @Test
    public void intoTargetWithNullThrows() throws Exception {
        try {
            new RequestCreator(picasso, TestUtils.URI_1, 0).into((Target) null);
            fail("Calling into() with null Target should throw exception");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void intoTargetWithFitThrows() throws Exception {
        try {
            Target target = TestUtils.mockTarget();
      new RequestCreator(picasso, TestUtils.URI_1, 0).fit().into(target);
      fail("Calling into() target with fit() should throw exception");
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void intoTargetWithNullUriAndResourceIdSkipsAndCancels() throws Exception {
    Target target = TestUtils.mockTarget();
    Drawable placeHolderDrawable = mock(Drawable.class);
    new RequestCreator(picasso, null, 0).placeholder(placeHolderDrawable).into(target);
    verify(picasso).cancelRequest(target);
    verify(target).onPrepareLoad(placeHolderDrawable);
    verifyNoMoreInteractions(picasso);
  }

  @Test
  public void intoTargetWithQuickMemoryCacheCheckDoesNotSubmit() throws Exception {
    when(picasso.quickMemoryCacheCheck(picasso.getCache(), TestUtils.URI_KEY_1))
        .thenReturn(TestUtils.BITMAP_1);
    Target target = TestUtils.mockTarget();
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(target);
    verify(target).onBitmapLoaded(TestUtils.BITMAP_1, MEMORY);
    verify(picasso).cancelRequest(target);
    verify(picasso, never()).enqueueAndSubmit(any(Action.class), eq(0L));
  }

  @Test
  public void intoTargetAndSkipMemoryCacheDoesNotCheckMemoryCache() throws Exception {
    Target target = TestUtils.mockTarget();
    new RequestCreator(picasso, TestUtils.URI_1, 0).skipMemoryCache().into(target);
    verify(picasso, never()).quickMemoryCacheCheck(picasso.getCache(), TestUtils.URI_KEY_1);
  }

  @Test
  public void intoTargetAndNotInCacheSubmitsTargetRequest() throws Exception {
    Target target = TestUtils.mockTarget();
    Drawable placeHolderDrawable = mock(Drawable.class);
    new RequestCreator(picasso, TestUtils.URI_1, 0).placeholder(placeHolderDrawable).into(target);
    verify(target).onPrepareLoad(placeHolderDrawable);
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(TargetAction.class);
  }

  @Test public void targetActionWithDefaultPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(NORMAL);
  }

  @Test public void targetActionWithCustomPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).priority(HIGH).into(TestUtils.mockTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(HIGH);
  }

  @Test public void targetActionWithDefaultTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo(actionCaptor.getValue());
  }

  @Test public void targetActionWithCustomTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).tag("tag").into(TestUtils.mockTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo("tag");
  }

  @Test
  public void intoImageViewWithNullThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).into((ImageView) null);
      fail("Calling into() with null ImageView should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoImageViewWithNullUriAndResourceIdSkipsAndCancels() throws Exception {
    ImageView target = TestUtils.mockImageViewTarget();
    new RequestCreator(picasso, null, 0).into(target);
    verify(picasso).cancelRequest(target);
    verify(picasso, never()).quickMemoryCacheCheck(picasso.getCache(), anyString());
    verify(picasso, never()).enqueueAndSubmit(any(Action.class), eq(0L));
  }

  @Test
  public void intoImageViewWithQuickMemoryCacheCheckDoesNotSubmit() throws Exception {
    Picasso picasso =
        spy(new Picasso(Robolectric.application, mock(Dispatcher.class), Cache.NONE, null,
            IDENTITY, null, mock(Stats.class), false, false));
    doReturn(TestUtils.BITMAP_1).when(picasso).quickMemoryCacheCheck(picasso.getCache(),
                                                                     TestUtils.URI_KEY_1);
    ImageView target = TestUtils.mockImageViewTarget();
    Callback callback = TestUtils.mockCallback();
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(target, callback);
    verify(target).setImageDrawable(any(PicassoDrawable.class));
    verify(callback).onSuccess();
    verify(picasso).cancelRequest(target);
    verify(picasso, never()).enqueueAndSubmit(any(Action.class), eq(0L));
  }

  @Test
  public void intoImageViewSetsPlaceholderDrawable() throws Exception {
    Picasso picasso =
        spy(new Picasso(Robolectric.application, mock(Dispatcher.class), Cache.NONE, null,
            IDENTITY, null, mock(Stats.class), false, false));
    ImageView target = TestUtils.mockImageViewTarget();
    Drawable placeHolderDrawable = mock(Drawable.class);
    new RequestCreator(picasso, TestUtils.URI_1, 0).placeholder(placeHolderDrawable).into(target);
    verify(target).setImageDrawable(placeHolderDrawable);
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(ImageViewAction.class);
  }

  @Test
  public void intoImageViewSetsPlaceholderWithResourceId() throws Exception {
    Picasso picasso =
        spy(new Picasso(Robolectric.application, mock(Dispatcher.class), Cache.NONE, null,
            IDENTITY, null, mock(Stats.class), false, false));
    ImageView target = TestUtils.mockImageViewTarget();
    new RequestCreator(picasso, TestUtils.URI_1, 0).placeholder(R.drawable.picture_frame).into(target);
    verify(target).setImageResource(R.drawable.picture_frame);
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(ImageViewAction.class);
  }

  @Test
  public void cancelNotOnMainThreadCrashes() throws Exception {
    doCallRealMethod().when(picasso).cancelRequest(any(Target.class));
    final CountDownLatch latch = new CountDownLatch(1);
    new Thread(new Runnable() {
      @Override public void run() {
        try {
          new RequestCreator(picasso, null, 0).into(TestUtils.mockTarget());
          fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ignored) {
        } finally {
          latch.countDown();
        }
      }
    }).start();
    latch.await();
  }

  @Test
  public void intoNotOnMainThreadCrashes() throws Exception {
    doCallRealMethod().when(picasso).enqueueAndSubmit(any(Action.class), eq(0L));
    final CountDownLatch latch = new CountDownLatch(1);
    new Thread(new Runnable() {
      @Override public void run() {
        try {
          new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockImageViewTarget());
          fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ignored) {
        } finally {
          latch.countDown();
        }
      }
    }).start();
    latch.await();
  }

  @Test
  public void intoImageViewAndNotInCacheSubmitsImageViewRequest() throws Exception {
    ImageView target = TestUtils.mockImageViewTarget();
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(target);
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(ImageViewAction.class);
  }

  @Test
  public void intoImageViewWithFitAndNoDimensionsQueuesDeferredImageViewRequest() throws Exception {
    ImageView target = TestUtils.mockFitImageViewTarget(true);
    when(target.getWidth()).thenReturn(0);
    when(target.getHeight()).thenReturn(0);
    new RequestCreator(picasso, TestUtils.URI_1, 0).fit().into(target);
    verify(picasso, never()).enqueueAndSubmit(any(Action.class), eq(0L));
    verify(picasso).defer(eq(target), any(DeferredRequestCreator.class));
  }

  @Test
  public void intoImageViewWithFitAndDimensionsQueuesImageViewRequest() throws Exception {
    ImageView target = TestUtils.mockFitImageViewTarget(true);
    when(target.getWidth()).thenReturn(100);
    when(target.getHeight()).thenReturn(100);
    new RequestCreator(picasso, TestUtils.URI_1, 0).fit().into(target);
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(ImageViewAction.class);
  }

  @Test
  public void intoImageViewAndSkipMemoryCacheDoesNotCheckMemoryCache() throws Exception {
    ImageView target = TestUtils.mockImageViewTarget();
    new RequestCreator(picasso, TestUtils.URI_1, 0).skipMemoryCache().into(target);
    verify(picasso, never()).quickMemoryCacheCheck(picasso.getCache(), TestUtils.URI_KEY_1);
  }

  @Test
  public void intoImageViewWithFitAndResizeThrows() throws Exception {
    try {
      ImageView target = TestUtils.mockImageViewTarget();
      new RequestCreator(picasso, TestUtils.URI_1, 0).fit().resize(10, 10).into(target);
      fail("Calling into() ImageView with fit() and resize() should throw exception");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void imageViewActionWithDefaultPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockImageViewTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(NORMAL);
  }

  @Test public void imageViewActionWithCustomPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).priority(HIGH).into(TestUtils.mockImageViewTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(HIGH);
  }

  @Test public void imageViewActionWithDefaultTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockImageViewTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo(actionCaptor.getValue());
  }

  @Test public void imageViewActionWithCustomTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).tag("tag").into(TestUtils.mockImageViewTarget());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo("tag");
  }

  @Test public void intoRemoteViewsWidgetQueuesAppWidgetAction() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, new int[] { 1, 2, 3 });
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(AppWidgetAction.class);
  }

  @Test public void intoRemoteViewsNotificationQueuesNotificationAction() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue()).isInstanceOf(NotificationAction.class);
  }

  @Test
  public void intoRemoteViewsNotificationWithNullRemoteViewsThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).into(null, 0, 0, TestUtils.mockNotification());
      fail("Calling into() with null RemoteViews should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsWidgetWithPlaceholderDrawableThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).placeholder(new ColorDrawable(0))
          .into(TestUtils.mockRemoteViews(), 0, new int[] { 1, 2, 3 });
      fail("Calling into() with placeholder drawable should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsWidgetWithErrorDrawableThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).error(new ColorDrawable(0))
          .into(TestUtils.mockRemoteViews(), 0, new int[] { 1, 2, 3 });
      fail("Calling into() with error drawable should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsNotificationWithPlaceholderDrawableThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).placeholder(new ColorDrawable(0))
          .into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
      fail("Calling into() with error drawable should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsNotificationWithErrorDrawableThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).error(new ColorDrawable(0))
          .into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
      fail("Calling into() with error drawable should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsWidgetWithNullRemoteViewsThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).into(null, 0, new int[] { 1, 2, 3 });
      fail("Calling into() with null RemoteViews should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsWidgetWithNullAppWidgetIdsThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, null);
      fail("Calling into() with null appWidgetIds should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsNotificationWithNullNotificationThrows() throws Exception {
    try {
      new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, 0, null);
      fail("Calling into() with null Notification should throw exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void intoRemoteViewsWidgetWithFitThrows() throws Exception {
    try {
      RemoteViews remoteViews = TestUtils.mockRemoteViews();
      new RequestCreator(picasso, TestUtils.URI_1, 0).fit().into(remoteViews, 1, new int[] { 1, 2, 3 });
      fail("Calling fit() into remote views should throw exception");
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void intoRemoteViewsNotificationWithFitThrows() throws Exception {
    try {
      RemoteViews remoteViews = TestUtils.mockRemoteViews();
      new RequestCreator(picasso, TestUtils.URI_1, 0).fit().into(remoteViews, 1, 1, TestUtils.mockNotification());
      fail("Calling fit() into remote views should throw exception");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void appWidgetActionWithDefaultPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, new int[] { 1, 2, 3 });
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(NORMAL);
  }

  @Test public void appWidgetActionWithCustomPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).priority(HIGH)
        .into(TestUtils.mockRemoteViews(), 0, new int[]{1, 2, 3});
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(HIGH);
  }

  @Test public void notificationActionWithDefaultPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(NORMAL);
  }

  @Test public void notificationActionWithCustomPriority() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).priority(HIGH)
        .into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getPriority()).isEqualTo(HIGH);
  }

  @Test public void appWidgetActionWithDefaultTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, new int[] { 1, 2, 3 });
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo(actionCaptor.getValue());
  }

  @Test public void appWidgetActionWithCustomTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).tag("tag")
        .into(TestUtils.mockRemoteViews(), 0, new int[]{1, 2, 3});
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo("tag");
  }

  @Test public void notificationActionWithDefaultTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo(actionCaptor.getValue());
  }

  @Test public void notificationActionWithCustomTag() throws Exception {
    new RequestCreator(picasso, TestUtils.URI_1, 0).tag("tag")
        .into(TestUtils.mockRemoteViews(), 0, 0, TestUtils.mockNotification());
    verify(picasso).enqueueAndSubmit(actionCaptor.capture(), eq(0L));
    assertThat(actionCaptor.getValue().getTag()).isEqualTo("tag");
  }

  @Test public void invalidResize() throws Exception {
    try {
      new RequestCreator().resize(-1, 10);
      fail("Negative width should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().resize(10, -1);
      fail("Negative height should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().resize(0, 10);
      fail("Zero width should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().resize(10, 0);
      fail("Zero height should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test public void invalidCenterCrop() throws Exception {
    try {
      new RequestCreator().resize(10, 10).centerInside().centerCrop();
      fail("Calling center crop after center inside should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void invalidCenterInside() throws Exception {
    try {
      new RequestCreator().resize(10, 10).centerInside().centerCrop();
      fail("Calling center inside after center crop should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void invalidPlaceholderImage() throws Exception {
    try {
      new RequestCreator().placeholder(0);
      fail("Resource ID of zero should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().placeholder(1).placeholder(new ColorDrawable(0));
      fail("Two placeholders should throw exception.");
    } catch (IllegalStateException expected) {
    }
    try {
      new RequestCreator().placeholder(new ColorDrawable(0)).placeholder(1);
      fail("Two placeholders should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void invalidErrorImage() throws Exception {
    try {
      new RequestCreator().error(0);
      fail("Resource ID of zero should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().error(null);
      fail("Null drawable should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().error(1).error(new ColorDrawable(0));
      fail("Two placeholders should throw exception.");
    } catch (IllegalStateException expected) {
    }
    try {
      new RequestCreator().error(new ColorDrawable(0)).error(1);
      fail("Two placeholders should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }

  @Test public void invalidPriority() throws Exception {
    try {
      new RequestCreator().priority(null);
      fail("Null priority should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().priority(LOW).priority(HIGH);
      fail("Two priorities should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }


  @Test public void invalidTag() throws Exception {
    try {
      new RequestCreator().tag(null);
      fail("Null tag should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().tag("tag1").tag("tag2");
      fail("Two tags should throw exception.");
    } catch (IllegalStateException expected) {
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void nullTransformationsInvalid() throws Exception {
    new RequestCreator().transform(null);
  }

  @Test public void nullTargetsInvalid() throws Exception {
    try {
      new RequestCreator().into((ImageView) null);
      fail("Null ImageView should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
    try {
      new RequestCreator().into((Target) null);
      fail("Null Target should throw exception.");
    } catch (IllegalArgumentException expected) {
    }
  }
}
