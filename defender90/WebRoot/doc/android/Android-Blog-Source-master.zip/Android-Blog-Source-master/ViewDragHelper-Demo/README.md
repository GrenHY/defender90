# 我的博客实例库（http://blog.csdn.net/yanbober）

##说明

该实例是博客 [《Android应用ViewDragHelper详解及部分源码浅析》](http://blog.csdn.net/yanbober/article/details/50419059) 的讲解实例Demo。

##ViewDragHelper的VerticalDrawerLayout垂直抽屉控件实现

如下是该控件的演示效果，支持Button切换收起展开，支持手势上滑下滑收起展开，支持跟随手指滑动，详细使用及源码见工程。

![VerticalDrawerLayout](./images/VerticalDrawerLayout.gif)

##ViewDragHelper的综合实现案例

如下是综合实例，考虑处理了ListView嵌套等触摸冲突问题。

![VerticalDrawerLayout](./images/test.gif)
