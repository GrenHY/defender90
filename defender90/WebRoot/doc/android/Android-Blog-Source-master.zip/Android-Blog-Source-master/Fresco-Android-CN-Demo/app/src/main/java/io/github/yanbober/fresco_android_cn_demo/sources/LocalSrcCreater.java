package io.github.yanbober.fresco_android_cn_demo.sources;

import java.util.List;

/**
 * Author       : yanbo
 * Date         : 2015-04-10
 * Time         : 15:58
 * Description  : 本地图片生成器
 */
public class LocalSrcCreater implements SrcCreaterImpl {
    @Override
    public String getPic() {
        return null;
    }

    @Override
    public List<String> getPicList() {
        return null;
    }

    @Override
    public String getGif() {
        return null;
    }

    @Override
    public List<String> getGifList() {
        return null;
    }
}
