# 我的博客实例库（http://blog.csdn.net/yanbober）

##说明

该实例是博客 []() 的讲解实例Demo。

##左右侧滑拉出收起的Layout，类似于ListView Item左右侧滑效果。

如下是该控件的演示效果，支持Button切换收起展开，支持手势上滑下滑收起展开，支持跟随手指滑动，详细使用及源码见工程。

![VerticalDrawerLayout](./images/test.gif)

