package com.yanbober.scroller_demo;

public class Person {
    public int mId;
    public String mName;
}
