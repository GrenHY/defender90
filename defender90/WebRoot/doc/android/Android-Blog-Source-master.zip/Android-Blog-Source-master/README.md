# 我的博客实例库（http://blog.csdn.net/yanbober）

##示例索引

###博客：NDK-JNI实战教程（三） 从比Hello World稍复杂点儿的NDK例子说说模板

[博客文章链接](http://blog.csdn.net/yanbober/article/details/45310589)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/NDKApplication)

###博客：facebook Fresco框架库源使用基础

[博客文章链接](http://blog.csdn.net/yanbober/article/details/45307897)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/Fresco-Android-CN-Demo)

###博客：浅谈MVP实现Android应用层开发

[博客文章链接](http://blog.csdn.net/yanbober/article/details/45645115)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/Android-MVP-Demo)

###博客：EventBus使用之基础

[博客文章链接](http://blog.csdn.net/yanbober/article/details/45667363)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/Android-EventBus-Demo)

###博客：Android应用Design Support Library完全使用实例

[博客文章链接](http://blog.csdn.net/yanbober/article/details/46312339)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/Support-Library-Demo)

###博客：Android自定义控件（状态提示图表）

[博客文章链接](http://blog.csdn.net/yanbober/article/details/46342361)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/CustomerViewDemo)


###博客：Android应用ViewDragHelper详解及部分源码浅析

[博客文章链接](http://blog.csdn.net/yanbober/article/details/50419059)---------[实例代码工程](https://github.com/yanbober/Android-Blog-Source/tree/master/ViewDragHelper-Demo)


##说明

示例均使用Android Studio演示。
