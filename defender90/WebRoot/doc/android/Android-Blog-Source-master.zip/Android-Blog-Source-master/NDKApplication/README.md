# 我的博客实例库（http://blog.csdn.net/yanbober）

##说明

该实例是博客 [NDK-JNI实战教程（三） 从比Hello World稍复杂点儿的NDK例子说说模板](http://blog.csdn.net/yanbober/article/details/45310589) 的讲解实例Demo。

第一部分的示例代码版本是：

dd9dbe24c09c7afbf565f3bf532b5e8651f506a3

第二部分的示例代码版本是：

50e6be1b0b9854c74fad37f1a9505fdc3d583834

依据需求对照博客自行切换版本获取不同部分示例代码。

##信息

- Android Studio工具
- 配置NDK路径
