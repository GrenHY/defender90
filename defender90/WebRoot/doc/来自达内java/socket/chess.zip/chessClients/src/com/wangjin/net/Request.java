package com.wangjin.net;
//请求的�?信协议规�?
public class Request {
	public static final int LOGIN = 1;//输入用户名的请求
	public static final int CR_ROOM = 2;//创建房间的请�?
	public static final int GET_ROOM = 3;//获取房间列表的请�?
	public static final int DEL_ROOM = 4;//删除房间
	//public static final int FLUSH_ROOM = 5;//刷新房间的请�?
    public static final int IN_ROOM = 6;//进入房间
    public static final int IN_RESULT = 7;//进入房间结果的请�?
    public static final int CHESS = 8;//落子的请�?
    public static final int SEND_MSG = 9;//发�?聊天请求
    public static final int NEWS_TART = 10;//新开游戏请求
    public static final int WIN = 11;//代表赢的请求
    public static final int GIVEUP = 12;//放弃请求
    public static final int SUM = 13;//求和
    public static final int SUM_RESULT = 14;//求和结果处理
    public static final int EXIT = 15;//�?��
    public static final int EXIT_ROOM = 16;//�?��游戏大厅的请�?
    //public static final int ROVS = 17;//转观战请�?
    public static final int IN_LOOK = 18;//进入观战
    public static final int LOO_GET_DATA = 19;//观看请求数据
    public static final int BACK_CHESS = 20;//悔棋
    public static final int BACK_CHESS_RESULT = 21;//悔棋结果处理
    public static final int FLUSH_ROOM1 = 22;//刷新房间的请�?
    public static final int EXIT_FLUSH = 23;//刷新房间的请�?
}
