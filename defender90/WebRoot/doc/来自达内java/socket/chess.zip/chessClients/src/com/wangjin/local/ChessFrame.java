package com.wangjin.local;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.net.URL;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import com.wangjin.gui.GetImgUrl;
import com.wangjin.gui.frameUtil;
import com.wangjin.util.LocationUtil;

public class ChessFrame extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean isBlack = true;
	private JMenuBar bar;// �˵���
	private JMenu game;// ��Ϸ�˵�
	private JMenuItem saveGame;// ������Ϸ
	private JMenuItem loadGame;// ������Ϸ
	private JButton backChess, start, min, close;// ���尴ť
	private ChessPanel panel;
	boolean isWin = false;
	
	JLabel comL = new JLabel(new ImageIcon(getUrl("blackmsg.png")));
	JLabel playL = new JLabel(new ImageIcon(getUrl("whitemsg.png")));
	frameUtil util1;

	public ChessFrame(frameUtil util1) {
		this.util1 = util1;
		JLabel mainLabel = new JLabel(new ImageIcon(getUrl("back.png")));
		panel = new ChessPanel();
		panel.setBounds(162, 88, 592, 592);
		panel.setOpaque(false);
		mainLabel.add(panel);
		this.setUndecorated(true);
		this.setBounds(200, 50, 900, 700);
		this.setIconImage(new ImageIcon(getUrl("icon.jpg")).getImage());
		// ���ý�����Ը�������ƶ�
		new LocationUtil(this);
		bar = new JMenuBar();
		bar.setBounds(10, 10, 100, 36);
		bar.setOpaque(false);
		bar.setBorderPainted(false);
		game = new JMenu("��Ϸ");
		game.setIcon(new ImageIcon(getUrl("bar.png")));
		game.setContentAreaFilled(false);
		game.setBorderPainted(false);
		game.add(saveGame = new JMenuItem("������Ϸ..."));
		game.add(loadGame = new JMenuItem("װ����Ϸ..."));
		mainLabel.add(bar);
		bar.add(game);
		comL.setBounds(30, 90, 110, 110);
		comL.setOpaque(false);
		mainLabel.add(comL);
		playL.setBounds(770, 510, 110, 110);
		playL.setOpaque(false);
		mainLabel.add(playL);
		this.add(mainLabel);
		backChess = new JButton(new ImageIcon(getUrl("huiqi.png")));
		backChess.setContentAreaFilled(false);
		backChess.setBorderPainted(false);
		backChess.setBounds(36, 416, 100, 42);
		mainLabel.add(backChess);
		close = new JButton(new ImageIcon(getUrl("close.png")));
		close.setBounds(860, 8, 34, 34);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		mainLabel.add(close);
		min = new JButton(new ImageIcon(getUrl("min.png")));
		min.setBounds(835, 8, 34, 34);
		min.setContentAreaFilled(false);
		min.setBorderPainted(false);
		mainLabel.add(min);
		start = new JButton(new ImageIcon(getUrl("start.png")));
		start.setBounds(409, 11, 34, 34);
		start.setContentAreaFilled(false);
		start.setBorderPainted(false);
		mainLabel.add(start);
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				if (isWin) {
					return;
				}
				int x = e.getX();
				int y = e.getY();
				int i = Math.round((float) (y - ChessPanel.leftSpace)
						/ ChessPanel.rowSpace);
				int j = Math.round((float) (x - ChessPanel.upSpace)
						/ ChessPanel.colSpace);
				System.out.println(i + ":" + j);
				panel.boardX = i;
				panel.boardY = j;
				if (panel.chess[i][j] != 0) {
					JOptionPane.showMessageDialog(ChessFrame.this,
							"��λ���������ˣ�����������");
					return;
				}
				String str = i + ":" + j + ":" + (isBlack ? 1 : 2);
				panel.stepChess.add(str);
				panel.chess[i][j] = isBlack ? 1 : 2;
				panel.repaint();
				if (panel.isWin(i, j)) {
					JOptionPane.showMessageDialog(ChessFrame.this,
							(isBlack ? "��" : "��") + "��ʤ��");
					isWin = true;
					start.setEnabled(true);
				}
				isBlack = !isBlack;
			}
		});
		// �԰�ť�����¼�
		saveGame.addActionListener(this);
		loadGame.addActionListener(this);
		start.addActionListener(this);
		min.addActionListener(this);
		close.addActionListener(this);
		backChess.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == saveGame) {
			// 1,���������ļ��Ի���
			JFileChooser jfc = new JFileChooser();
			jfc.showSaveDialog(this);

			// 2������û�ѡ����ļ�
			File f = jfc.getSelectedFile();
			panel.saveFile(f);
			return;
		}
		if (e.getSource() == loadGame) {
			// 1,�������ļ��Ի���
			JFileChooser jfc = new JFileChooser();
			jfc.showOpenDialog(this);
			// 2������û�ѡ����ļ�
			File f = jfc.getSelectedFile();
			// 3������
			if (f != null) {
				panel.loadFile(f);
				panel.repaint();
			}
			return;
		}
		if (e.getSource() == min) {
			ChessFrame.this.setState(JFrame.ICONIFIED);
		}
		if (e.getSource() == close) {
			ChessFrame.this.setVisible(false);
			util1.getChoiseFrame().setVisible(true);
		}
		if (e.getSource() == start) {
			isWin = false;
			panel.initChessPanel();
			panel.boardX = -1;
			panel.boardY = -1;
			panel.repaint();
			panel.stepChess.clear();
		}
		if (e.getSource() == backChess) {
			List<String> step = panel.stepChess;
			if (step.size() == 0) {
				return;
			}
			String[] str = step.get(step.size() - 1).split(":");
			int i = Integer.parseInt(str[0]);
			int j = Integer.parseInt(str[1]);
			panel.chess[i][j] = 0;
			if (step.size() == 1) {
				panel.boardX = -1;
				panel.boardY = -1;
				panel.repaint();
				return;
			}
			String[] strs = step.get(step.size() - 2).split(":");
			panel.boardX = Integer.parseInt(strs[0]);
			panel.boardY = Integer.parseInt(strs[1]);
			panel.repaint();
			panel.stepChess.remove(step.size() - 1);
		}
	}
	private URL getUrl(String str){
		return GetImgUrl.getImgUrl(1, str);
	}
}
