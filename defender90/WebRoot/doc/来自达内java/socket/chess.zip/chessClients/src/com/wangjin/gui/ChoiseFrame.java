package com.wangjin.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.wangjin.net.ClientThread;
import com.wangjin.net.ConnectUtil;
import com.wangjin.util.LocationUtil;

//五子棋开始界
public class ChoiseFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	JButton but1,but2,but3,min,close;
	frameUtil util;//窗体管理器类
	ClientThread t;
	public ChoiseFrame(frameUtil util){
		this.util = util;
	}
	// 初始化界
	public void init() {
		// 设置界面大小以及在屏幕上的显示位
		this.setBounds(util.loCationX, util.loCationY,900, 700);
		this.setUndecorated(true);
		this.setIconImage(new ImageIcon(GetImgUrl.getImgUrl(2,"icon.jpg"))
															.getImage());
		new LocationUtil(this);
		JLabel label = new JLabel(new ImageIcon(
				GetImgUrl.getImgUrl(4,"startback.jpg")));
		this.add(label);
         //对三个按钮初始化
		but1 = new JButton(new ImageIcon(GetImgUrl.getImgUrl(4,"danji1.png")));
		but1.setBounds(347, 370, 167, 62);
		but1.setPressedIcon(new ImageIcon(GetImgUrl.getImgUrl(4,"danji.png")));
		but1.setContentAreaFilled(false);
		but1.setBorderPainted(false);
		but2 = new JButton(new ImageIcon(GetImgUrl.getImgUrl(4,"wangluo1.png")));
		but2.setPressedIcon(new ImageIcon(GetImgUrl.getImgUrl(4,"wangluo.png")));
		but2.setBounds(347, 456, 167, 62);
		but2.setContentAreaFilled(false);
		but2.setBorderPainted(false);
		label.add(but2);
		but3 = new JButton(new ImageIcon(GetImgUrl.getImgUrl(4,"shuoming1.png")));
		but3.setPressedIcon(new ImageIcon(GetImgUrl.getImgUrl(4,"shuoming.png")));
		but3.setBounds(347, 541 ,167, 62);
		but3.setContentAreaFilled(false);
		but3.setBorderPainted(false);
		label.add(but3);
		label.add(but1);
		min = new JButton(new ImageIcon(GetImgUrl.getImgUrl(2,"min.png")));
		min.setBounds(810, 13 ,32, 32);
		min.setContentAreaFilled(false);
		min.setBorderPainted(false);
		label.add(min);
		close = new JButton(new ImageIcon(GetImgUrl.getImgUrl(2,"close.png")));
		close.setBounds(850, 13 ,32, 32);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		label.add(close);
		//  设置界面可见
		this.setVisible(true);
		MyClick click = new MyClick();
		but1.addActionListener(click);
		but2.addActionListener(click);
		but3.addActionListener(click);
		min.addActionListener(click);
		close.addActionListener(click);
	}
  class MyClick implements ActionListener{
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==but1){
			 util.getChessframe().setVisible(true);
			 ChoiseFrame.this.setVisible(false);
		}else if(e.getSource()==but2){
			ChoiseFrame.this.setVisible(false);
			util.getUserNameFrame().setVisible(true);
		   //连接服务器
			ConnectUtil.connect();
			//启动读取服务器数据的线程
	    t= new ClientThread(util);
	    t.start();
		
		}else if(e.getSource() == but3){
			
		}else if(e.getSource()==min){
			ChoiseFrame.this.setState(JFrame.ICONIFIED);
		}else if(e.getSource()==close){
			System.exit(0);
		}
	}
	  
  }
  
	
}
