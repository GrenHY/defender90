package com.wangjin.net;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.*;
//连接服务器的工具�?
public class ConnectUtil {
	public static Socket socket;
	public static BufferedReader br;
	public static PrintWriter out;
	//连接服务�?
	public static Socket connect(){
		try{
			if(socket==null){
			socket = new Socket("127.0.0.1",9876);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return socket;
	}
	//发�?消息
	public static void write(String msg){
		out.println(msg);
		out.flush();
	}
	//读取消息
	public static String read() throws IOException{
		String msg = br.readLine();
		return msg;
	}

}
