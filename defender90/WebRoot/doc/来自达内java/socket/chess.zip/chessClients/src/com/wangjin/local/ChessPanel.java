package com.wangjin.local;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import com.wangjin.gui.GetImgUrl;

public class ChessPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final int upSpace = 30;// �ϼ��
	public static final int leftSpace = 30;// ����
	public static final int rowSpace = 30;// �м��
	public static final int colSpace = 30;// �м��
	public static final int colNumber = 18;// ����
	public static final int rowNumber = 18;// ����
	public static final int chessRadio = 13;// ���ӵİ뾶
	int[][] chess = new int[rowNumber][colNumber];// ����������ӵ�����
	List<String> stepChess = new ArrayList<String>();
	int boardX = -1;
	int boardY = -1;

	// �ػ�paintCom
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		Stroke s = new BasicStroke(2.0f);
		g2.setStroke(s);
		// ������
		g.drawImage(new ImageIcon(getUrl("panel.png")).getImage(), 0, 0,
				this);
		for (int i = 0; i < rowNumber; i++) {
			g2.drawLine(leftSpace, upSpace + (rowSpace * i), leftSpace
					+ ((colNumber - 1) * colSpace), upSpace + (rowSpace * i));
		}
		// �������ϵ�����
		for (int i = 0; i < colNumber; i++) {
			g2.drawLine(leftSpace + (i * rowSpace), upSpace, leftSpace
					+ (i * rowSpace), upSpace + ((rowNumber - 1) * rowSpace));
		}
		// ������
		for (int i = 0; i < chess.length; i++) {
			for (int j = 0; j < chess[i].length; j++) {
				if (chess[i][j] == 0) {
					continue;
				} else {
					if (chess[i][j] == 1) {
						g.drawImage(new ImageIcon(getUrl("black.png"))
								.getImage(), j * colSpace + leftSpace
								- chessRadio, i * rowSpace + upSpace
								- chessRadio, this);
					} else if (chess[i][j] == 2) {
						g.drawImage(new ImageIcon(getUrl("white.png"))
								.getImage(), j * colSpace + leftSpace
								- chessRadio, i * rowSpace + upSpace
								- chessRadio, this);
					}
				}
			}
		}
		if (boardX != -1) {// �����һ����Ч���λ�û�һ���졮X�������Ա�ʶ��
			g2.setColor(Color.RED);
			g.fillOval(boardY * rowSpace + leftSpace - 5, boardX * colSpace
					+ upSpace - 5, 10, 10);

		}
	}

	public int[][] getChess() {
		return chess;
	}

	public void setChess(int[][] chess) {
		this.chess = chess;
	}

	// ����������
	public void loadFile(File f) {
		BufferedReader in;
		try {
			in = new BufferedReader(new InputStreamReader(
					new FileInputStream(f)));
			String line = "";
			while ((line = in.readLine()) != null) {
				stepChess.add(line);
				 parseData(line);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ��������
	public void saveFile(File f) {
		PrintWriter out;
		try {
			out = new PrintWriter(new OutputStreamWriter(
					new FileOutputStream(f)));
			for (int i = 0; i < stepChess.size(); i++) {
				out.println(stepChess.get(i));
				out.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void parseData(String strs) {
		String[] str = strs.split(":");
		int i = Integer.parseInt(str[0]);
		int j = Integer.parseInt(str[1]);
		boardX = i;
		boardY = j;
		int chessColor = Integer.parseInt(str[2]);
		chess[i][j] = chessColor;
		repaint();
	}

	// ��ʼ������
	public void initChessPanel() {
		for (int i = 0; i < chess.length; i++) {
			for (int j = 0; j < chess.length; j++) {
				chess[i][j] = 0;
			}
		}
		repaint();
	}

	// �ж���Ӯ �ܷ���
	public boolean isWin(int i, int j) {
		return isUpAndDown(i, j) || isLeftAndRight(i, j)
				|| isLeftUpAndRightDown(i, j) || isLeftDownAndRightUp(i, j);
	}

	// ���·���
	public boolean isUpAndDown(int i, int j) {
		int i1 = i - 1;
		// �������� �����겻�� ������--
		while (true) {
			if (i1 < 0 || chess[i][j] != chess[i1][j]) {
				break;
			}
			i1--;
		}
		// �������ж�
		i1++;
		int count = 0;// ����
		while (true) {
			if (i1 >= rowNumber || chess[i1][j] != chess[i][j]) {
				break;
			}
			i1++;
			count++;
		}
		return count >= 5;
	}

	// ���ҷ���
	public boolean isLeftAndRight(int i, int j) {
		int j1 = j - 1;
		// �������� �����겻�� ������--
		while (true) {
			if (j1 < 0 || chess[i][j] != chess[i][j1]) {
				break;
			}
			j1--;
		}
		// �������ж�
		j1++;
		int count = 0;// ����
		while (true) {
			if (j1 >= colNumber || chess[i][j1] != chess[i][j]) {
				break;
			}
			j1++;
			count++;
		}
		return count >= 5;
	}

	// ��������
	public boolean isLeftUpAndRightDown(int i, int j) {
		int j1 = j - 1;
		int i1 = i - 1;
		// �������� �����겻�� ������--
		while (true) {
			if (j1 < 0 || i1 < 0 || chess[i][j] != chess[i1][j1]) {
				break;
			}
			j1--;
			i1--;
		}
		// �������ж�
		j1++;
		i1++;
		int count = 0;// ����
		while (true) {
			if (j1 >=colNumber || i1 >= rowNumber|| chess[i1][j1] != chess[i][j]) {
				break;
			}
			j1++;
			i1++;
			count++;
		}
		return count >= 5;
	}

	// ��������
	public boolean isLeftDownAndRightUp(int i, int j) {
		int j1 = j + 1;
		int i1 = i - 1;
		// �������� �����겻�� ������--
		while (true) {
			if (j1 >= colNumber|| i1 < 0 || chess[i][j] != chess[i1][j1]) {
				break;
			}
			i1--;
			;
			j1++;
		}
		// �������ж�
		i1++;
		j1--;
		int count = 0;// ����
		while (true) {
			if (j1 < 0 || i1 >= rowNumber || chess[i1][j1] != chess[i][j]) {
				break;
			}
			i1++;
			j1--;
			count++;
		}
		return count >= 5;
	}
	private URL getUrl(String str){
		return GetImgUrl.getImgUrl(1, str);
	}
}
