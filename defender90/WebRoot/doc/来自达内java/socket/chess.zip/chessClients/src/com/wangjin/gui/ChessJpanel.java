package com.wangjin.gui;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class ChessJpanel extends JPanel {
	private static final long serialVersionUID = 1L;
	public static final int liftSpace = 30;
	public static final int upSpace = 30;
	public static final int space = 30;
	public static final int row = 18;
	public static final int col = 18;
	public static final int r = 13;
	public static int clickCount = 0;
	public static int x1, y1, i, j;
	public static boolean isClick = false;
	public char[][] chessBoard = new char[row][row];
	public List<String> chessStep = new ArrayList<String>();

	public void start() {
		for (int i = 0; i < row; i++)
			for (int j = 0; j < row; j++)
				chessBoard[i][j] = '*';
	}

	@Override
	public void paint(Graphics g) {

		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;
		Stroke s = new BasicStroke(2.0f);
		g2.setStroke(s);
		g.drawImage(new ImageIcon(getUrl("panel.png")).getImage(), 0,
				0, this);
		for (int i = 0; i < row; i++) {
			g.drawLine(liftSpace, upSpace + space * i, liftSpace + (row - 1)
					* space, upSpace + space * i);
			g.drawLine(liftSpace + space * i, upSpace, liftSpace + space * i,
					upSpace + (row - 1) * space);
		}
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < row; j++) {
				if (chessBoard[i][j] == '@') {
					g.drawImage(new ImageIcon(getUrl("white.png"))
							.getImage(), j * space + liftSpace - r, i * space
							+ upSpace - r, this);

				} else if (chessBoard[i][j] == 'O') {
					g.drawImage(new ImageIcon(getUrl("black.png"))
					.getImage(), j * space + liftSpace - r, i * space
					+ upSpace - r, this);
				}
			}
		}

	}

	public boolean isWin(int i, int j) {
		int j1 = j - 1;
		int count = 1;
		while (true) { // 锟斤拷锟斤拷
			if (j1 >= 0 && chessBoard[i][j] == chessBoard[i][j1]) {
				count++;
				j1--;
			} else {
				break;
			}
		}
		j1 = j + 1;
		while (true) { // 锟斤拷xia
			if (j1 < col && chessBoard[i][j] == chessBoard[i][j1]) {
				count++;
				j1++;
			} else {
				break;
			}
		}
		if (count >= 5) {
			return true;
		}
		return false;
	}

	public boolean isWin1(int i, int j) {
		int count = 1;
		int i1 = i - 1;
		while (true) { // 锟斤拷锟斤拷
			if (i1 >= 0 && chessBoard[i][j] == chessBoard[i1][j]) {
				count++;
				i1--;
			} else {
				break;
			}
		}
		i1 = i + 1;
		while (true) { // 锟斤拷锟斤拷
			if (i1 < row && chessBoard[i][j] == chessBoard[i1][j]) {
				count++;
				i1++;
			} else {
				break;
			}
		}
		if (count >= 5) {
			return true;
		}
		return false;
	}

	public boolean isWin2(int i, int j) {
		int count, i1, j1;
		count = 1;
		j1 = j + 1;
		i1 = i + 1;
		while (true) { // 锟斤拷锟斤拷锟斤拷
			if (i1 < row && j1 < col && chessBoard[i][j] == chessBoard[i1][j1]) {
				count++;
				i1++;
				j1++;
			} else {
				break;
			}
		}
		j1 = j - 1;
		i1 = i - 1;
		while (true) { // 锟斤拷锟斤拷锟斤拷
			if (i1 >= 0 && j1 >= 0 && chessBoard[i][j] == chessBoard[i1][j1]) {
				count++;
				i1--;
				j1--;
			} else {
				break;
			}
		}
		if (count >= 5) {
			return true;
		}
		return false;
	}

	public boolean isWin3(int i, int j) {
		int count, i1, j1;
		count = 1;
		j1 = j + 1;
		i1 = i - 1;
		while (true) { // 锟斤拷
			if (i1 >= 0 && j1 < col && chessBoard[i][j] == chessBoard[i1][j1]) {
				count++;
				i1--;
				j1++;
			} else {
				break;
			}
		}
		j1 = j - 1;
		i1 = i + 1;
		while (true) { // 锟斤拷锟斤拷锟斤拷
			if (i1 < row && j1 >= 0 && chessBoard[i][j] == chessBoard[i1][j1]) {
				count++;
				i1++;
				j1--;
			} else {
				break;
			}
		}
		if (count >= 5) {
			return true;
		}
		return false;
	}
	private URL getUrl(String str){
		return GetImgUrl.getImgUrl(3, str);
	}
}
