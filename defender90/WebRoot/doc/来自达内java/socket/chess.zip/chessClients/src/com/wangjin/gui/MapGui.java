package com.wangjin.gui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import com.wangjin.net.ConnectUtil;
import com.wangjin.net.Request;
import com.wangjin.pojo.User;

public class MapGui extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	int row = 6;
	int col = 3;
	frameUtil util;
	
	RoomEntity[] entitys = new RoomEntity[row * col];
	int choiseNo = -1;

	public MapGui(frameUtil util) {
		this.util = util;
		GridLayout gridLayout = new GridLayout();
		this.setLayout(gridLayout);
		gridLayout.setRows(row);
		gridLayout.setColumns(col);
		gridLayout.setHgap(5);
		gridLayout.setVgap(5);
		this.setLayout(gridLayout);
		this.setBackground(new Color(105, 55, 32));
		for (int i = 0; i < entitys.length; i++) {
			entitys[i] = new RoomEntity();
			entitys[i].no = i;
			entitys[i].setContentAreaFilled(false);
			entitys[i].addActionListener(this);
			this.add(entitys[i]);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		RoomEntity so = (RoomEntity) e.getSource();
		if (choiseNo == -1) {
			if (so.state == 0) {
				ConnectUtil.write(Request.CR_ROOM + ":" + User.userName + ":"
						+ so.no);
				choiseNo = so.no;
				util.getGameRoomFrame().setVisible(false);
				util.getChessmainGui().setVisible(true);
				util.getChessmainGui().setMap(this);
				util.getChessmainGui().selfName.setText("您");
				util.getChessmainGui().duiName.setText("等待对方进入");
			} else if (so.state == 1) {
				if (so.no != choiseNo) {
					ConnectUtil.write(Request.IN_ROOM + ":" + so.no + ":"
							+ so.name1.getText() + ":" + User.userName);
					choiseNo = so.no;
				}

			} else if (so.state == 2) {
				ConnectUtil.write(Request.IN_LOOK + ":" + so.no + ":"
						+ User.userName + ":" + entitys[so.no].name1.getText());
				choiseNo = so.no;
			}
		}else{
			if(so.no==choiseNo){
				choiseNo = -1;
				ConnectUtil.write(Request.DEL_ROOM+":"+so.no);
			}
		}
	}
}
