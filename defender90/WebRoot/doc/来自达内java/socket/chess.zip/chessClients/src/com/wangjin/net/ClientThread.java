package com.wangjin.net;

import com.wangjin.gui.frameUtil;

//客户端线�? 不断读取服务器发送的数据
public class ClientThread extends Thread{
	frameUtil util;
	public ClientThread(frameUtil util){
		this.util = util;
	}
	public void run(){
		try{
			while(true){
				String str = ConnectUtil.read();
				String[] msgs = str.split(":");
				int a = Integer.parseInt(msgs[0]);
				switch(a){
				case Request.LOGIN:
					util.getUserNameFrame().loginResponse(msgs);
					break;
				case Request.CR_ROOM:
					util.getGameRoomFrame().crRoomResponse(msgs);
					break;
				case Request.GET_ROOM:
					util.getGameRoomFrame().getList1(msgs);;
					break;
//				case Request.FLUSH_ROOM:
//					//util.getGameRoomFrame().getList(msgs);
//					break;
				case Request.IN_ROOM:
					util.getGameRoomFrame().inRoom(msgs);
					break;
				case Request.IN_RESULT:
					util.getGameRoomFrame().inResult(msgs);
					break;
				case Request.CHESS:
					util.getChessmainGui().chess(msgs);
					break;
				case Request.SEND_MSG:
					util.getChessmainGui().sendMsg(msgs);
					break;
				case Request.NEWS_TART:
					util.getChessmainGui().newStart(msgs);
					break;
				case Request.GIVEUP:
					util.getChessmainGui().giveUp(msgs);
					break;
				case Request.SUM:
					util.getChessmainGui().sum(msgs);
					break;
				case Request.SUM_RESULT:
					util.getChessmainGui().sumResult(msgs);
					break;
				case Request.EXIT:
					 util.getChessmainGui().exit(msgs);
					break;
				case Request.IN_LOOK:
				   util.getGameRoomFrame().inLook(msgs);
					break;
				case Request.LOO_GET_DATA:
					util.getChessmainGui().getData(msgs);
					break;
				case Request.BACK_CHESS:
					util.getChessmainGui().backChess(msgs);
					break;
				case Request.BACK_CHESS_RESULT:
					util.getChessmainGui().backChessResult(msgs);
					break;
				case Request.FLUSH_ROOM1:
					util.getGameRoomFrame().flushVs(msgs);
					break;
				case Request.EXIT_FLUSH:
					util.getGameRoomFrame().ExitFlush(msgs);
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
