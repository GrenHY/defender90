package com.wangjin.gui;

import com.wangjin.local.ChessFrame;

public class frameUtil {
	private ChoiseFrame choiseFrame;
	private UserNameFrame userNameFrame;
	private GameRoomFrame gameRoomFrame;
	private ChessMainGui chessmainGui;
	private ChessFrame chessframe;
	
	public ChessFrame getChessframe() {
		return chessframe;
	}
	public void setChessframe(ChessFrame chessframe) {
		this.chessframe = chessframe;
	}
	int loCationX =200;
	int loCationY =20;
	public ChoiseFrame getChoiseFrame() {
		return choiseFrame;
	}
	public void setChoiseFrame(ChoiseFrame choiseFrame) {
		this.choiseFrame = choiseFrame;
	}
	public UserNameFrame getUserNameFrame() {
		return userNameFrame;
	}
	public void setUserNameFrame(UserNameFrame userNameFrame) {
		this.userNameFrame = userNameFrame;
	}
	public GameRoomFrame getGameRoomFrame() {
		return gameRoomFrame;
	}
	public void setGameRoomFrame(GameRoomFrame gameRoomFrame) {
		this.gameRoomFrame = gameRoomFrame;
	}
	public ChessMainGui getChessmainGui() {
		return chessmainGui;
	}
	public void setChessmainGui(ChessMainGui chessmainGui) {
		this.chessmainGui = chessmainGui;
	}
    
	
}
