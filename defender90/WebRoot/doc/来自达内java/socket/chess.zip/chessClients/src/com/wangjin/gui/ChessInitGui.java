package com.wangjin.gui;

import com.wangjin.local.ChessFrame;

public class ChessInitGui {
	public ChessInitGui(){
		frameUtil util = new frameUtil();
		ChoiseFrame choiseFrame = new ChoiseFrame(util);
		util.setChoiseFrame(choiseFrame);
		UserNameFrame userNameFrame= new UserNameFrame(util);
	    util.setUserNameFrame(userNameFrame);
	    choiseFrame.init();
	    GameRoomFrame gameRoomFrame = new GameRoomFrame(util);
	    util.setGameRoomFrame(gameRoomFrame);
	    ChessMainGui chessmainGui = new ChessMainGui(util);
	    util.setChessmainGui(chessmainGui);
	    ChessFrame chessframe = new ChessFrame(util); 
	    util.setChessframe(chessframe);
	    userNameFrame.init();
	    gameRoomFrame.init();
	    chessmainGui.init();
	}
	
}
