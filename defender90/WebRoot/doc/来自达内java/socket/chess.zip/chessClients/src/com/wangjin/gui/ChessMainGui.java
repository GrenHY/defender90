package com.wangjin.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.wangjin.net.ConnectUtil;
import com.wangjin.net.Request;
import com.wangjin.pojo.User;
import com.wangjin.util.LocationUtil;

public class ChessMainGui extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel duiName, duiScore, duiIcon, selfName, selfScore, selfIcon;
	MapGui map;
	ChessJpanel chessPanel;

	frameUtil util;

	JLabel state;

	JButton newStart, backChess, giveUp, sum, exit, min;

	JTextArea msgRoom;

	JTextField msgF;

	boolean isChess = false;

	boolean isVs = false;// 是否两个人都在线

	boolean isV = false;// 默认两个人没有对战
	public boolean isLook = false;// 是否是观战者的身份

	public ChessMainGui(frameUtil util) {
		this.util = util;
	}

	public void setMap(MapGui map) {
		this.map = map;
	}

	public void init() {
		this.setBounds(util.loCationX, util.loCationY, 900, 700);
		this.setUndecorated(true);
		this.setIconImage(new ImageIcon(GetImgUrl.getImgUrl(2,"icon.jpg")).
				getImage());
		JLabel label = new JLabel(new ImageIcon(
				GetImgUrl.getImgUrl(3,"mainback.png")));
		JLabel chessMsg = new JLabel(new ImageIcon("image/title_cn.png"));
		this.add(label);
		new LocationUtil(this);

		newStart = new JButton(new ImageIcon(
				GetImgUrl.getImgUrl(3, "xinkai.png")));
		newStart.setBounds(20, 409, 123, 48);
		label.add(newStart);

		backChess = new JButton(new ImageIcon(GetImgUrl.getImgUrl(3,
				"huiqi.png")));
		backChess.setBounds(20, 476, 123, 48);
		label.add(backChess);
		giveUp = new JButton(new ImageIcon(GetImgUrl.getImgUrl(
				3,"renshu.png")));
		giveUp.setBounds(20, 543, 123, 48);
		label.add(giveUp);
		sum = new JButton(new ImageIcon(GetImgUrl.getImgUrl(3,"heqi.png")));
		sum.setContentAreaFilled(true);
		sum.setBounds(20, 608, 123, 48);
		label.add(sum);
		exit = new JButton(new ImageIcon(GetImgUrl.getImgUrl(3,"exit.png")));
		exit.setBounds(769, 63, 107, 42);

		label.add(exit);
		chessPanel = new ChessJpanel();
		chessPanel.setBounds(161, 90, 592, 592);
		chessPanel.setOpaque(false);
		label.add(chessPanel);
		duiName = new JLabel("张三");
		duiName.setBounds(19, 215, 118, 50);
		label.add(duiName);
		duiScore = new JLabel("1000");
		duiScore.setBounds(45, 261, 100, 30);
		label.add(duiScore);
		duiIcon = new JLabel(new ImageIcon(
				GetImgUrl.getImgUrl(3,"blackmsg.png")));
		duiIcon.setBounds(110, 82, 36, 36);
		label.add(duiIcon);
		selfName = new JLabel("李四");
		selfName.setBounds(758, 265, 118, 50);
		label.add(selfName);
		selfScore = new JLabel("1000");
		selfScore.setBounds(786, 312, 100, 30);
		label.add(selfScore);
		selfIcon = new JLabel(new ImageIcon(
				GetImgUrl.getImgUrl(3,"whitemsg.png")));
		selfIcon.setBounds(847, 127, 36, 36);
		label.add(selfIcon);
		state = new JLabel(new ImageIcon(
				GetImgUrl.getImgUrl(3,"helfmsg.png")));
		state.setBounds(9, 347, 145, 35);
		label.add(state);
		msgRoom = new JTextArea();
		msgRoom.setEditable(false);
		msgRoom.setBounds(755, 413, 110, 236);
		label.add(msgRoom);
		msgF = new JTextField();
		msgF.setBounds(755, 650, 110, 30);
		label.add(msgF);
		label.add(chessMsg);
		min = new JButton(new ImageIcon(GetImgUrl.getImgUrl(2,"min.png")));
		min.setBounds(810, 13, 32, 32);
		min.setContentAreaFilled(false);
		min.setBorderPainted(false);
		label.add(min);
		// 设置按钮样式
		exit.setContentAreaFilled(false);
		giveUp.setContentAreaFilled(false);
		newStart.setContentAreaFilled(false);
		backChess.setContentAreaFilled(false);
		sum.setContentAreaFilled(false);
		exit.setBorderPainted(false);
		giveUp.setBorderPainted(false);
		newStart.setBorderPainted(false);
		backChess.setBorderPainted(false);
		sum.setBorderPainted(false);
		backChess.setEnabled(false);
		giveUp.setEnabled(false);
		newStart.setEnabled(false);
		sum.setEnabled(false);
		// 添加事件
		MyClick click = new MyClick();
		chessPanel.addMouseListener(click);
		msgF.addKeyListener(click);
		newStart.addActionListener(click);
		backChess.addActionListener(click);
		giveUp.addActionListener(click);
		sum.addActionListener(click);
		exit.addActionListener(click);
		min.addActionListener(click);
	}

	class MyClick implements MouseListener, KeyListener, ActionListener {
		// 鼠标点击实现
		public void mouseClicked(MouseEvent e) {
			if (isChess) {
				int x = e.getX();
				int y = e.getY();
				int i = Math.round((float) (y - ChessJpanel.upSpace)
						/ ChessJpanel.space);
				int j = Math.round((float) (x - ChessJpanel.liftSpace)
						/ ChessJpanel.space);
				// 通信协议:房间号:i:j:color
				ConnectUtil.write(Request.CHESS + ":" + map.choiseNo + ":"
						+ duiName.getText() + ":" + User.userName + ":" + i
						+ ":" + j + ":" + User.color);
			}
		}

		public void mouseEntered(MouseEvent arg0) {
		}

		public void mouseExited(MouseEvent arg0) {
		}

		public void mousePressed(MouseEvent arg0) {
		}

		public void mouseReleased(MouseEvent arg0) {
		}

		public void keyPressed(KeyEvent e) {
			// 触发键盘事件
			if (e.getKeyCode() == 10) {
				// 回车
				// 通信协议:房间号:发送者名字:消息
				if (!msgF.getText().trim().equals("")) {
					ConnectUtil.write(Request.SEND_MSG + ":" + map.choiseNo
							+ ":" + User.userName + ":" + duiName.getText()
							+ ":" + msgF.getText().trim());
					msgF.setText("");
				}
			}

		}

		public void keyReleased(KeyEvent arg0) {
		}

		public void keyTyped(KeyEvent arg0) {
		}

		// 触发按钮调用方法
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == newStart) {
				// 点击新开按钮者先落子
				ConnectUtil.write(Request.NEWS_TART + ":" + map.choiseNo + ":"
						+ User.userName + ":" + duiName.getText());
				isChess = true;
				isV = true;
				backChess.setEnabled(true);
				giveUp.setEnabled(true);
				sum.setEnabled(true);
				state.setText("请你落子");
				chessPanel.start();
				chessPanel.repaint();
				// 让按钮失效
				newStart.setEnabled(false);
			} else if (e.getSource() == giveUp) {
				// 放弃
				int a = JOptionPane.showConfirmDialog(ChessMainGui.this,
						"你确定放弃吗?", "放弃确认", JOptionPane.YES_NO_OPTION);
				if (a == 0) {
					// 确定放弃
					ConnectUtil.write(Request.GIVEUP + ":" + map.choiseNo + ":"
							+ duiName.getText());
					newStart.setEnabled(true);
					isChess = false;
					isV = false;
					backChess.setEnabled(false);
					giveUp.setEnabled(false);
					sum.setEnabled(false);
				}
			} else if (e.getSource() == sum) {
				// 求和
				int a = JOptionPane.showConfirmDialog(ChessMainGui.this,
						"你确定求和吗?", "求和", JOptionPane.YES_NO_OPTION);
				if (a == 0) {
					ConnectUtil.write(Request.SUM + ":" + map.choiseNo + ":"
							+ duiName.getText());
				}
			} else if (e.getSource() == exit) {
				if (isLook) {
					ConnectUtil.write(Request.EXIT + ":" + map.choiseNo + ":"
							+ User.userName + ":"
							+ map.entitys[map.choiseNo].name1.getText() + ":"
							+ map.entitys[map.choiseNo].name2.getText() + ":"
							+ isLook);
					isLook = false;
					map.choiseNo = -1;
				} else {
					// 退出 isVs
					if (isVs) {
						// 代表两个人都没有退出
						String str = isV ? "处于对战中,强制退出要扣积分!" : "确定离开该房间";
						int a = JOptionPane.showConfirmDialog(
								ChessMainGui.this, str, "退出",
								JOptionPane.YES_NO_OPTION);
						if (a == 0) {
							if (isV) {
								User.elo = User.elo - 50;
							}
							// 通信协议:房间号:对方的名字:退出的类型
							ConnectUtil.write(Request.EXIT + ":" + map.choiseNo
									+ ":" + duiName.getText() + ":"
									+ map.entitys[map.choiseNo].name1.getText()
									+ ":"
									+ map.entitys[map.choiseNo].name2.getText()
									+ ":" + isLook+":"+isV);
							ChessMainGui.this.setVisible(false);
							util.getGameRoomFrame().setVisible(true);
							chessPanel.start();
							// 发送请求 获取房间列表
							ConnectUtil.write(Request.GET_ROOM + ":"
									+ User.userName);
							backChess.setEnabled(false);
							giveUp.setEnabled(false);
							sum.setEnabled(false);
							newStart.setEnabled(true);
							msgRoom.setText("");
						}

					} else {
						ChessMainGui.this.setVisible(false);
						util.getGameRoomFrame().setVisible(true);
						ConnectUtil.write(Request.EXIT + ":" + map.choiseNo + ":"
								+ User.userName + ":"
								+ map.entitys[map.choiseNo].name1.getText() + ":"
								+ map.entitys[map.choiseNo].name2.getText() + ":"
								+ isLook+":"+isV);
						chessPanel.start();
						backChess.setEnabled(false);
						giveUp.setEnabled(false);
						sum.setEnabled(false);
						newStart.setEnabled(true);
						msgRoom.setText("");
						// 发送请求 获取房间列表
						ConnectUtil.write(Request.GET_ROOM + ":"
								+ User.userName);
					}
				}
				isV = false;
				isVs = false;
				map.choiseNo = -1;
			} else if (e.getSource() == backChess) {
				List<String> chessStep = chessPanel.chessStep;
				if (chessStep.size() >= 1) {
					// 最后落子的人是谁 自己和对方
					ConnectUtil.write(Request.BACK_CHESS + ":"
							+ duiName.getText());
				}
			} else if (e.getSource() == min) {
				ChessMainGui.this.setState(JFrame.ICONIFIED);
			}

		}

	}

	// 落子处理
	public void chess(String[] msgs) {
		int i = Integer.parseInt(msgs[1]);
		int j = Integer.parseInt(msgs[2]);
		char color = msgs[3].charAt(0);
		if (User.color == color) {
			isChess = false;
			state.setText("等待对方落子");
		} else {
			isChess = true;
			state.setText("请你落子");
		}
		chessPanel.chessBoard[i][j] = color;
		chessPanel.repaint();
		chessPanel.chessStep.add(i + "_" + j + "_" + color);
		// 判断输赢
		if (chessPanel.isWin(i, j) || chessPanel.isWin1(i, j)
				|| chessPanel.isWin2(i, j) || chessPanel.isWin3(i, j)) {
			// ConnectUtil.write(Request.WIN+":"+User.roomNo+":"+duiName.getText()+":"+User.userName);

			if (!isLook) {
				JOptionPane.showMessageDialog(this, (User.color == color ? "你"
						: "对方")
						+ "胜利");
				newStart.setEnabled(true);
				isChess = false;
			} else {
				if (color == 'O') {
					msgRoom.append("黑方胜利/n");
				} else if (color == '@') {
					msgRoom.append("白方胜利/n");
				}
			}
		}
	}

	// 处理聊天响应
	public void sendMsg(String[] msgs) {
		String name = msgs[1];
		String msg = msgs[2];
		msgRoom.append(name + "说:" + msg + "\n");
	}

	// 处理新开游戏的响应
	public void newStart(String[] msgs) {
		JOptionPane.showMessageDialog(this, msgs[1] + "新开一局游戏");
		state.setText("请等待对方落子");
		chessPanel.start();
		chessPanel.repaint();
		newStart.setEnabled(false);
		isV = true;
		backChess.setEnabled(true);
		giveUp.setEnabled(true);
		sum.setEnabled(true);
	}

	// 处理弃权的响应
	public void giveUp(String[] msgs) {
		JOptionPane.showMessageDialog(this, "对方弃权了,你胜利");
		// 处理对方和自己的分数
		newStart.setEnabled(true);
		isChess = false;
		isV = false;
		backChess.setEnabled(false);
		giveUp.setEnabled(false);
		sum.setEnabled(false);
	}

	// 求和处理
	public void sum(String[] msgs) {
		int a = JOptionPane.showConfirmDialog(this, "对方求和", "求和",
				JOptionPane.YES_NO_OPTION);
		if (a == 0) {
			// 同意求和
			newStart.setEnabled(true);
			isChess = false;
			isV = false;
			backChess.setEnabled(false);
			giveUp.setEnabled(false);
			sum.setEnabled(false);
		}
		ConnectUtil.write(Request.SUM_RESULT + ":" + User.roomNo + ":"
				+ duiName.getText() + ":" + a);
	}

	// 求和结果处理
	public void sumResult(String[] msgs) {
		int a = Integer.parseInt(msgs[1]);
		if (a == 0) {
			JOptionPane.showMessageDialog(this, "对方同意了你的求和");
			newStart.setEnabled(true);
			isChess = false;
			isV = false;
			backChess.setEnabled(false);
			giveUp.setEnabled(false);
			sum.setEnabled(false);
		} else if (a == 1) {
			JOptionPane.showMessageDialog(this, "对方拒绝了你的求和");
		}
	}

	// 退出响应
	public void exit(String[] msgs) {
		String str = "";
		if (isV) {
			str = "对方强制结束了游戏，离开房间,\n请重新回到游戏大厅选择对手!";
		} else {
			str = "对方离开房间,请重新回到游戏大厅选择对手!";
		}
		isVs = false;// 对方下线
		JOptionPane.showMessageDialog(this, str);
		newStart.setEnabled(false);
		isV = false;
		isChess = false;
		backChess.setEnabled(false);
		giveUp.setEnabled(false);
		sum.setEnabled(false);
		ChessMainGui.this.setVisible(false);
		util.getGameRoomFrame().setVisible(true);
		chessPanel.start();
		// 发送请求 获取房间列表
		ConnectUtil.write(Request.GET_ROOM + ":"
				+ User.userName);
	}

	// 获取当前棋盘上的棋子数据
	public void getData(String[] msgs) {
		String str = "";
		// i_j_color
		for (int i = 0; i < chessPanel.chessStep.size(); i++) {
			str = str + chessPanel.chessStep.get(i) + ",";
		}
		ConnectUtil.write(Request.LOO_GET_DATA + ":" + str + ":"
				+ selfName.getText() + ":" + User.color + ":"
				+ duiName.getText() + ":" + msgs[1]);

	}

	// 处理悔棋的请求
	public void backChess(String[] msgs) {
		int a = JOptionPane.showConfirmDialog(this, "对方请求悔棋", "悔棋",
				JOptionPane.YES_NO_OPTION);
		if (a == 0) {
			if (isChess) {
				backChessStep();

			} else {
				if (chessPanel.chessStep.size() >= 2) {
					backChessStep();
					backChessStep();
				}
			}
			isChess = false;
			state.setText("请等待对方落子");
		}
		ConnectUtil.write(Request.BACK_CHESS_RESULT + ":" + a + ":"
				+ User.roomNo + ":" + duiName.getText());
	}

	// 悔棋逻辑处理方法封装
	public void backChessStep() {
		List<String> chessStep = chessPanel.chessStep;
		String str = chessStep.get(chessStep.size() - 1);
		String[] strs = str.split("_");
		int i = Integer.parseInt(strs[0]);
		int j = Integer.parseInt(strs[1]);
		chessPanel.chessBoard[i][j] = '*';
		chessPanel.repaint();
		chessPanel.chessStep.remove(chessStep.size() - 1);
	}

	// 悔棋结果处理响应
	public void backChessResult(String[] msgs) {
		int a = Integer.parseInt(msgs[1]);
		if (a == 0) {
			if (isChess) {
				backChessStep();
				backChessStep();
			} else {
				backChessStep();
			}
			isChess = true;
			state.setText("请你落子");
		} else if (a == 1) {
			JOptionPane.showMessageDialog(this, "对方拒绝悔棋");
		}
	}

}
