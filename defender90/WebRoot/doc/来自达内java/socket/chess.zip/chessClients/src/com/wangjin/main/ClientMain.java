package com.wangjin.main;

import com.wangjin.gui.ChessInitGui;

public class ClientMain {
	public static void main(String[] args){
		new ChessInitGui();
	}
}
