package com.wangjin.gui;

import java.io.File;
import java.net.URL;

public class GetImgUrl {
	private static final String FILE1=
			"image"+File.separator+"case1"+File.separator;
	private static final String FILE2=
			"image"+File.separator+"case2"+File.separator;
	private static final String FILE3=
		"image"+File.separator+"case2"+File.separator+"main"+File.separator;
	private static final String FILE4=
		"image"+File.separator+"case2"+File.separator+"start"+File.separator;

	public static URL getImgUrl(int key,String str){
		String name=getUrl(key, str);
		return GetImgUrl.class.getResource(name);
	}
	private static String getUrl(int key,String str){
		String name="";
		switch (key) {
		case 1:
			name=FILE1+str;
			break;
		case 2:
			name=FILE2+str;
			break;
		case 3:
			name=FILE3+str;
			break;
		case 4:
			name=FILE4+str;
			break;
		}
		return name;
	}
}
