package com.wangjin.gui;
import java.awt.Color;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;


public class RoomEntity extends JButton{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel playIcon1;
	JLabel playIcon2;
	JLabel chessIcon;
	JLabel name1;
	JLabel name2;
	int no;
	int state = 0;//状态 0空桌  1有一人  2有两人
	public RoomEntity(){
		this.setLayout(null);
		this.setBorderPainted(false);
		this.setBackground(new Color(105,55,32));
		playIcon1=new JLabel(new ImageIcon(getUrl("noplay.png")));
		playIcon1.setBounds(0, 5, 46, 46);
		this.add(playIcon1);
		playIcon2=new JLabel(new ImageIcon(getUrl("noplay.png")));
		playIcon2.setBounds(116, 5, 46, 46);
		this.add(playIcon2);
		chessIcon=new JLabel(new ImageIcon(getUrl("chessicon.png")));
		chessIcon.setBounds(48, 0, 67, 69);
		this.add(chessIcon);
		name1=new JLabel();
		name1.setBounds(0, 52, 46, 20);
		name1.setForeground(new Color(222,184,122));
		this.add(name1);
		name2=new JLabel();
		name2.setBounds(116, 52, 46, 20);
		name2.setForeground(new Color(222,184,122));
		this.add(name2);
	}
	private URL getUrl(String str) {
		return GetImgUrl.getImgUrl(2, str);
	}
	
}
