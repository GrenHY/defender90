package com.wangjin.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.wangjin.net.ConnectUtil;
import com.wangjin.net.Request;
import com.wangjin.pojo.User;
import com.wangjin.util.LocationUtil;

public class UserNameFrame extends JFrame{
	private static final long serialVersionUID = 1L;
	JTextField namet;//用户名输入框 
	JButton login,exit;
	frameUtil util;
	public UserNameFrame(frameUtil util){
		this.util = util;
	}
	public void init(){
		this.setBounds(500, 300, 393, 211);
		this.setUndecorated(true);
		this.setIconImage(new ImageIcon(getUrl("icon.jpg")).getImage());
		new LocationUtil(this);
		JLabel label = new JLabel(new ImageIcon(getUrl("userback.png")));
		this.add(label);
		namet = new JTextField();
		namet.setBounds(38, 63, 310, 38);
		namet.setBackground(new Color(242,211,158));
		label.add(namet);
		login = new JButton(new ImageIcon(getUrl("in.png")));;
		login.setBounds(37, 170, 130, 37);
		login.setContentAreaFilled(false);
		login.setBorderPainted(false);
		label.add(login);
		exit = new JButton(new ImageIcon(getUrl("exit.png")));
		exit.setBounds(220, 170, 130, 37);
		exit.setContentAreaFilled(false);
		exit.setBorderPainted(false);
		label.add(exit);
		//this.setVisible(true);
		MyClick click = new MyClick();
		login.addActionListener(click);
		exit.addActionListener(click);
	}
  class MyClick implements ActionListener{

	public void actionPerformed(ActionEvent e) {
	  if(e.getSource()==login){
		  //把输入的用户名发送给服务器
		  String name = namet.getText().trim();
		  if(!name.equals("")){
			  //发送消息 1:namet
			  ConnectUtil.write(Request.LOGIN+":"+name);
		  }
	  }else if(e.getSource()==exit){
		  util.getChoiseFrame().setVisible(true);
		  util.getUserNameFrame().setVisible(false);
	  }
		
	}
	  
  }
  //处理服务器响应的登录请求 1:false
  public void loginResponse(String[] msg){
	  //用户名正确
	  if(msg[1].equals("false")){
		  User.userName = namet.getText();
		  util.getGameRoomFrame().setVisible(true);
		  util.getUserNameFrame().setVisible(false);
		  util.getGameRoomFrame().namel.setText(User.userName);
		  //发送请求 获取房间列表
		  ConnectUtil.write(Request.GET_ROOM+":"+User.userName);
	  }else if(msg[1].equals("true")){
		  JOptionPane.showMessageDialog(UserNameFrame.this, "用户名存在");
	  }
  }
  private URL getUrl(String str){
	  return GetImgUrl.getImgUrl(2, str);
  }
}
