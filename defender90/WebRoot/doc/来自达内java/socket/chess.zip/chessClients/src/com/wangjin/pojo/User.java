package com.wangjin.pojo;
//用户的信�?
public class User {
	public static String userName;//用户的名�?
	public static int elo = 1000;//用户的积�?
    public static char color = 'O';//用户的颜�?
    public static int roomNo;//用户的房间号�?
}
