package com.wangjin.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.wangjin.net.ConnectUtil;
import com.wangjin.net.Request;
import com.wangjin.pojo.User;
import com.wangjin.util.LocationUtil;

//游戏大厅界面
public class GameRoomFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JLabel namel, elo, rooml, msgRoom;

	JButton min, close;
	ImageIcon[] isRoomicon = { new ImageIcon(getUrl("playicon1.png")),
			new ImageIcon(getUrl("playicon2.png")),
			new ImageIcon(getUrl("chessicon.png")),
			new ImageIcon(getUrl("noplay.png")) };
	MapGui map;
	DefaultListModel items = new DefaultListModel();
	frameUtil util;

	public GameRoomFrame(frameUtil util) {
		this.util = util;
	}
	private URL getUrl(String str){
		return GetImgUrl.getImgUrl(2, str);
	}
	public void init() {
		this.setBounds(util.loCationX, util.loCationY, 900, 700);
		this.setUndecorated(true);
		this.setIconImage(new ImageIcon(getUrl("icon.jpg")).getImage());
		new LocationUtil(this);
		JLabel label = new JLabel(
				new ImageIcon(getUrl("gameRoomback.jpg")));
		this.add(label);
		namel = new JLabel("张三");
		namel.setForeground(new Color(222, 184, 122));
		namel.setFont(new Font("微软雅黑", Font.ITALIC, 26));
		namel.setBounds(174, 82, 100, 25);
		label.add(namel);
		elo = new JLabel("1000ELO");
		elo.setBounds(233, 156, 50, 25);
		label.add(elo);
		rooml = new JLabel("");
		rooml.setBounds(26, 201, 150, 50);
		label.add(rooml);
		
		msgRoom = new JLabel(new ImageIcon(getUrl("but_3_11.png")));
		msgRoom.setBounds(265, 344, 53, 119);
		label.add(msgRoom);
		map = new MapGui(util);
		map.setBounds(312, 94, 555, 540);
		label.add(map);
		
		min = new JButton(new ImageIcon(getUrl("min.png")));
		min.setBounds(810, 13, 32, 32);
		min.setContentAreaFilled(false);
		min.setBorderPainted(false);
		label.add(min);
		close = new JButton(new ImageIcon(getUrl("close.png")));
		close.setBounds(850, 13, 32, 32);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		label.add(close);
		MyClick click = new MyClick();
		min.addActionListener(click);
		close.addActionListener(click);
	}

	class MyClick implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			 if (e.getSource() == min) {
				GameRoomFrame.this.setState(JFrame.ICONIFIED);
			} else if (e.getSource() == close) {
				// 通知服务器 下线
					ConnectUtil.write(Request.EXIT_ROOM + ":" + map.choiseNo+":"+User.userName);
					GameRoomFrame.this.setVisible(false);
					util.getChoiseFrame().setVisible(true);
					// 关闭客户端的读取数据的线程
					util.getChoiseFrame().t.stop();// 把t线程销毁
					// 把连接服务器的socket设置为null
					ConnectUtil.socket = null;
			}
		}
	}

	// 创建房间刷新游戏大厅的响应
	public void crRoomResponse(String[] msgs) {
		int id = Integer.parseInt(msgs[1]);
		String name = msgs[2];
		map.entitys[id].chessIcon.setIcon(isRoomicon[2]);
		map.entitys[id].playIcon1.setIcon(isRoomicon[0]);
		map.entitys[id].playIcon2.setIcon(isRoomicon[3]);
		map.entitys[id].name1.setText(name);
		map.entitys[id].state = 1;
	}

	public void flushVs(String[] msgs) {
		int id = Integer.parseInt(msgs[1]);
		map.entitys[id].state = 2;
		map.entitys[id].name2.setText(msgs[2]);
		map.entitys[id].playIcon2.setIcon(isRoomicon[1]);
	}

    //从对战状态退出房间刷新列表的响应
	 public void ExitFlush(String[] msgs) {
		    int id = Integer.parseInt(msgs[1]);
		    map.entitys[id].state = 0;
			map.entitys[id].chessIcon.setIcon(isRoomicon[2]);
			map.entitys[id].playIcon1.setIcon(isRoomicon[3]);
			map.entitys[id].name1.setText("");
			map.entitys[id].playIcon2.setIcon(isRoomicon[3]);
			map.entitys[id].name2.setText("");
	}
	// 登录成功获取房间列表响应
	public void getList1(String[] msgs) {
		if(msgs.length>1){
			String[] strs = msgs[1].split(",");
			for(int i=0;i<strs.length;i++){
				String[] ss = strs[i].split("_");
				int id = Integer.parseInt(ss[0]);
				   map.entitys[id].state = 1;
					map.entitys[id].chessIcon.setIcon(isRoomicon[2]);
					map.entitys[id].playIcon1.setIcon(isRoomicon[0]);
					map.entitys[id].name1.setText(ss[1]);
				if(ss.length==3){
					 map.entitys[id].state = 2;
					map.entitys[id].playIcon2.setIcon(isRoomicon[1]);
					map.entitys[id].name2.setText(ss[2]);
					
				}
				
			}
		}
	}


	// 处理进入房间的响应
	public void inRoom(String[] msgs) {
		int a = JOptionPane.showConfirmDialog(this, msgs[1] + "请求进入房间",
				"请求进入房间", JOptionPane.YES_NO_OPTION);
		if (a == 0) {
			// 同意
			util.getChessmainGui().selfName.setText("您");
			// util.getChessmainGui().selfScore.setText(User.elo + "ELO");
			// 请求者为黑方 被请求者为白方
			util.getChessmainGui().selfIcon.setIcon(new ImageIcon(
					"image/case14/whitemsg.png"));
			User.color = '@';
			util.getChessmainGui().duiName.setText(msgs[1]);
			// util.getChessmainGui().duiScore.setText(msgs[2]);
			util.getChessmainGui().duiIcon.setIcon(new ImageIcon(
					"image/case14/blackmsg.png"));
			//this.setVisible(false);
			util.getChessmainGui().setMap(map);
			util.getChessmainGui().newStart.setEnabled(true);
		     util.getChessmainGui().isV = true;
		     util.getChessmainGui().isVs = true;
			//util.getChessmainGui().setVisible(true);
		}
		// 发送消息给服务器
		ConnectUtil.write(Request.IN_RESULT + ":" + a + ":" + msgs[1]+":"+User.userName+":"+map.choiseNo);
	}

	// 处理对方给的结果的响应
	public void inResult(String[] msgs) {
		int a = Integer.parseInt(msgs[1]);
		if (a == 0) {
			// 代表对方同意
			// 同意
			util.getChessmainGui().selfName.setText("您");
			util.getChessmainGui().selfScore.setText(User.elo + "ELO");
			// 请求者为黑方 被请求者为白方
			util.getChessmainGui().selfIcon.setIcon(new ImageIcon(
					"image/case14/blackmsg.png"));
			User.color = 'O';
			util.getChessmainGui().duiName.setText(map.entitys[map.choiseNo].name1.getText());
			util.getChessmainGui().duiIcon.setIcon(new ImageIcon(
					"image/case14/whitemsg.png"));
			this.setVisible(false);
			util.getChessmainGui().setVisible(true);
			util.getChessmainGui().setMap(map);
			util.getChessmainGui().newStart.setEnabled(true);
			map.entitys[map.choiseNo].name2.setText(User.userName);
			 util.getChessmainGui().isV = true;
		     util.getChessmainGui().isVs = true;
			ConnectUtil.write(Request.FLUSH_ROOM1 + ":" + map.choiseNo + ":"
					+ map.entitys[map.choiseNo].name1.getText() + ":"
					+ map.entitys[map.choiseNo].name2.getText());
		} else if (a == 1) {
			// 代表对方拒绝
			JOptionPane.showMessageDialog(this, "对方拒绝进入房间");
			map.choiseNo = -1;
		}
	}


	// 进入观战的请求
	public void inLook(String[] msgs) {
		// 通信协议:str:一方名字:一方颜色:另外一方名字
		util.getChessmainGui().selfName.setText(msgs[2]);
		util.getChessmainGui().duiName.setText(msgs[4]);
		if (msgs[3].charAt(0) == 'O') {
			util.getChessmainGui().selfIcon.setIcon(new ImageIcon(
					"image/blackmsg.png"));
			util.getChessmainGui().duiIcon.setIcon(new ImageIcon(
					"image/whitemsg.png"));
		} else if (msgs[3].charAt(0) == '@') {
			util.getChessmainGui().selfIcon.setIcon(new ImageIcon(
					"image/whitemsg.png"));
			util.getChessmainGui().duiIcon.setIcon(new ImageIcon(
					"image/blackmsg.png"));
		}
		// i_j_color
		String[] data = msgs[1].split(",");
		for (int a = 0; a < data.length; a++) {
			String[] chess = data[a].split("_");
			int i = Integer.parseInt(chess[0]);
			int j = Integer.parseInt(chess[1]);
			char color = chess[2].charAt(0);
			util.getChessmainGui().chessPanel.chessBoard[i][j] = color;
		}
		this.setVisible(false);
		util.getChessmainGui().setVisible(true);
		util.getChessmainGui().chessPanel.repaint();
		util.getChessmainGui().newStart.setEnabled(false);
		util.getChessmainGui().isVs = false;
        util.getChessmainGui().isLook = true;
	}

	

	
}
