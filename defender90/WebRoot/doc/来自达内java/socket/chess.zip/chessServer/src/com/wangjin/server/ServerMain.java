package com.wangjin.server;

public class ServerMain {
	public static void main(String[] args) {
		new Server();
	}
}
