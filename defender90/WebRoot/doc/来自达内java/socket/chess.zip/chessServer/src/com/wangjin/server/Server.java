package com.wangjin.server;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class Server {
	Map<String, Socket> sockets = new Hashtable<String, Socket>();
	//用来保存当前创建房间的客户端
    Map<String,Socket>  rooms = new Hashtable<String,Socket>();
	//保存当前对战的集合列
	Map<String,Map<String,Socket>> vs = new Hashtable<String, Map<String,Socket>>();
	//保存每个房间的观看
	Map<String,Vector<String>> lookVs = new Hashtable<String, Vector<String>>();
	private ServerSocket server;
	public Server() {
		createServer();
	}
	private void createServer() {
		try {
			server = new ServerSocket(9876);
			while (true) {
				Socket socket = server.accept();
				System.out.println("客户端^");
				ServerThread t = new ServerThread(socket, sockets,rooms,vs,lookVs);
				t.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
