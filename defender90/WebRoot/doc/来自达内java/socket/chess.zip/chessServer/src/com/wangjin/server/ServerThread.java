package com.wangjin.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

public class ServerThread extends Thread {
	Socket socket;// 自己客户端的socket

	// 保存客户端socket对象的集
	Map<String, Socket> sockets;

	// 保存房间列表
	Map<String, Socket> rooms;

	PrintWriter out;

	BufferedReader br;
	// 保存房间观看
	Map<String, Vector<String>> lookVs;

	public ServerThread(Socket socket, Map<String, Socket>sockets, 
			Map<String, Socket> rooms,
			Map<String, Map<String, Socket>> vs,
			Map<String, Vector<String>> lookVs) {
		this.socket = socket;
		this.sockets = sockets;
		this.rooms = rooms;
		this.lookVs = lookVs;
	}

	public void run() {
		try {
			out = new PrintWriter(new OutputStreamWriter(socket
					.getOutputStream()));
			br = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
			while (true) {// 1:张三
				// 1:data1:data2:data3
				String str = br.readLine();
				String[] msgs = str.split(":");
				int a = Integer.parseInt(msgs[0]);
				switch (a) {
				case Request.LOGIN:
					boolean isName = sockets.containsKey(msgs[1]);
					if (isName) {
						out.println(Request.LOGIN + ":" + "true");
						out.flush();
					} else {
						sockets.put(msgs[1], socket);
						out.println(Request.LOGIN + ":" + "false");
						out.flush();
					}

					break;
				case Request.CR_ROOM:
					String name = msgs[1];// 获取到创建房间用户的名字
					String butNo = msgs[2];// 创建房间的号
					 String key = butNo + "_" + name;
					//String key = butNo + "";
					rooms.put(key, socket);
					System.out.println(Request.CR_ROOM + ":" + butNo + ":"
							+ name + "======");
					// 发消息给客户端
					sedAll(Request.CR_ROOM + ":" + butNo + ":" + name);
					break;
				case Request.GET_ROOM:
					loginRoom();
					break;
				case Request.DEL_ROOM:
					sedAll(Request.EXIT_FLUSH + ":" + msgs[1]);
					break;
				// case Request.FLUSH_ROOM:
				// sedAll(str);
				// break;
				case Request.IN_ROOM:
					// 进入房间请求
					inRoom(msgs);
					break;
				case Request.IN_RESULT:
					// 处理结果
					inResult(msgs);
					break;
				case Request.CHESS:
					chess(msgs);
					break;
				case Request.SEND_MSG:
					sendMSg(msgs);
					break;
				case Request.NEWS_TART:
					String msg = Request.NEWS_TART + ":" + msgs[2];
					sendOther(msgs[3], msg);
					break;
				case Request.GIVEUP:
					sendOther(msgs[2], Request.GIVEUP + ":");
					break;
				case Request.SUM:
					sendOther(msgs[2], Request.SUM + ":");
					break;
				case Request.SUM_RESULT:
					sendOther(msgs[2], Request.SUM_RESULT + ":" + msgs[3]);
					break;
				case Request.EXIT:
					exit(msgs);
					break;
				case Request.EXIT_ROOM:
					sockets.remove(msgs[2]);
					int aa = Integer.parseInt(msgs[1]);
					if (aa != -1) {
						rooms.remove(msgs[1] + "_" + msgs[2]);
						sedAll(Request.EXIT_FLUSH + ":" + msgs[1]);
					}
					System.out.println("下线");
					this.stop();
					break;
				case Request.IN_LOOK:
					inLook(msgs);
					break;
				case Request.LOO_GET_DATA:
					inLookData(msgs);
					break;
				case Request.BACK_CHESS:
					backChess(msgs);
					break;
				case Request.BACK_CHESS_RESULT:
					backChessResult(msgs);
					break;
				case Request.FLUSH_ROOM1:
					sedAll(Request.FLUSH_ROOM1 + ":" + msgs[1] + ":" + msgs[3]);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sedAll(String msg) throws IOException {
		Iterator<Socket> ss = sockets.values().iterator();
		while (ss.hasNext()) {
			Socket s = ss.next();
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
					.getOutputStream()));
			pw.println(msg);
			pw.flush();
		}
	}

	// 进入房间获取当前游戏大厅数据
	public void loginRoom() throws IOException {
		Iterator<String> it = rooms.keySet().iterator();
		System.out.println("size====="+rooms.size());
		String str = Request.GET_ROOM + ":";
		while (it.hasNext()) {
			String s = it.next();
			str += s + ",";
		}
		out.println(str);
		out.flush();
	}

	// 进入房间请求处理
	public void inRoom(String[] msgs) throws IOException {
		// ------------
		Socket ss = sockets.get(msgs[2]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(ss
				.getOutputStream()));
		pw.println(Request.IN_ROOM + ":" + msgs[3]);
		pw.flush();
	}

	// 处理请求结果的响�?
	public void inResult(String[] msgs) throws IOException {
		int a = Integer.parseInt(msgs[1]);
		// 找见请求者的socket
		Socket ss = sockets.get(msgs[2]);
		if (a == 0) {
			rooms.remove(msgs[4] + "_" + msgs[3]);
			rooms.put(msgs[4] + "_" + msgs[3] + "_" + msgs[2], socket);
		}
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(ss
				.getOutputStream()));
		// 通信协议:a:被请求�?名字:被请求�?积分:房间�?
		pw.println(Request.IN_RESULT + ":" + a);
		pw.flush();

	}

	// 落子处理
	public void chess(String[] msgs) throws IOException {
		String msg = Request.CHESS + ":" + msgs[4] + ":" + msgs[5] + ":"
				+ msgs[6];
		sendVs(msgs, msg);
		// 发�?给观战的�?
		boolean is = lookVs.containsKey(msgs[1]);
		if (is) {
			Vector<String> looks = lookVs.get(msgs[1]);
			for (int i = 0; i < looks.size(); i++) {
				String name = looks.get(i);
				System.out.println(is + ":" + name);
				Socket s = sockets.get(name);
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
						.getOutputStream()));
				pw.println(msg);
				pw.flush();
			}
		}

	}

	// 发�?聊天
	public void sendMSg(String[] msgs) throws IOException {
		String msg = Request.SEND_MSG + ":" + msgs[2] + ":" + msgs[3];
		sendVs(msgs, msg);
	}

	// 发�?消息给当前对战的两个客户�?
	public void sendVs(String[] msgs, String msg) throws IOException {
		Socket s = sockets.get(msgs[2]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(msg);
		pw.flush();
		Socket ss = sockets.get(msgs[3]);
		PrintWriter pw1 = new PrintWriter(new OutputStreamWriter(ss
				.getOutputStream()));
		pw1.println(msg);
		pw1.flush();
	}

	// 给对方发送消息的方法
	public void sendOther(String otherName, String msg) throws IOException {
		// 找见房间号对应的集合
		// 在vss中找到对方的socket
		Socket s = sockets.get(otherName);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(msg);
		pw.flush();
		// 发�?消息给观战�?
	}

	// �?��处理
	public void exit(String[] msgs) throws IOException {
		if (!msgs[5].equals("true")) {// 是以对站�?��身份�?��
			if (msgs[6].equals("true")) {// 从对战中�?���?
				sendOther(msgs[2], Request.EXIT + ":");
				rooms.remove(msgs[1] + "_" + msgs[3] + "_" + msgs[4]);
				rooms.remove(msgs[1] + "_" + msgs[4] + "_" + msgs[3]);
			} else {
				System.out.println("key===="+msgs[1]+"_"+msgs[2]);
				rooms.remove(msgs[1] + "_" + msgs[2]);
			}
			// 通知�?��在线客户端刷新游戏大�?
			sedAll(Request.EXIT_FLUSH + ":" + msgs[1]);
		} else {
			lookVs.get(msgs[1]).remove(msgs[2]);
		}
		// 把这两个人从对战的列表清�?
	}

	// 进入观战
	public void inLook(String[] msgs) throws IOException {

		boolean is = lookVs.containsKey(msgs[1]);
		if (is) {
			lookVs.get(msgs[1]).add(msgs[2]);
		} else {
			Vector<String> v = new Vector<String>();
			v.add(msgs[2]);
			lookVs.put(msgs[1], v);
		}
		Socket s = sockets.get(msgs[3]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(Request.LOO_GET_DATA + ":" + msgs[2]);
		pw.flush();
	}

	public void inLookData(String[] msgs) throws IOException {
		// 通信协议:str:�?��名字:�?��颜色:另外�?��名字
		Socket s = sockets.get(msgs[5]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(Request.IN_LOOK + ":" + msgs[1] + ":" + msgs[2] + ":"
				+ msgs[3] + ":" + msgs[4]);
		pw.flush();
	}

	// 处理悔棋
	public void backChess(String[] msgs) throws IOException {
		Socket s = sockets.get(msgs[1]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(Request.BACK_CHESS + ":");
		pw.flush();
	}

	// 悔棋结果处理
	public void backChessResult(String[] msgs) throws IOException {
		Integer a = Integer.parseInt(msgs[1]);
		if (a == 0) {
			// 告诉观战者悔棋处�?
		}
		Socket s = sockets.get(msgs[3]);
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
				.getOutputStream()));
		pw.println(Request.BACK_CHESS_RESULT + ":" + a);
		pw.flush();
	}

}
