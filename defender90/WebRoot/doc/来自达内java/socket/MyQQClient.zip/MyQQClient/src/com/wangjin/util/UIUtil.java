package com.wangjin.util;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.wangjin.gui.SuperFrame;
/**
 * ����UI�Ĺ�����
 * @author ��ʫ������
 * @QQ 824886693 
 */
public class UIUtil {
	
	public static final ImageIcon AUTHOR=
							new ImageIcon(getImageUrl("author.png"));
	public static final Icon DIALOG=new ImageIcon(getImageUrl("dialog.gif"));
	public static final Icon MARIO=new ImageIcon(getImageUrl("mario.gif"));
	public static final ImageIcon WELBACK=
			new ImageIcon(getImageUrl("1bg.png"));
	public static final ImageIcon SNOW=
			new ImageIcon(getImageUrl("snowflower.png"));
	/**
	 * ���÷��䣬���÷���
	 * ���ô���͸��
	 * @param frame
	 */
	public static void function(JFrame frame){
		try {
			Class<?> clazz = Class.forName("com.sun.awt.AWTUtilities");
			Method method = clazz.getMethod("setWindowOpaque",
					java.awt.Window.class, Boolean.TYPE);
			method.invoke(clazz, frame, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * �޸����ַ����������弰��ɫ
	 * @param mf
	 */
	public static void chooseFontAndColor(SuperFrame mf){
			
		JFontChooser one = new JFontChooser(mf.font, mf.color);
		one.showDialog(null, 500, 200);
		Font font = one.getSelectedfont();
		Color color = one.getSelectedcolor();
		if (font != null && color != null) {
			mf.font = font;
			mf.color = color;
			mf.sendArea.setForeground(color);
			mf.sendArea.setFont(font);
		}
	}
	/**
	 * ���ͼƬ��URL·��
	 * @param str
	 * @return url
	 */
	private static URL getImageUrl(String str){
		URL url=
				GetImagePathUtil.getImageResource("icon"+File.separator+str);
		return url;
	}
}
