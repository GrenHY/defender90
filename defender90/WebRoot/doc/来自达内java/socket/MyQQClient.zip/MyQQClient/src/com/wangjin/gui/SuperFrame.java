package com.wangjin.gui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextPane;
/**
 * Ⱥ�ĺ�˽�ĵ�UI����
 * @author ��ʫ������
 * @QQ 824886693
 *
 */
public class SuperFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Font font = new Font("����", Font.BOLD, 15);
	public Color color = Color.red;
	public JTextPane msgArea, sendArea;
}
