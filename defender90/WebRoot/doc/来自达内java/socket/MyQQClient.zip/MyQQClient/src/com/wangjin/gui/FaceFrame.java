package com.wangjin.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyledDocument;

import com.wangjin.entity.Request;
import com.wangjin.util.GetImagePathUtil;
import com.wangjin.util.LocationUtil;
import com.wangjin.util.SocketUtil;
/**
 * �����ǩ��
 * @author ��ʫ������
 * @QQ 824886693
 */
public class FaceFrame extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	JFrame frame;
	/**
	 * ��ʼ�������UI����
	 * @param textPane1
	 */
	public FaceFrame(JFrame textPane1) {
		this.frame = textPane1;

		JLabel label = new JLabel(new ImageIcon(
				GetImagePathUtil.getImageResource("face/main.png")));
		this.add(label);
		this.setBounds(400, 300, 259, 259);
		this.setUndecorated(true);
		JPanel panel = new JPanel(new GridLayout(5, 5));
		panel.setOpaque(false);
		panel.setBounds(0, 80, 260, 159);
		label.add(panel);
		LocationUtil util = new LocationUtil(this);
		util.setOp();
		ArrayList<JButton> al = new ArrayList<JButton>();
		for (int i = 1; i < 24; i++) {
			ImageIcon ii = new ImageIcon(
					GetImagePathUtil.getImageResource("face/"
							+ (i < 10 ? "0" + i : i) + ".gif"));
			JButton jl = new JButton(ii);
			jl.addActionListener(this);
			jl.setContentAreaFilled(false);
			al.add(jl);
			panel.add(jl);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String s = e.getSource().toString();
		Pattern p = Pattern.compile(".gif");
		Matcher m = p.matcher(s);
		while (m.find()) {
			int start = m.start();
			int end = m.end();
			String subs = s.substring(start - 2, end);
			String path = "face/" + subs;
			if(frame instanceof MainFrame)
				SocketUtil.println(Request.SEND_FACE_TO_ALL+":"+
								LoginFrame.getUsername()+":"+path);
			else{
				ToOneChatFrame tocf=(ToOneChatFrame)frame;
				StyledDocument doc = tocf.msgArea.getStyledDocument();
				SimpleAttributeSet attr = new SimpleAttributeSet();
				tocf.msgArea.setCaretPosition(doc.getLength());
				tocf.msgArea.insertIcon(
					new ImageIcon(GetImagePathUtil.getImageResource(path))
				);
				try {
					doc.insertString(doc.getLength(), "\n", attr);
				} catch (BadLocationException e1) {
					e1.printStackTrace();
				}finally{
					SocketUtil.println(Request.SEND_FACE_TO_ONE+":"+
							tocf.username+":"+path);
				}
			}
		}
		this.setVisible(false);
	}

}
