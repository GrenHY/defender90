package com.wangjin.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.wangjin.util.LocationUtil;
import com.wangjin.util.UIUtil;
/**
 * ��ӭҳ���UI
 * @author ��ʫ������
 * @QQ 824886693
 *
 */
public class Welcome extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	private JLabel label = new JLabel(UIUtil.MARIO);
	private int x = 270;
	private static final int Y=440;
	private static final int WIDTH= UIUtil.MARIO.getIconWidth();
	private static final int HEIGHT=UIUtil.MARIO.getIconHeight();
	/**
	 * ������
	 */
	public Welcome() {
		init();
		new Thread(this).start();
	}
	/**
	 * ��ʼ��FRAME
	 */
	private void init() {
		setIconImage(UIUtil.AUTHOR.getImage());
		setSize(UIUtil.WELBACK);
		setUndecorated(true);// �����ޱ߿򴰿�
		new LocationUtil(this);// �����϶���������
		setLocationRelativeTo(null);// ���ô������λ��
		label.setBounds(x, Y,WIDTH,HEIGHT);
		add(label);
		this.add(new WelPanel());
		setVisible(true);// ���ÿɼ���

	}
	/**
	 * setSize�����ط��������ݱ���ͼƬ��С�ı�Frame�Ĵ�С
	 * @param icon
	 */
	private void setSize(Icon icon) {
		this.setSize(icon.getIconWidth(), icon.getIconHeight());
	}

	@Override
	public void run() {
		try {
			while (x <= 600) {
				int num = new Random().nextInt(200) + 30;
				Thread.sleep(num);
				x += 30;
				label.setBounds(x,Y, WIDTH,HEIGHT);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			dispose();
			new LoginFrame().setVisible(true);
		}
	}

	public static void main(String[] args) {
		new Welcome().setVisible(true);
	}
	/**
	 * �ڲ��࣬Ӧ���ڻ�ӭҳ���panel
	 * @author ��ʫ������
	 * @QQ 824886693
	 *
	 */
	private class WelPanel extends JPanel implements Runnable{
		private static final long serialVersionUID = 1L;
		
		private static final int SNUM=15;
		
		int []sx=new int[SNUM];
		int []sy=new int[SNUM];
		/**
		 * ������
		 */
		public WelPanel() {
			for (int i = 0; i < sy.length; i++) {
				sx[i]=(int) (Math.random()*UIUtil.WELBACK.getIconWidth());
				sy[i]=(int) (Math.random()*UIUtil.WELBACK.getIconHeight());
			}
			repaint();
			new Thread(this).start();
		}

		@Override
		public void paint(Graphics g) {
			ImageIcon icon=UIUtil.SNOW;
			g.drawImage(UIUtil.WELBACK.getImage(), 0, 0, null);
			g.setColor(Color.BLUE);
			g.setFont(new Font("����", Font.BOLD,36));
			g.drawString("��ӭ����AUTHOR��������", 180, 100);
			for (int i = 0; i < SNUM; i++) 
				g.drawImage(icon.getImage(), sx[i], sy[i],this);
			
		}

		@Override
		public void run() {
			while(x<=600){
				for (int i = 0; i < SNUM; i++) {
					sy[i]+=10;
					if(sy[i]==HEIGHT)
						sy[i]=0;
				}
				try {
					Thread.sleep(120);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}finally{
					repaint();
				}
			}
		}
	}

}
