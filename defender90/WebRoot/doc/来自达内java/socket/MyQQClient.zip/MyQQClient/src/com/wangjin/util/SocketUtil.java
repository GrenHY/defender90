package com.wangjin.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
/**
 * �ͻ��˹�����
 * @author ��ʫ������
 * @QQ 824886693
 */
public class SocketUtil {
	private static Socket socket;
	private static PrintWriter out;
	private static BufferedReader br;

	/**
	 * ͨ���ⲿע��ip�����socket�ͻ���Զ������
	 * ��ʼ��Socket��out��br
	 * @param host
	 * @return socket
	 * @throws IOException
	 * @throws UnknownHostException
	 */
	public static Socket connect(String host) throws UnknownHostException,
			IOException {
		if (socket == null) {
			socket = new Socket(host, 9876);
			out = new PrintWriter(new OutputStreamWriter(
					socket.getOutputStream(), "UTF-8"), true);
			br = new BufferedReader(new InputStreamReader(
					socket.getInputStream(), "UTF-8"));
		}

		return socket;
	}

	/**
	 * ��ȡ����˷�������Ϣ
	 * 
	 * @return str
	 * @throws IOException
	 */
	public static String readLine() throws IOException {
		String str = br.readLine().trim();
		return str;
	}

	/**
	 * �����˷�����Ϣ
	 * 
	 * @param msg
	 */
	public static void println(String msg) {
		out.println(msg);
		out.flush();
	}

	/**
	 * �ر�socket�̷߳���
	 */
	public static void close() {
		try {
			if (socket != null) {
				out.close();
				br.close();
				socket.close();
			}
		} catch (IOException e) {
			System.out.println("����");
		}
	}
}
