package com.wangjin.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.Calendar;







//import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
//import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;


import com.wangjin.entity.Request;
import com.wangjin.util.ClientUtil;
import com.wangjin.util.GetImagePathUtil;
//import com.wangjin.thread.ClientThread;
import com.wangjin.util.LocationUtil;
import com.wangjin.util.OptionPane;
import com.wangjin.util.SocketUtil;
import com.wangjin.util.UIUtil;
/**
 * ˽��UI���
 * @author ��ʫ������
 * @QQ 824886693
 *
 */
public class ToOneChatFrame extends SuperFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	/**
	 * ����UI���
	 */
	JLabel touIcon, nameL, msgL, duiNameL, duiQQL;
	JButton close, send, fontbut, facebut, filebut, add, minn;
	JLabel selfIcon, selfName;
	public JLabel selfMsg;
	JLabel selfQQL;
	JScrollPane scrollPane;
	JButton friend1;
	int year, month, day, hour, min, sec;
	JScrollPane scrollPanea;
	JFileChooser chooser = new JFileChooser();
	
	private MainFrame mf;
	/**����û���*/
	public String username;

	private FaceFrame ff=null;
	
	private boolean isClick=false;
	/**
	 * ������
	 * @param username
	 * @param mf
	 */
	public ToOneChatFrame(String username,MainFrame mf) {
		this.username = username;
		this.mf=mf;
		String[]image=new String[]{
			"image/main1/main.png","image/main/tou.png",
			"image/main/send.png","image/main/fontbut.png",
			"image/main/facebut.png","image/main/filesend.png",
			"image/main1/selficon.png","image/main1/friend1.png",
			"image/main1/add.png","image/min.png","image/close.png"
		};
		int index=0;
		String[]arr=username.split(":");
		if(!LoginFrame.getUsername().equals(arr[0])){
			String s="";
			s=arr[0];
			arr[0]=arr[1];
			arr[1]=s;
			
		}
		this.setBounds(200, 200, 600, 500);
		this.setUndecorated(true);
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon(
			GetImagePathUtil.getImageResource(image[index++])));
		this.add(label);
		UIUtil.function(this);
		new LocationUtil(this);
		touIcon = new JLabel(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		touIcon.setBounds(16, 47, 53, 53);
		label.add(touIcon);
		nameL = new JLabel();
		nameL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		nameL.setBounds(81, 52, 100, 30);
		label.add(nameL);
		duiQQL = new JLabel();
		duiQQL.setBounds(150, 52, 50, 30);
		duiQQL.setFont(new Font("΢���ź�", Font.BOLD, 15));
		duiQQL.setForeground(Color.blue);
		label.add(duiQQL);
		msgL = new JLabel("");
		msgL.setFont(new Font("΢���ź�", Font.BOLD, 15));
		msgL.setBounds(81, 82, 200, 20);
		label.add(msgL);
		msgArea = new JTextPane();
		sendArea = new JTextPane();
		scrollPanea = new JScrollPane(msgArea);
		JScrollPane scrollPaneb = new JScrollPane(sendArea);

		scrollPanea.setBounds(6, 118, 410, 200);
		label.add(scrollPanea);

		scrollPaneb.setBounds(6, 349, 410, 100);
		label.add(scrollPaneb);
		send = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		send.setBounds(346, 460, 62, 23);
		label.add(send);
		fontbut = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		fontbut.setBounds(31, 326, 20, 18);
		label.add(fontbut);
		facebut = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		facebut.setBounds(66, 326, 20, 18);
		label.add(facebut);
		filebut = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		filebut.setBounds(105, 326, 20, 18);
		label.add(filebut);
		selfIcon = new JLabel(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		selfIcon.setBounds(437, 26, 54, 54);
		label.add(selfIcon);
		selfName = new JLabel(arr[0]);
		selfName.setBounds(503, 20, 150, 30);
		selfName.setFont(new Font("΢���ź�", Font.BOLD, 20));
		label.add(selfName);
		selfMsg = new JLabel(" to "+arr[1]);
		selfMsg.setBounds(503, 63, 200, 20);
		selfMsg.setFont(new Font("΢���ź�", Font.BOLD, 10));
		selfMsg.setForeground(Color.red);
		label.add(selfMsg);
		selfQQL = new JLabel();
		selfQQL.setBounds(503, 45, 200, 20);
		selfQQL.setFont(new Font("΢���ź�", Font.BOLD, 10));
		selfQQL.setForeground(Color.blue);
		label.add(selfQQL);
		duiNameL = new JLabel("");
		duiNameL.setBounds(371, 18, 50, 30);
		duiNameL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		duiNameL.setForeground(Color.blue);
		label.add(duiNameL);
		duiQQL = new JLabel("");
		duiQQL.setBounds(150, 52, 150, 30);
		duiQQL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		duiQQL.setForeground(Color.blue);
		label.add(duiQQL);
		// ���������б�
		JPanel friendPanel = new JPanel(new BorderLayout());
		friendPanel.setBackground(Color.white);

		friend1 = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		friend1.setBounds(0, 0, 51, 12);
		Insets space = new Insets(0, 0, 0, 0);
		friend1.setMargin(space);
		friend1.setContentAreaFilled(false);
		friend1.setBorderPainted(false);

		friendPanel.add(friend1, BorderLayout.NORTH);
		scrollPane = new JScrollPane(friendPanel);

		scrollPane.setBounds(432, 130, 157, 325);
		label.add(scrollPane);
		add = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		add.setBounds(570, 467, 12, 13);
		add.setContentAreaFilled(false);
		add.setBorderPainted(false);
		label.add(add);
		add.addActionListener(this);
		friend1.addActionListener(this);
		minn = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		minn.setBounds(550, 5, 14, 14);
		label.add(minn);
		minn.setContentAreaFilled(false);
		minn.setBorderPainted(false);
		close = new JButton(new ImageIcon(
				GetImagePathUtil.getImageResource(image[index++])
				));
		close.setBounds(570, 5, 14, 14);
		label.add(close);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		Calendar cal = Calendar.getInstance();
		year = cal.get(Calendar.YEAR);
		month = cal.get(Calendar.MONTH);
		day = cal.get(Calendar.DAY_OF_MONTH);
		send.addActionListener(this);
		close.addActionListener(this);
		minn.addActionListener(this);
		facebut.addActionListener(this);
		filebut.addActionListener(this);
		fontbut.addActionListener(this);
//		jlistClickItem();
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
	}

	/**
	 * ���Ӱ�ť����¼�
	 * ���ݵ��λ��ִ�в�ͬ�Ĺ���
	 * �ֱ��Ƿ�����Ϣ����С�����ر�
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == send) {
			sendMsgToOneMethod();
		} else if (e.getSource() == minn) {
			// ��С��
			this.setState(JFrame.ICONIFIED);
		} else if (e.getSource() == close) {
			this.dispose();
			mf.getCt().setTocf(null);
		} else if(e.getSource()==facebut){
			faceVisible(isClick);
		} else if(e.getSource()==fontbut){
			UIUtil.chooseFontAndColor(this);
		}else if(e.getSource()==filebut){
			chooser.showDialog(this, "�����ļ�");
			
		}else if(e.getSource()==chooser){
			if (JFileChooser.APPROVE_SELECTION.equals(e.getActionCommand())) {
				final File file = chooser.getSelectedFile();
				if (file != null) {
					
				}
			}
		}

	}
	private void faceVisible(boolean isClick) {
		if(!isClick){
			ff=new FaceFrame(this);
			ff.setVisible(true);
		}else{
			if(ff!=null)
				ff.dispose();
		}
	}
	/**
	 * send button ����
	 * 1.����ı��������������
	 * 2.����ı����� ����������������Ϳ���Ϣ�����򵯳���ʾ�� '������Ϣ����Ϊ��'
	 * 3.����Ϣ���ͣ������˷�����Ϣ
	 * 4.�ÿ�sendArea
	 */
	private void sendMsgToOneMethod(){
		String str = sendArea.getText().toString().trim();
		System.out.println("1" + str);
		if (str == null || "".equalsIgnoreCase(str)) {
			OptionPane.warningMsgOptionPane("AUTHOR��Mario������:"
					+ "������Ϣ����Ϊ��", this,
					UIUtil.MARIO);
			return;
		}
		SocketUtil
			.println(Request.SEND_MSG_TO_ONE + ":" + username + ":" + str);
		String[] arr = (Request.SEND_MSG_TO_ONE + ":" + username + ":" + str)
				.split(":");
		ClientUtil.functionSelfMsg(this, msgArea,
								arr[1] + "˵:\n" + arr[3] + "\n");
//		ClientUtil.functionToOneMsg(this, msgArea);
		sendArea.setText("");
	}
	/**���ù���������ײ�*/
	public void scro() {
		Point p = new Point();
		p.setLocation(0, msgArea.getStyledDocument().getLength());
		scrollPanea.getViewport().setViewPosition(p);
	}
//	public static void main(String[] args) {
//		new ToOneChatFrame("sss", null);
//	}

}
