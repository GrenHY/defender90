package com.wangjin.util;

//import java.awt.Font;
import java.awt.Color;
//import java.io.File;
//import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

//import com.wangjin.gui.LoginFrame;
import com.wangjin.gui.MainFrame;
import com.wangjin.gui.ToOneChatFrame;

/**
 * �ͻ��˹�����
 * 
 * @author ��ʫ������
 * @QQ 824886693
 */
public class ClientUtil {
	/** Ⱥ����Ϣ������ **/
	public static List<String> list = new ArrayList<String>();
	/** ˽����Ϣ������ **/
	public static List<String> toOneList = new ArrayList<String>();

	/**
	 * ����Ⱥ�Ļ�����Ϣ
	 * 
	 * @param mf
	 * @param area
	 * @throws BadLocationException
	 */
	public static void function(MainFrame mf, JTextPane area)
			throws BadLocationException {
		StyledDocument doc = area.getStyledDocument();
		SimpleAttributeSet attr = new SimpleAttributeSet();
		StyleConstants.setForeground(attr, Color.black);
		StyleConstants.setFontSize(attr, 20);
		JTextPane msgArea = area;
		String str = list.get(0);
		list.clear();
		msgArea.setCaretPosition(doc.getLength()); // ���ò���λ��
		try {
			doc.insertString(doc.getLength(), str, attr);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		mf.scro();
	}
	/**
	 * �������б����Ⱥ����Ϣ
	 * @param mf
	 * @param area
	 * @param icon
	 */
	public static void faceToAllMethod(MainFrame mf, JTextPane area, Icon icon) {
		StyledDocument doc = area.getStyledDocument();
		SimpleAttributeSet attr = new SimpleAttributeSet();
		StyleConstants.setForeground(attr, Color.black);
		StyleConstants.setFontSize(attr, 20);
		JTextPane msgArea = area;
		msgArea.setCaretPosition(doc.getLength()); // ���ò���λ��
		msgArea.insertIcon(icon);
		try {
			doc.insertString(doc.getLength(), "\n", attr);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		mf.scro();
	}

	/**
	 * ����˽�Ļ�����Ϣ
	 * 
	 * @param tocf
	 * @param area
	 */
	public static void functionToOneMsg(ToOneChatFrame tocf, JTextPane area) {
		StyledDocument doc = area.getStyledDocument();
		SimpleAttributeSet attr = new SimpleAttributeSet();
		// if(list.get(0).startsWith(LoginFrame.getUsername()))
		StyleConstants.setForeground(attr, Color.black);
		StyleConstants.setFontSize(attr, 20);
		JTextPane msgArea = area;
		String str = toOneList.get(0);
		toOneList.clear();
		msgArea.setCaretPosition(doc.getLength());
		try {
			doc.insertString(doc.getLength(), str, attr);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		tocf.scro();
	}
	/***
	 * �������б����˽����Ϣ
	 * @param mf
	 * @param area
	 * @param icon
	 */
	public static void faceToOne(ToOneChatFrame mf, JTextPane area, 
			Icon icon) {
		StyledDocument doc = area.getStyledDocument();
		SimpleAttributeSet attr = new SimpleAttributeSet();
		StyleConstants.setForeground(attr, Color.black);
		StyleConstants.setFontSize(attr, 20);
		JTextPane msgArea = area;
		msgArea.setCaretPosition(doc.getLength()); // ���ò���λ��
		msgArea.insertIcon(icon);
		try {
			doc.insertString(doc.getLength(), "\n", attr);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		mf.scro();
	}

	/**
	 * ˽�ĵ�ʱ�򣬰���Ϣ���͵��Լ��������
	 * 
	 * @param tocf
	 * @param area
	 * @param str
	 */
	public static void functionSelfMsg(ToOneChatFrame tocf, JTextPane area,
			String str) {
		StyledDocument doc = area.getStyledDocument();
		SimpleAttributeSet attr = new SimpleAttributeSet();
		// if(list.get(0).startsWith(LoginFrame.getUsername()))
		StyleConstants.setForeground(attr, Color.black);
		StyleConstants.setFontSize(attr, 20);
		JTextPane msgArea = area;
		msgArea.setCaretPosition(doc.getLength());
		try {
			doc.insertString(doc.getLength(), str, attr);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		tocf.scro();
	}
}
