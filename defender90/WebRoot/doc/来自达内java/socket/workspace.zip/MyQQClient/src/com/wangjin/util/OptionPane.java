package com.wangjin.util;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class OptionPane{
	public static void warningMsgOptionPane(String msg,JFrame frame){
		JOptionPane.showConfirmDialog(frame, msg, 
				"", JOptionPane.CANCEL_OPTION, JOptionPane.WARNING_MESSAGE,
				null);
	}
}
