package com.wangjin.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.reflect.Method;
import java.util.Calendar;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import com.wangjin.entity.Request;
import com.wangjin.thread.ClientThread;
import com.wangjin.util.ClientUtil;
import com.wangjin.util.LocationUtil;
import com.wangjin.util.SocketUtil;


public class MainFrame extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	DefaultListModel data;
	JLabel touIcon, nameL, msgL, duiNameL, duiQQL;
	public JTextPane msgArea, sendArea;
	JButton close, send, fontbut, facebut, filebut, add, minn;
	JLabel selfIcon, selfName;
	public JLabel selfMsg;
	JLabel selfQQL;
	JScrollPane scrollPane;
	JButton friend1;
	JList l;
	int year, month, day, hour, min, sec;
	Font font = new Font("����", Font.BOLD, 15);
	Color color = Color.red;
	JScrollPane scrollPanea;

	String username;
	public String num;
	public MainFrame(String username) {
		this.username=username;
		this.setBounds(200, 200, 600, 500);
		this.setUndecorated(true);
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon("image/main1/main.png"));
		this.add(label);

		// ���ô��屳��͸��
		try {
			Class<?> clazz = Class.forName("com.sun.awt.AWTUtilities");
			Method method = clazz.getMethod("setWindowOpaque",
					java.awt.Window.class, Boolean.TYPE);
			method.invoke(clazz, this, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		new LocationUtil(this);
		touIcon = new JLabel(new ImageIcon("image/main/tou.png"));
		touIcon.setBounds(16, 47, 53, 53);
		label.add(touIcon);
		nameL = new JLabel();
		nameL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		nameL.setBounds(81, 52, 100, 30);
		label.add(nameL);
		duiQQL = new JLabel();
		duiQQL.setBounds(150, 52, 50, 30);
		duiQQL.setFont(new Font("΢���ź�", Font.BOLD, 15));
		duiQQL.setForeground(Color.blue);
		label.add(duiQQL);
		msgL = new JLabel("");
		msgL.setFont(new Font("΢���ź�", Font.BOLD, 15));
		msgL.setBounds(81, 82, 200, 20);
		label.add(msgL);
		msgArea = new JTextPane();
		sendArea = new JTextPane();
		scrollPanea = new JScrollPane(msgArea);
		JScrollPane scrollPaneb = new JScrollPane(sendArea);

		scrollPanea.setBounds(6, 118, 410, 200);
		label.add(scrollPanea);

		scrollPaneb.setBounds(6, 349, 410, 100);
		label.add(scrollPaneb);
		send = new JButton(new ImageIcon("image/main/send.png"));
		send.setBounds(346, 460, 62, 23);
		label.add(send);
		fontbut = new JButton(new ImageIcon("image/main/fontbut.png"));
		fontbut.setBounds(31, 326, 20, 18);
		label.add(fontbut);
		facebut = new JButton(new ImageIcon("image/main/facebut.png"));
		facebut.setBounds(66, 326, 20, 18);
		label.add(facebut);
		filebut = new JButton(new ImageIcon("image/main/filesend.png"));
		filebut.setBounds(105, 326, 20, 18);
		label.add(filebut);
		selfIcon = new JLabel(new ImageIcon("image/main1/selficon.png"));
		selfIcon.setBounds(437, 26, 54, 54);
		label.add(selfIcon);
		selfName = new JLabel(username);
		selfName.setBounds(503, 20, 150, 30);
		selfName.setFont(new Font("΢���ź�", Font.BOLD, 20));
//		 selfName.setForeground(Color.blue);
		label.add(selfName);
		selfMsg = new JLabel("��ǰ��������:"+num);
		selfMsg.setBounds(503, 63, 200, 20);
		selfMsg.setFont(new Font("΢���ź�", Font.BOLD, 10));
		selfMsg.setForeground(Color.red);
		label.add(selfMsg);
		selfQQL = new JLabel();
		selfQQL.setBounds(503, 45, 200, 20);
		selfQQL.setFont(new Font("΢���ź�", Font.BOLD, 10));
		selfQQL.setForeground(Color.blue);
		label.add(selfQQL);
		duiNameL = new JLabel("");
		duiNameL.setBounds(371, 18, 50, 30);
		duiNameL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		duiNameL.setForeground(Color.blue);
		label.add(duiNameL);
		duiQQL = new JLabel("");
		duiQQL.setBounds(150, 52, 150, 30);
		duiQQL.setFont(new Font("΢���ź�", Font.BOLD, 20));
		duiQQL.setForeground(Color.blue);
		label.add(duiQQL);
		// ���������б�
		JPanel friendPanel = new JPanel(new BorderLayout());
		friendPanel.setBackground(Color.white);
		data = new DefaultListModel();
		l = new JList(data);

		friendPanel.add(l, BorderLayout.CENTER);

		friend1 = new JButton(new ImageIcon("image/main1/friend1.png"));
		friend1.setBounds(0, 0, 51, 12);
		Insets space = new Insets(0, 0, 0, 0);
		friend1.setMargin(space);
		friend1.setContentAreaFilled(false);
		friend1.setBorderPainted(false);

		friendPanel.add(friend1, BorderLayout.NORTH);
		scrollPane = new JScrollPane(friendPanel);

		scrollPane.setBounds(432, 130, 157, 325);
		label.add(scrollPane);
		add = new JButton(new ImageIcon("image/main1/add.png"));
		add.setBounds(570, 467, 12, 13);
		add.setContentAreaFilled(false);
		add.setBorderPainted(false);
		label.add(add);
		add.addActionListener(this);
		friend1.addActionListener(this);
		minn = new JButton(new ImageIcon("image/min.png"));
		minn.setBounds(550, 5, 14, 14);
		label.add(minn);
		minn.setContentAreaFilled(false);
		minn.setBorderPainted(false);
		close = new JButton(new ImageIcon("image/close.png"));
		close.setBounds(570, 5, 14, 14);
		label.add(close);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		Calendar cal = Calendar.getInstance();
		year = cal.get(Calendar.YEAR);
		month = cal.get(Calendar.MONTH);
		day = cal.get(Calendar.DAY_OF_MONTH);
		send.addActionListener(this);
		close.addActionListener(this);
		minn.addActionListener(this);
		facebut.addActionListener(this);
		filebut.addActionListener(this);
		fontbut.addActionListener(this);
		new ClientThread(this).start();
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				super.windowClosing(e);
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == send) {
			String str=sendArea.getText().toString();
			ClientUtil.list.add(username+"˵:"+str);
			SocketUtil.println(Request.SENDMSG+":"+username+":"+str);
			sendArea.setText("");
		} else if (e.getSource() == minn) {
			this.setState(JFrame.ICONIFIED);
		} else if (e.getSource() == close) {
			if(username!=null&&!("".equals(username))){
				SocketUtil.println(Request.EXIT+":"+username);
				SocketUtil.close();
			}
			System.exit(EXIT_ON_CLOSE);
		} 

	}


	// ���ù���������ײ�
	public void scro() {
		Point p = new Point();
		p.setLocation(0, msgArea.getStyledDocument().getLength());
		scrollPanea.getViewport().setViewPosition(p);
	}


	public static void main(String[] args) {
		new MainFrame("wj").setVisible(true);
	}

}
