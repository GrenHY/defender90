package com.wangjin.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.wangjin.entity.Request;
import com.wangjin.util.LocationUtil;
import com.wangjin.util.OptionPane;
import com.wangjin.util.SocketUtil;

public class LoginFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * ����UI���
	 */
	private JLabel iconL;
	private JTextField host, nickname;
	private JButton login, min, close;
	/**
	 * ����flag������UserName
	 */
	private static boolean flag=false;
	private static String username;
	public static MainFrame mf;
	public LoginFrame() {
		this.setBounds(400, 200, 300, 200);
		this.setUndecorated(true);
		new LocationUtil(this);
		JLabel label = new JLabel(new ImageIcon("image/login/main.png"));
		this.add(label);
		// ���ô��屳��͸��
		try {
			Class<?> clazz = Class.forName("com.sun.awt.AWTUtilities");
			Method method = clazz.getMethod("setWindowOpaque",
					java.awt.Window.class, Boolean.TYPE);
			method.invoke(clazz, this, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		createUi(label);
		this.setVisible(true);
		checkHost();
		checkNickName();
		mouseClick();
	}
	/**
	 * ����UI�����JLabel��λ��
	 * @param label
	 */
	private void createUi(JLabel label) {
		iconL = new JLabel(new ImageIcon("image/login/icon.png"));
		iconL.setBounds(27, 78, 53, 53);
		label.add(iconL);
		host = new JTextField();
		host.setBounds(95, 75, 185, 23);
		label.add(host);
		nickname = new JTextField();
		nickname.setBounds(95, 105, 185, 23);
		label.add(nickname);
		login = new JButton(new ImageIcon("image/login/loginbut.png"));
		login.setBounds(215, 162, 70, 27);
		label.add(login);
		min = new JButton(new ImageIcon("image/min.png"));
		min.setBounds(230, 13, 31, 31);
		label.add(min);
		min.setContentAreaFilled(false);
		min.setBorderPainted(false);
		close = new JButton(new ImageIcon("image/close.png"));
		close.setBounds(265, 13, 31, 31);
		label.add(close);
		close.setContentAreaFilled(false);
		close.setBorderPainted(false);
		
	}

	/**
	 * ���Ip��ַ�Ƿ���ȷ
	 */
	private void checkHost() {
		host.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String rex = "\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}";
				String host = LoginFrame.this.host.getText().toString();
				if (host.matches(rex) || "localhost".equalsIgnoreCase(host)) {
					System.out.println(host);
					try {
						SocketUtil.connect(host);
					} catch (Exception e1) {
						OptionPane.warningMsgOptionPane("ip��ַ����",
								LoginFrame.this);
						LoginFrame.this.host.setText("");
					}
				} else {
					OptionPane.warningMsgOptionPane("ip��д���󣬲����ϸ�ʽ",
							LoginFrame.this);
					LoginFrame.this.host.setText("");
				}
			}
		});
	}

	/**
	 * ͨ��ajax��֤nickname�Ƿ����
	 */
	private void checkNickName() {
		nickname.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String nickname = 
						LoginFrame.this.nickname.getText().toString();
				try {
					SocketUtil.println(Request.CHECK_NICKNAME + ":" + nickname);
					boolean flag = Boolean.valueOf(SocketUtil.readLine());
					checkNickName(flag);
				} catch (UnknownHostException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
	}

	/**
	 * �԰�ť������굥���¼�
	 */
	private void mouseClick() {
		login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!flag)
					return;
				LoginFrame.this.dispose();
				mf=new MainFrame(username);
				mf.setVisible(true);
			}
		});
		min.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LoginFrame.this.setState(LoginFrame.ICONIFIED);
			}
		});
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(username!=null&&!("".equals(username))){
					SocketUtil.println(Request.EXIT+":"+username);
					SocketUtil.close();
				}
				System.exit(EXIT_ON_CLOSE);
			}
		});
	}
	/**
	 * ����boolean�ж��ǳ��Ǵ���
	 * @param flag
	 */
	private void checkNickName(boolean flag) {
		if (!flag) {
			OptionPane.warningMsgOptionPane("�ǳ��Ѵ��ڣ���һ����", 
					LoginFrame.this);
			LoginFrame.this.nickname.setText("");
			return;
		}
		LoginFrame.flag=true;
		username=LoginFrame.this.nickname.getText().toString();
	}

	public static void main(String[] args) {
		LoginFrame f = new LoginFrame();
		f.setVisible(true);
	}

}
