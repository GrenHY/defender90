package com.wangjin.util;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextPane;

import com.wangjin.gui.MainFrame;
/**
 * �ͻ��˹�����
 * @author Administrator
 *
 */
public class ClientUtil {
	public static List<String>list=new ArrayList<String>();
	/**
	 * ����������Ϣ
	 * @param mf
	 * @param area
	 */
	public static void function(MainFrame mf, JTextPane area){
		StringBuffer buffer=new StringBuffer();
		JTextPane msgArea=area;
		for (int i = 0; i < list.size(); i++) {
			buffer.append(list.get(i)+"\n");
		}
		msgArea.setText(buffer.toString());
		mf.scro();
	}
}
