package com.wangjin.thread;

import java.io.IOException;

import com.wangjin.entity.Request;
import com.wangjin.gui.MainFrame;
import com.wangjin.util.ClientUtil;
import com.wangjin.util.SocketUtil;
/**
 * �ͻ����߳�
 * @author Administrator
 *
 */
public class ClientThread extends Thread {
	private MainFrame mf;
	public ClientThread(MainFrame mf) {
		this.mf=mf;
	}
	@Override
	public void run() {
		try {
			while (true) {
				String line = SocketUtil.readLine();
				String[] arr = line.split(":");
				int key = Integer.valueOf(arr[0]);
				String msg="";
				switch (key) {
				case Request.LOGIN:
					mf.num=arr[arr.length-1];
					mf.selfMsg.setText(mf.num);
					msg=arr[1];
					
					break;
				case Request.EXIT:
					mf.num=arr[arr.length-1];
					msg=arr[1];
					mf.selfMsg.setText(mf.num);
					break;
				case Request.SENDMSG:
					msg=arr[1]+"˵:"+arr[2];
					break;
				}
				if(!ClientUtil.list.contains(msg)&&
						!msg.endsWith("�ѵ�¼")&&
						!msg.endsWith("���˳�")){
					ClientUtil.list.add(msg);
				}
				ClientUtil.function(mf,mf.msgArea);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
