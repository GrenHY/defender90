package com.wangjin.thread;

import com.wangjin.gui.LoginFrame;

public class ClientMain {
	public static void main(String[] args) {
		new LoginFrame().setVisible(true);
	}
}
