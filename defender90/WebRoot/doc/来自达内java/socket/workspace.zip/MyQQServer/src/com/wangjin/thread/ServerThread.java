package com.wangjin.thread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

import com.wangjin.entity.Request;
/**
 * ������߳�
 * @author ��ʫ������
 *
 */
public class ServerThread extends Thread {
	private Map<String, Socket>sockets;
	private Socket socket;
	private PrintWriter out;
	private BufferedReader br;
	private List<String>users;
	
	public ServerThread(Map<String, Socket> sockets,List<String>users
			,Socket socket) {
		this.sockets = sockets;
		this.users=users;
		this.socket = socket;
	}


	@Override
	public void run() {
		try {
			br=new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			while (true) {
				String line=br.readLine();
				String[]arrs=line.split(":");
				int key=Integer.valueOf(arrs[0]);
				switch (key) {
				case Request.LOGIN:
					sendListToAll(key+":"+arrs[1]+"�ѵ�¼", users);
					break;
				case Request.EXIT:
					sockets.remove(arrs[1]);
					users.remove(arrs[1]);
					sendListToAll(key+":"+arrs[1]+"���˳�",users);
					break;
				case Request.SENDMSG:
					sendAll(key+":"+arrs[1]+":"+arrs[2]);
					break;
				case Request.CHECK_NICKNAME:
					if(sockets.containsKey(arrs[1])){
						sendCheckNameMsg(socket,false);
					}else{
						sockets.put(arrs[1], socket);
						sendCheckNameMsg(socket,true);
						users.add(arrs[1]);
					}
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * �����еĿͻ��˷�����Ϣ
	 * @param msg
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public void sendAll(String msg) 
			throws UnsupportedEncodingException, IOException{
		Iterator<String>it=sockets.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Socket s=sockets.get(key);
			PrintWriter out=new PrintWriter(new OutputStreamWriter(
					s.getOutputStream(),"UTF-8"),true);
			out.println(msg);
			out.flush();
		}
	}
	/**
	 * ��̶��ͻ��˷�����֤��Ϣ
	 * @param s
	 * @param flag
	 * @throws IOException
	 */
	public void sendCheckNameMsg(Socket s,Boolean flag) throws IOException{
		out=new PrintWriter(new OutputStreamWriter(s.getOutputStream()));
		out.println(flag.toString());
		out.flush();
	}
	/**
	 * ���û����Ϸ���ÿ���ͻ���
	 * @param users
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	public void sendListToAll(String str,List<String>users)
			throws UnsupportedEncodingException, IOException{
		JSONArray obj=JSONArray.fromObject(users);
		sendAll(str+":"+obj.toString()+":"+users.size());
	}
}
