package com.wangjin.thread;

import com.wangjin.util.ServerUtil;

public class Demo {
	public static void main(String[] args) {
	new ServerUtil();
	}
}
