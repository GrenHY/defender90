package com.wangjin.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.wangjin.thread.ServerThread;

public class ServerUtil {
	private ServerSocket server;
	
	private Map<String, Socket>sockets=new HashMap<String, Socket>();
	
	private ExecutorService threadPool;
	
	private	List<String>users=new Vector<String>();
	
	public ServerUtil() {
		try {
			server=new ServerSocket(80);
			threadPool=Executors.newFixedThreadPool(50);
			while(true){
				Socket socket=server.accept();
				ServerThread st=new ServerThread(sockets,users,socket);
				threadPool.execute(st);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
