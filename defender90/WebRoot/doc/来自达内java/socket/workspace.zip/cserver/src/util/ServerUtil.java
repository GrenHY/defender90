package util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import thread.ServerThread;
/**
 * ������������
 * @author Administrator
 *
 */
public class ServerUtil {
	private Map<Socket,String>client=new HashMap<Socket,String>();
	
	public ServerUtil() {
		createServer();
	}
	/**
	 * ��ʼ��������
	 */
	private void createServer() {
		try {
			ServerSocket socket=new ServerSocket(80);
			while(true){
				System.out.println("waiting for clients");
				Socket s=socket.accept();
				System.out.println("connected����");
				new ServerThread(s, client).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
