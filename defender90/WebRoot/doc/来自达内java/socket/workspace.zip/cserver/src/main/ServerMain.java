package main;

import util.ServerUtil;

public class ServerMain {
	public static void main(String[] args) {
		new ServerUtil();
	}
}
