package thread;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
/**
 * �������߳�
 * @author Administrator
 *
 */
public class ServerThread extends Thread {
	private Socket socket;
	
	private Map<Socket,String>clients;
	
	private BufferedReader br;
	
	private BufferedOutputStream myout;
	
	public ServerThread(Socket socket,Map<Socket,String>clients) {
		this.socket=socket;
		this.clients=clients;
	}
	@Override
	public void run() {
		try {
			br=new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			while (true) {
				String name=br.readLine();
				String line="";
				if(!clients.containsKey(socket)){
					line=name.split(":")[0];
					System.out.println(line);
					clients.put(socket, line);
				}else{
					line=clients.get(socket);
				}
				System.out.println("please enter to your password....");
				String pwd=new Scanner(System.in).nextLine();
				if("exit".equalsIgnoreCase(pwd)){
					sendAll(pwd);
					String str=br.readLine().trim();
					if("exited".equalsIgnoreCase(str)){
						System.out.println(str);
						clients.remove(socket);
						System.out.println("is socket already:"
						+clients.containsKey(socket));
					}	
				}else if("iwtgi".equalsIgnoreCase(pwd)){
					sendAll(pwd);
					getImage(line,br.readLine().split(":"));
					continue;
				}else{
					sendAll(pwd);
					String newLine=br.readLine().trim();
					System.out.println(newLine);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��������ͻ��˷�����Ϣ
	 * @param msg
	 * @throws IOException
	 */
	public void sendAll(String msg) throws IOException {
		Iterator<Socket> ss = clients.keySet().iterator();
		while (ss.hasNext()) {
			Socket s = ss.next();
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(s
					.getOutputStream()));
			pw.println(msg);
			pw.flush();
		}
	}
	/**
	 * ���շ���˴��ݵ�ͼƬ����Ϣ���ж�end����ĳ��ȣ����С�ڶ�����˵����������Ҫ����Ϣ
	 * ����RuntimeException�׳�������Ϣ��end[1]��ǵ��Ǵ���ͼƬ�ĳ��ȣ���ͨ��socket����
	 * ���ļ�����ҪDataIn/OutputStream��װ
	 * @param name
	 * @param end
	 * @throws IOException
	 */
	public void getImage(String name,String[] end) throws IOException{
		
		if(end.length<2)
			throw new RuntimeException();
		
		long l=Long.valueOf(end[1]);
		
		Iterator<Socket> ss = clients.keySet().iterator();
		
		while (ss.hasNext()) {
			Socket s = ss.next();
			BufferedInputStream bis=new BufferedInputStream(
					s.getInputStream());
			myout=new BufferedOutputStream(
							new FileOutputStream(name+".jpg"));
			DataInputStream in=new DataInputStream(bis);
			DataOutputStream out=new DataOutputStream(myout);
			byte[]bts=new byte[1024*10];
			int i=-1;
			long lg=0;
			while((i=in.read(bts))!=-1){
				out.write(bts);
				lg+=i;
				System.out.println("-----------------------------"+i);
				out.flush();
				if(l==lg)
					break;
			}
			System.out.println("-----------------------------------");
			out.close();
		}
	}
}
