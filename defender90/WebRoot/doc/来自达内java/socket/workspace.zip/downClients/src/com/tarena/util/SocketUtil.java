package com.tarena.util;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
/**
 * �ͻ��˹�����
 * @author Administrator
 *
 */
public class SocketUtil {
	private static Socket socket;
	private static BufferedReader br;
	private static PrintWriter out;
	private static DataInputStream dis;
	/**
	 * ��ʼ���ͻ��˷���
	 * @return
	 */
	public static Socket connect(){
		try {
			if(socket==null){
				socket=new Socket("localhost",9876);
				br=new BufferedReader(
					new InputStreamReader(
							socket.getInputStream()));
				out=new PrintWriter(
						new OutputStreamWriter(
						socket.getOutputStream()));
				dis=new DataInputStream(socket.getInputStream());
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return socket;
	}
	/**
	 * �����˷�����Ϣ
	 * @param msg
	 */
	public static void println(String msg){
		out.println(msg);
		out.flush();
	}
	/**
	 * ���շ������Ϣ
	 * @throws IOException 
	 */
	public static String readLine() throws IOException{
		String str=br.readLine().trim();
		return str;
	}
	/**
	 * ���շ���˴�����ļ�
	 * @throws IOException 
	 */
	public static void getDownLoadFile(String msg,long length) 
				throws IOException{
		DataOutputStream dos=new DataOutputStream(
				new BufferedOutputStream(
					new FileOutputStream(msg)));
		int i=0;
		byte[]bts=new byte[1024*10];
		long l=0;
		System.out.println("---------------��ʼ����---------------");
		while((i=dis.read(bts))!=-1){
			dos.write(bts, 0, i);
			dos.flush();
			l+=i;
			System.out.println("������"+l+"byte");
			if(l==length)
				break;
		}
		System.out.println("--------------�������--------------");
		dos.close();
	}
	/**
	 * �رտͻ���
	 * @throws IOException 
	 */
	public static void close() throws IOException{
		if(socket!=null){
			dis.close();
			br.close();
			out.close();
			socket.close();
		}
	}
	
	
}









