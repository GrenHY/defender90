package com.tarena.thread;

import java.io.IOException;
import java.util.Scanner;

import com.tarena.pojo.Request;
import com.tarena.util.SocketUtil;
/**
 * �ͻ����߳���
 * @author Administrator
 *
 */
public class ClientThread extends Thread {
	private String username;
	private String filename;
	
	public ClientThread() {
		SocketUtil.connect();
	}
	
	@Override
	public void run() {
		Scanner scan=new Scanner(System.in);
		try {
			SocketUtil.println(Request.LOGIN+"");
			while(true){
				String line=SocketUtil.readLine();
				String[]arr=line.split(":");
				int key=Integer.valueOf(arr[0]);
				switch (key) {
				case Request.LOGIN:
					username=arr[1];
					break;
				case Request.EXIT:
					SocketUtil.close();
					break;
				case Request.PASSWORD:
					filename=arr[1];
					break;
				case Request.DOWNLOAD:
					filename=arr[1];
					long length=Long.valueOf(arr[2]);
					SocketUtil.getDownLoadFile(filename, length);
					break;
				}
				System.out.println("����������:");
				printMsg(scan.nextLine().trim());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ������������Ϣ
	 * @param msg
	 */
	private void printMsg(String msg){
		String message="";
		if("exit".equalsIgnoreCase(msg))
			message=Request.EXIT+":"+username;
		else if("down".equalsIgnoreCase(msg))
			message=Request.DOWNLOAD+":"+username;
		else
			message=Request.PASSWORD+":"+username;
		SocketUtil.println(message);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}










