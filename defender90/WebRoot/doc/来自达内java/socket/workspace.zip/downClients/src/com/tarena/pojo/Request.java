package com.tarena.pojo;
/**
 * ��Ϣ��������
 * @author Administrator
 *
 */
public class Request {
	public static final int LOGIN=1;
	
	public static final int EXIT=2;
	
	public static final int PASSWORD=3;

	public static final int DOWNLOAD=4;
	
}
