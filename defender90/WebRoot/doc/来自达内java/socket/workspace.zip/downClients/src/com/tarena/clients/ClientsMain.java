package com.tarena.clients;

import com.tarena.thread.ClientThread;
/**
 * �ͻ�������
 * @author Administrator
 *
 */
public class ClientsMain {
	public static void main(String[] args) {
		new ClientThread().start();
	}
}








