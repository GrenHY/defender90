package thread;

import java.io.File;
import java.io.IOException;

import util.ConnectUtil;
import util.ImageUtil;
/**
 * �ͻ����߳���
 * @author Administrator
 */
public class ClientThread extends Thread{
	
	@Override
	public void run() {
		try {
			ConnectUtil.write(System.getProperty("user.name"));
			while(true){
				String str=ConnectUtil.readLine();
				System.out.println(str);
				if("iwtgi".equalsIgnoreCase(str)){
					ImageUtil.createImage();
					ConnectUtil.write(System.getProperty("user.name")+":"
							+ImageUtil.FILELENGTH);
					ConnectUtil.sendScreenImage();
				}else if("exit".equalsIgnoreCase(str)){
					ConnectUtil.write("exited");
					System.exit(0);
				}else{
					ConnectUtil.write("password error");
				}
				boolean flag=new File(ImageUtil.FILENAME).delete();
				System.out.println(System.getProperty("user.name"));
				System.out.println(flag);
				ConnectUtil.write(System.getProperty("user.name"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
