package main;

import thread.ClientThread;
import util.ConnectUtil;

public class ClientMain {
	public static void main(String[] args) {
		ConnectUtil.connect();
		new ClientThread().start();
	}
}
