package util;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
/**
 * ��ȡ��Ļ�ķ���
 * @author Administrator
 *
 */
public class ImageUtil {
	public static String FILENAME="image.jpg";
	public static long FILELENGTH;
	/**
	 * ����ͼƬ����������Ŀ��
	 * @throws Exception
	 */
	public static void createImage() throws Exception {
		// �˷�����������JdK1.6�����ϰ汾 ��ȡ��ǰ������Ļ
		Desktop.getDesktop();
		// .browse(new URL("http://www.baidu.com").toURI());
		Robot robot = new Robot();
		robot.delay(1000);
		Dimension d = new Dimension(
				Toolkit.getDefaultToolkit().getScreenSize());
		int width = (int) d.getWidth();
		int height = (int) d.getHeight();
		// ��������
		// robot.keyRelease(KeyEvent.VK_F11);
		robot.delay(2000);
		Image image = robot.createScreenCapture(new Rectangle(0, 0, width,
				height));
		BufferedImage bi = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		Graphics g = bi.createGraphics();
		g.drawImage(image, width/4, height/4, width / 2, height / 2, null);
		// ����ͼƬ
		File file=new File(FILENAME);
		ImageIO.write(bi, "jpg",file );
		FILELENGTH =file.length();
		System.out.println(FILENAME+" has be created");
	}
}
