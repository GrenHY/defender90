package util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
/**
 * �ͻ��˹�����
 * @author Administrator
 *
 */
public class ConnectUtil {
	private static Socket socket;
	
	private static PrintWriter out;
	
	private static BufferedReader br;
	
	private static OutputStream ops;
	/**
	 * �����ͻ���socket
	 * @return socket
	 */
	public static Socket connect(){
		try {
			if(socket==null){
					socket=new Socket("localhost", 80);
					out=new PrintWriter(
						new OutputStreamWriter(socket.getOutputStream()));
					br=new BufferedReader(
						new InputStreamReader(socket.getInputStream()));
					ops=socket.getOutputStream();
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return socket;
	}
	/**
	 * �������������Ϣ
	 * @param msg
	 */
	public static void write(String msg){
		out.println(msg);
		out.flush();
	}
	/**
	 * ��ȡ���������͵���Ϣ
	 * @return line
	 * @throws IOException
	 */
	public static String readLine() throws IOException{
		String line=br.readLine().trim();
		return line;
	}
	/**
	 * �����������ͼƬ
	 * @throws IOException
	 */
	public static void sendScreenImage() throws IOException{
		BufferedInputStream is=
			new BufferedInputStream(
				new FileInputStream(
						ImageUtil.FILENAME));
		BufferedOutputStream bos=new BufferedOutputStream(ops);
		DataOutputStream dops=new DataOutputStream(bos);
		DataInputStream bis=new DataInputStream(is);
		int i=0;
		byte[]bts=new byte[1024*10];
		while((i=bis.read(bts))!=-1){
			dops.write(bts, 0, i);
			dops.flush();
		}
		System.out.println("------------------------------------");
		bis.close();
	}
}
