package com.tarena.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.tarena.thread.ServerThread;

/**
 * ����˹�����
 * @author ��ʫ������  
 *
 */
public class ServerUtil {
	private ServerSocket server;
	private ExecutorService service;
	private Map<String, Socket>clients=
				new HashMap<String, Socket>();
	
	public ServerUtil() {
		createServer();
	}
	/**
	 * ����������
	 */
	private void createServer() {
		try {
			server=new ServerSocket(9876);
			service=Executors.newFixedThreadPool(5);
			while (true) {
				System.out.println("waiting for clients...");
				Socket socket=server.accept();
				System.out.println("connect....");
				Thread thread=new ServerThread(socket,clients);
				service.execute(thread);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}




















