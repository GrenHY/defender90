package com.tarena.server;

import com.tarena.util.ServerUtil;
/**
 * ���������
 * @author Administrator
 *
 */
public class ServerMain {
	public static void main(String[] args) {
		new ServerUtil();
	}
}
