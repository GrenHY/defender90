package com.tarena.thread;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Map;

import com.tarena.pojo.Request;
/**
 * ������߳�
 * @author Administrator
 *
 */
public class ServerThread extends Thread {

	private Socket socket;
	private DataInputStream dis;
	private DataOutputStream dos;
	private Map<String, Socket> clients;
	private BufferedReader br;
	private String username="uses";
	private static int num=0;
	private File file;
	
	public ServerThread(Socket socket,
			Map<String, Socket> clients) {
		this.socket = socket;
		this.clients = clients;
	}

	@Override
	public void run() {
		try {
			while (true) {
				br = new BufferedReader(new InputStreamReader(
						socket.getInputStream()));
				String line=br.readLine();
				String[]arr=line.split(":");
				int key=Integer.valueOf(arr[0]);
				switch (key) {
				case Request.LOGIN:
					String name=username+num++;
					clients.put(name, socket);
					String msg=key+":"+name;
					println(msg, socket);
					break;
				case Request.EXIT:
					Socket s=clients.get(arr[1]);
					msg=key+":"+"OK";
					println(msg, s);
					clients.remove(arr[1]);
					break;
				case Request.PASSWORD:
					s=clients.get(arr[1]);
					msg=key+":"+"slzxlm.zip";
					println(msg, s);	
					break;
				case Request.DOWNLOAD:
					s=clients.get(arr[1]);
					file=new File(
						"download"+File.separator+"slzxlm.zip");
					msg=key+":"+"slzxlm.zip:"+file.length();
					println(msg, s);
					upload(arr[1]);	
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * �ظ��ͻ���
	 * @throws IOException 
	 */
	public void println(String msg,Socket socket) 
									throws IOException{
		PrintWriter out=new PrintWriter(
				new OutputStreamWriter(
						socket.getOutputStream()));
		out.println(msg);
		out.flush();
	}
	/**
	 * ��ָ���û������ļ�
	 * @param name
	 * @throws IOException
	 */
	private void upload(String name) 
			throws IOException{
		Socket s=clients.get(name);
		dis=new DataInputStream(
				new BufferedInputStream(
					new FileInputStream(
					file)));
		dos=new DataOutputStream(new BufferedOutputStream(
					s.getOutputStream()
				));
		
		int i=0;
		byte[]bts=new byte[1024*10];
		
		while ((i=dis.read(bts))!=-1) {
			dos.write(bts,0,i);
			System.out.println(i);
			dos.flush();
		}
		System.out.println("----------------------");
		dis.close();
	}
}



















