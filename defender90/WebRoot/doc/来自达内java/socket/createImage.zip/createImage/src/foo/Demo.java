package foo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class Demo {
	public static void main(String[] args) 
									throws Exception{
//		Class<?>cla=String.class;
//		Class<?>cla1="sadasd".getClass();
//		
//		Class<?>cla2=Class.forName("java.lang.String");
//		cla2.newInstance();
		Class<?>clas=Class.forName("foo.Foo");
		clas.newInstance();
		
		Constructor<?>c=
				clas.getConstructor(new Class[]{String.class}); 
		Foo f=(Foo) c.newInstance(new Object[]{"=========="});
		f.getSome();
		
		Method[]methods=clas.getMethods();
		for (Method method : methods) {
			System.out.println(method.getName()+":"+
					method.getReturnType()+":"+
					method.getParameterTypes());
		}
		Method method=clas.getMethod("dosome",new Class[]{
				String.class,int.class,char.class
		});
		method.invoke(clas.newInstance(),
				new Object[]{"str",2,'a'});
		method=clas.getMethod("getSome",new Class[]{});
		method.invoke(clas.newInstance(), new Object[]{});
		
		
		method=clas.getDeclaredMethod("sum",new Class[]{
				int.class,char.class
		});
		method.setAccessible(true);
		
		int a=(Integer) method.invoke(clas.newInstance(), 
				new Object[]{1,'1'});
		System.out.println(a);
		
		clas=Thread.class;
		Field []fs=clas.getDeclaredFields();
		for (Field field : fs) {
			System.out.println(field.getName());
		}
	}
}





























