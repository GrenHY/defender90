package foo;

public class Foo {
	public Foo() {
		System.out.println("=====================");
	}
	public Foo(String str){
		System.out.println(str);
	}
	public void getSome(){
		System.out.println("----------");
	}
	public void dosome(String str,int num,char ch){
		System.out.println(str+num+ch);
	}
	private int sum(int a,char c){
		return a+c;
	}
}














