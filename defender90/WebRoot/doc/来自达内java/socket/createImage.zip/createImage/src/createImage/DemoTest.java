package createImage;

public class DemoTest {
	public static void main(String[] args) {
//		function(2, 10);
		System.out.println(System.getProperty("user.name"));
	}

	public static void function(int start, int length) {
		int n, i;
		for (n = start; n <= length; n++) {
			for (i = 2; i < n; i++) {
				if (n % i == 0)
					break;
			}
			if (i == n)
				System.out.println(n);
		}

	}
}
