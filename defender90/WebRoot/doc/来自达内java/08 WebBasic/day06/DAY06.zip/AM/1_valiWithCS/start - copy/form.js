﻿function validateUserName(txtObj){
	var reg = /^[a-zA-Z0-9_]{1,10}$/;
	var isRight = reg.test(txtObj.value);
	//if(!isRight)			//alert("10个字符以内的字母、数字和下划线的组合!");
}
function validatePwd(txtObj){
	var reg=/^\d{6}$/;
	var isRight=reg.test(txtObj.value);
	//if(!isRight)
}
