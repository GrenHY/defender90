﻿function calc(btnObj){
	//得到按钮旁边文本框的值
	var txtObj=
		btnObj.parentNode
		.getElementsByTagName('input')[1];
	var n=parseInt(txtObj.value);
	//btnObj.value: + -
	//-: 当n==1时，值始终为1
	txtObj.value= btnObj.value=='+'?n+1:n==1?1:n-1;
	//获得当前行的所有td
	var tds=btnObj.parentNode.parentNode
		.getElementsByTagName('td');
	/*取第2个td中的内容，和数量文本框中的值做乘法，
		结果放回第4个td。保留两位小数*/
	var price=parseFloat(tds[1].innerHTML);
	var subTotal=price*parseInt(txtObj.value);
	tds[3].innerHTML=subTotal.toFixed(2);
	/*总计：从第二行开始每行的最后一个td的值累加
		，结果放入最后一行的最后一个td中，保留2为小数*/
	//td:last-child——作为最后一个元素的td
	//获得#shoppingCart中所有作为最后一个子元素的td
	var subs=document.querySelectorAll(
			"#shoppingCart td:last-child");
	/*IE8:为每行最后td添加class="sub"
		document.querySelectorAll('.sub');*/
	 var total=0;
	 for(var i=1;i<subs.length-1;i++)
		 total+=parseFloat(subs[i].innerHTML);
	 subs[subs.length-1].innerHTML=total.toFixed(2);
}