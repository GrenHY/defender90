﻿/*onfocus时触发*/
function inputFocus(txtObj){
	/*一套样式被程序操作时，优先选择类选择器*/
	//当获得焦点时，穿txt_focus（className="txt_focus"）
	txtObj.className="txt_focus";
    //脱掉隐身斗篷
	/*向上：parentNode
	    向下：getElementsByTagName*/
	var div=txtObj.parentNode.parentNode
		         .getElementsByTagName("td")[2]
				 .getElementsByTagName("div")[0];
	alert(div.nodeName);
}
/*onblur时触发*/
function validateUserName(txtObj){
	//失去焦点时，脱掉衣服(className="")
	txtObj.className="";
	var reg = /^[a-zA-Z0-9_]{1,10}$/;
	var isRight = reg.test(txtObj.value);
	//if(!isRight)			//alert("10个字符以内的字母、数字和下划线的组合!");
}
function validatePwd(txtObj){
	var reg=/^\d{6}$/;
	var isRight=reg.test(txtObj.value);
	//if(!isRight)
}
