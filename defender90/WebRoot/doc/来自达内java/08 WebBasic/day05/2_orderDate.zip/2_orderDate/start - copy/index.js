/*凡是从页面上传入的内容，都是字符串类型*/
function calc(days){
	var n=parseInt(days);
	//获得当前日期
	var now=new Date();
	//怎么取出来，算完，怎么放回去
	var d=now.getDate(); //--5
	/*数值计算，注意+/-1修正*/
	d=d-n+1; //3
    //d+20-1;//火车票预售期
	/*setXXX方法会直接修改原对象
	    返回值为毫秒数*/
	var end=new Date();
	/*2014-11-5
		             |
		             3
				     0 --上个月最后一天
		             -1 -- 上个月倒数第二天*/
	end.setDate(d);
	/*Locale:当地时间
		Date:只显示日期部分
		Time:只显示时间部分*/
	alert("开始日期："+end.toLocaleDateString()+"\n"
		   +"截止日期："+now.toDateString());
}