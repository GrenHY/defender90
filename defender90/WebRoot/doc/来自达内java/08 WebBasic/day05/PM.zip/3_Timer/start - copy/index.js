﻿var timer;
/*定时器：*做什么事(function)*；何时开始做；何时停止*/
/*倒计时：计算倒计时；页面记载后开始；点按钮时停止*/
var calc=function (){
	var now=new Date();
	//18:00:00
	//17:59:59
	//16:13:51
	//  1:46:08
	//  -1:59:59
	var h=17-now.getHours();
	var m=59-now.getMinutes();
	var s=59-now.getSeconds();
	if(h<0) clearInterval(timer);
	else{
		var h1=document.querySelector('h1');
		/*innerHTML:开始标签到结束标签之间的所有文本*/
		h1.innerHTML=h+"小时"+m+"分"+s+"秒";
	}
}
/*页面加载后执行*/
window.onload=function(){
	//setInterval(做什么事,每隔多少毫秒);
	//此时已经开辟了新线程执行calc
	//返回1个整数，唯一标示1个子线程
    timer=setInterval(calc,1000);
}
function stopTimer(){
	 if(timer===undefined)
		//重新开始一个新线程
		timer=setInterval(calc,1000);
	else
		//关闭一个线程
		timer=clearInterval(timer);
		//timer=undefined
}
/*一次性计时器：*做什么事(function)*；何时开始做；何时停止*/
var timer1;
function myAlert(){
	alert("该起床了！");
	//实现重复启动闹钟
	timer1=undefined;
}
function startAlert(){
	if(timer1===undefined)
		/*setTimeout(做什么事,等待几毫秒)*/
		timer1=setTimeout(myAlert,5000);
	else
		/*取消等待*/
		timer1=clearTimeout(timer1);
}