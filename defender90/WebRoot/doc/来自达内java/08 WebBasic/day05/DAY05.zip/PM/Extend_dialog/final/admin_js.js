﻿function update(){
	var r=confirm("go on updating?");
	if(r) div=document.getElementById("result_info").style.display='block';
	return r;
}