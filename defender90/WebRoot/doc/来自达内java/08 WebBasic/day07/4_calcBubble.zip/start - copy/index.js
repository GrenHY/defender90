﻿window.onload=function(){
	var div=document.querySelector('div');
	div.onclick=calculate;
}
function calculate(evt){
	var e=evt||event;
	/*src: 最初点击的对象*/
	/*Firefox: target   IE:srcElement*/	
	var src=e.srcElement||e.target;//input
	//只有点在按钮(input)上才执行计算
	/*nodeName属性，返回的永远是大写字母*/
	if(src.nodeName=="INPUT"){
		var str=src.value;
		var txtObj = document.getElementById("txtData");
		switch(str){
		case "C":
			txtObj.value = "";
			break;
		case "=":
			var input = txtObj.value;
			if(input.length > 0)
				try{
					var result = eval(input);
					txtObj.value = result;
				}catch(error){
					txtObj.value = error;
				}
			break;
		default:
			txtObj.value += str;
			break;						
		}
	}
}