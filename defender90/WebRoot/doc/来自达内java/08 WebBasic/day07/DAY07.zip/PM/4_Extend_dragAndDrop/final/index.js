//两个数组分别用来保存参赛选手和志愿者
var racers=[];
var vols=[];
//分别用来保存放置参赛选手和志愿者的ul
var ulRacers;
var ulVols;
window.onload=function() {
	/*IE8的数组没有indexOf函数，所以必须在原型中自己定义
	  而FF和Chrome都是有的*/
	indexOf4IE8();		
	ulMembers=document.querySelector("#members");
	/*子元素大量事件相同时，尽量放在父元素中统一绑定事件*/
	ulMembers.ondragstart=handleDragStart;
	ulMembers.ondragend=handleDragEnd;
	ulRacers = document.querySelector("#racers");
	ulVols = document.querySelector("#vols");
	ulRacers.ondragover=handleDragOver;
	ulVols.ondragover=handleDragOver;
	ulRacers.ondragleave=handleDragLeave;
	ulVols.ondragleave=handleDragLeave;
	ulRacers.ondrop=handleDrop;
	ulVols.ondrop=handleDrop;
}
function handleDragStart(evt) {
	var e=evt||event;
	var src=e.srcElement||e.target;
	//IE中不支持自定义属性：data-xxx,只能用getAttribute读取
		//而其他浏览器可使用src.dataset.xxx方式访问
	var txt=src.getAttribute("data-age")+":"+src.innerHTML;
	//IE中setData方法只支持参数text，不能自定义
		//其他浏览器可自定义
	e.dataTransfer.setData("text",txt);
	ulRacers.className="validtarget";
	ulVols.className="validtarget";
}
function handleDragOver(evt) {
	var e=evt||event;
	/*dragover开始，就要打破浏览器对拖拽的默认限制
		而且还要阻止事件从当前ul冒泡到页面，避免遇到更多的限制*/
	e.cancelBubble=true;
	/*要求严格的浏览器如FF，要求必须带dataTransfer数据才可拖拽
	  所以，哪怕只是做最简单的拖拽也必须放入数据
	  否则，无法响应后续drop、dragend等事件*/
	/*IE8不支持preventDefault函数，只能使用returnValue=false
	  而FF和Chrome是支持的，所以需要区别对待*/
	if(e.preventDefault)
		e.preventDefault();
	else
		e.returnValue=false;
	var src=e.srcElement||e.target;
	src.className = "highlighted";
}

function handleDragLeave(evt) {
	var e=evt||event;
	var src=e.srcElement||e.target;
	src.className="validtarget";
}

function handleDrop(evt) {
	var e=evt||event;
	e.cancelBubble=true;
	if(e.preventDefault)
		e.preventDefault();
	else
		e.returnValue=false;
	var src=e.srcElement||e.target;	
	var txt = e.dataTransfer.getData("text");
	var arr=src.id=="racers"?racers:vols;
	if (arr.indexOf(txt)==-1){
		arr.push(txt);
		arr.sort();
		src.innerHTML="";
		for(var i in arr){
			/*重大解密，其实：
				for in不仅遍历数组元素，其实是遍历原型属性+元素
				所以如果前面在IE下为原型增加了indexOf方法
				此处的第一个i，就是这个方法的名字
				为了避免遍历到非数组元素，要使用hasOwnPropert(i)进行判断*/
			if(arr.hasOwnProperty(i)){
				var newli = document.createElement("li");
				newli.innerHTML=arr[i];
				src.appendChild(newli);
			}
		}/*其实，in的效率比普通for差，所以尽量少用*/
	}
}

function handleDragEnd() {
	ulRacers.className="";
	ulVols.className="";
}

function indexOf4IE8(){
	if(!Array.prototype.indexOf)
		Array.prototype.indexOf=function(elt){
			for(var i=0;i<this.length;i++)
				if(this[i]===elt)
					return i;
			return -1;
		};
}
