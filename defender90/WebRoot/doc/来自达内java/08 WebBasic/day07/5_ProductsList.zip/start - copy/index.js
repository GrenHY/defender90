﻿var table;//undefined
function addRow() {
	if(!table)//undefined-->false
		table=document.getElementById('table1');
	//添加新行
	var tr=table.insertRow(-1);
	//在新行对象中添加3个单元格
	var tdID=tr.insertCell(0);
	tdID.innerHTML=
		document.getElementById('txtID').value;
	var tdName=tr.insertCell(1);
	tdName.innerHTML=
		document.getElementById('txtName').value;
	var tdBtn=tr.insertCell(2);
	//第三个td中新建一个按钮，为按钮绑定事件
	var btn=document.createElement('input');
	//<input />
	btn.type="button";
	btn.value="删除";
	tdBtn.appendChild(btn);
	//<input type="button" value="删除"/>
	/*为按钮绑定事件*/
	btn.onclick=function(){
		//删除当前行
		//得到当前点击的行对象
		var tr=this.parentNode.parentNode;
		var r=confirm('是否删除：'+tr.cells[1].innerHTML+"?");
		if(r)
			//使用Table对象，删除tr
			table.deleteRow(tr.rowIndex);
	};
}