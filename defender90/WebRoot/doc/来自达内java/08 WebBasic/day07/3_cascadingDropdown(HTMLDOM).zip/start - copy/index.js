﻿//使用二维数组保存方向与课程之间的包含关系。第一项是默认项“请选择”。
//这里为了演示效果，我们特意将二维数组的顺序和"方向"下拉列表中的列表项顺序对应
var projectArray = new Array();
//对应"方向"下拉列表中的第一项
projectArray[0] = ["请选择"];  
//对应"方向"下拉列表中的第二项
projectArray[1] = ["请选择","CoreJava", "Oracle", "JSP", "JDBC"]; 
//对应"方向"下拉列表中的第三项
projectArray[2] = ["请选择","PS", "CSS"]; 
//对应"方向"下拉列表中的第四项
projectArray[3] = ["请选择","PHP", "MySql", "Jquery"];
			
function classChanged(selObj){
	/*select对象的selectedIndex: 选中项的下标*/
	var i=selObj.selectedIndex;
	/*获得对应子数组*/
	var classes=projectArray[i];
	/*清空第二个下拉列表中的项*/
	var classObj=document.getElementById('selProject');
	classObj.innerHTML="";
	/*遍历子数组，向classObj中逐项添加*/
	for(var i=0;i<classes.length;i++)
		//HTML DOM:简化了编程
		//缺点：只能完成特定功能
		classObj.add(new Option(classes[i],classes[i]));
		/*创建元素上半步：document.createElement('标签名')*/
		//标准DOM：支持所有元素，能完成所有功能
		//缺点：步骤繁琐
		/*createElement方法返回新创建的元素对象*/
		//<option></option>
		/*必要步骤：修改新元素的必要属性*/
		//<option>Oracle</option>
		/*下半步：父元素.appendChild(子元素)*/
}