﻿function displaySubMenu(li) { 
	var subMenu = li.getElementsByTagName("ol")[0]; 
	subMenu.style.display = "block"; 
} 
function hideSubMenu(li) { 
var subMenu = li.getElementsByTagName("ol")[0]; 
subMenu.style.display = "none"; 
} 