﻿//计算资产折旧
//得到录入的各项数值
//拼接结果字符串
//循环计算每年的折旧
	//每年的结果显示为一行
//计算资产折旧
function calculateDepreciation() {
	
}
