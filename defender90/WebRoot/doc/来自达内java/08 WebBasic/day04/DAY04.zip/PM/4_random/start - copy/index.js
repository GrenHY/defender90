﻿//得到随机数
function getRandomNumber() {
	
}