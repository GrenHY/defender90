package com.tarena.action;

import java.util.HashMap;
import java.util.Map;

import com.tarena.dao.CostDao;
import com.tarena.dao.CostDaoImpl;
import com.tarena.entity.Cost;

/**
 *	У���ʷ������Ƿ��ظ�
 */
public class CheckCostNameAction {

	private String name;
	
	private Map<String, Object> result = 
		new HashMap<String, Object>();

	public String execute() {
		CostDao dao = new CostDaoImpl();
		Cost cost = dao.findByName(name);
		if(cost == null) {
			//û������
			result.put("repeat", false);
			result.put("message", "�ʷ�����Ч.");
		} else {
			//������
			result.put("repeat", true);
			result.put("message", "�ʷ����Ѵ���.");
		}
		return "success";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, Object> getResult() {
		return result;
	}

	public void setResult(Map<String, Object> result) {
		this.result = result;
	}
	
}
