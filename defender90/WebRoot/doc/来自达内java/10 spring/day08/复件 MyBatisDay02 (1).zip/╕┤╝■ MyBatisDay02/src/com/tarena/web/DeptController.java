package com.tarena.web;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tarena.entity.Dept;
import com.tarena.entity.DeptMapper;

@Controller
@RequestMapping("/dept")
public class DeptController implements Serializable {
	
	@Resource
	private DeptMapper deptMapper;

	@RequestMapping("/list.form")
	public String list(ModelMap map){
		List<Dept> list = deptMapper.findAllDept();
		map.put("depts", list);
		return "list";
	}
}








