package com.tarena.test;

import java.io.Reader;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.tarena.entity.Dept;
import com.tarena.entity.DeptMapper;
import com.tarena.vo.DeptVO;

public class TestCase {
	//@Test
	public void testSqlSession() throws Exception{
		//��ȡ�����ļ�
		//java.io.Reader Ҳ���� new FileReader() 
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		//����SqlSession�Ĺ���
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		//����SqlSession 
		SqlSession session = factory.openSession();
		System.out.println(session);
		System.out.println(session.getConnection()
				.getMetaData().getDatabaseProductName());
		session.close();
	}
	
	//@Test
	public void testAddDept() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		Dept d = new Dept(null, "PHP��ѧ��", "���ݽ�");
		mapper.addDept(d);
		System.out.println(d); 
		session.commit();
		session.close();
	}
	
	//@Test
	public void testFindAll() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		List<Dept> list = mapper.findAllDept();
		for (Dept dept : list) {
			System.out.println(dept);
 		}
		session.commit();
		session.close();
	}
	//@Test
	public void testFindById() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		Dept dept=mapper.findDeptById(2);
		System.out.println(dept);
		session.commit();
		session.close();
	}
	//@Test
	public void testUpdateDept() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		Dept dept=mapper.findDeptById(2);
		System.out.println(dept);
		dept.setLoc("����");
		mapper.updateDept(dept);
		Dept d = mapper.findDeptById(2);
		System.out.println(d); 
		session.commit();
		session.close();
	}
	//@Test
	public void testDeleteDept() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		Dept dept=mapper.findDeptById(2);
		System.out.println(dept);
		mapper.deleteDept(dept);
		System.out.println(mapper.findAllDept()); 
		session.commit();
		session.close();
	}
	
	//@Test
	public void testFindValue() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		List<Map<String, Object>> list = mapper.findValue();
		for (Map<String, Object> vo : list) {
			System.out.println(vo.get("DNAME")+","+
					vo.get("LOC")); 
		}
		session.commit();
		session.close();
	}
	
	//@Test
	public void testFindValues() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		DeptMapper mapper = 
			session.getMapper(DeptMapper.class);
		List<DeptVO> list = mapper.findValues();
		for (DeptVO vo : list) {
			System.out.println(vo.getDname()+","+
					vo.getLoc()); 
		}
		session.commit();
		session.close();
	}
	//@Test
	public void testFindValues2() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		//ֱ��ִ��idΪfindValues ��SQL���
		List<DeptVO> list = 
			session.selectList("findValues");
		for (DeptVO vo : list) {
			System.out.println(vo.getDname()+","+vo.getLoc());
		}
		session.commit();
		session.close();
	}

	@Test
	public void testInsert2() throws Exception{
		Reader cfg = 
			Resources.getResourceAsReader("SqlMapConfig.xml");
		SqlSessionFactoryBuilder builder =
			new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = builder.build(cfg);
		SqlSession session = factory.openSession();
		Dept dept = new Dept(null, "Java��ѧ��", "������");
		session.insert("addDept", dept);
		System.out.println(dept); 
		System.out.println(
				session.selectList("findAllDept")); 
		session.commit();
		session.close();
	}

}











