package com.tarena.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.DeptDao;
import com.tarena.entity.Dept;
import com.tarena.entity.DeptMapper;

public class TestCase2 {
	//@Test
	public void testSqlSessionFactory(){
		String cfg = "spring-mvc.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		SqlSessionFactory factory = 
			ctx.getBean("sqlSessionFactory",
					SqlSessionFactory.class);
		SqlSession session = factory.openSession();
		Dept dept = session.selectOne("findDeptById",	6);
		System.out.println(dept); 
		session.close();
	}
	//@Test
	public void testDeptMapper(){
		String cfg = "spring-mvc.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		DeptMapper mapper = ctx.getBean(
				"deptMapper", DeptMapper.class);
		Dept d = mapper.findDeptById(6);
		System.out.println(d);
	}
	
	//@Test
	public void testDeptDao(){
		String cfg = "spring-mvc.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		DeptDao dao = ctx.getBean(
				"deptDao", DeptDao.class);
		Dept d = dao.add("IOS����", "�˼�԰"); 
		System.out.println(d);
	}
	
	//@Test
	public void testSort(){
		List<String> names = new ArrayList<String>();
		List<String> others = names;
		Collections.addAll(others, "Tom", "Jerry", 
				"Andy", "John", "Lee", "Nemo"); 
		System.out.println(names); 
		Collections.sort(others);
 		System.out.println(names); 
	}
	
	//@Test
	public void testDeptSort(){
		String cfg = "spring-mvc.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		DeptMapper mapper = ctx.getBean(
				"deptMapper", DeptMapper.class);
		List<Dept> all = mapper.findAllDept();
		System.out.println(all); 
		//ʵ�ֶԲ��� ���� ���ű�� ��������
		Collections.sort(all, new Comparator<Dept>() {
			public int compare(Dept o1, Dept o2) {
				//return -(o1.getDeptno() - o2.getDeptno());
				return o1.getDname()
					.compareToIgnoreCase(o2.getDname()); 
			}
		});
		for (Dept dept : all) {
			System.out.println(dept);
		}
	}
	
	@Test
	public void testRowBounds(){
		String cfg = "spring-mvc.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		SqlSession session = ctx.getBean(
				"sqlSession", SqlSession.class);
		RowBounds rowBounds = new RowBounds(4, 5);
		List<Dept> list = session.selectList(
				"findAllDept", null, rowBounds);
		for (Dept dept : list) {
			System.out.println(dept); 
		}
		session.close();
	}
}








