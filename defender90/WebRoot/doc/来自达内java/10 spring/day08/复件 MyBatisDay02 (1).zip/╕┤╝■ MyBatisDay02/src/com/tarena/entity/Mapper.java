package com.tarena.entity;

public @interface Mapper {

}
