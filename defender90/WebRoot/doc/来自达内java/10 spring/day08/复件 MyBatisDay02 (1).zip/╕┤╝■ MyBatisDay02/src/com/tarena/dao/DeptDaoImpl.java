package com.tarena.dao;

import java.io.Serializable;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.tarena.entity.Dept;

@Repository("deptDao")
public class DeptDaoImpl 
	implements DeptDao, Serializable{
	
	@Resource
	private SqlSessionTemplate sqlSessionTemplate;
	
	public void add(Dept dept) {
		sqlSessionTemplate.insert("addDept", dept);
	}
	public Dept add(String dname, String loc) {
		Dept dept = new Dept(null, dname, loc);
		sqlSessionTemplate.insert("addDept", dept);
		return dept;
	}
}




