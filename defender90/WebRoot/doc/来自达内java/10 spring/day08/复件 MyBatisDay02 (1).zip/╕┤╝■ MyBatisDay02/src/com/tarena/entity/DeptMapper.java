package com.tarena.entity;

import java.util.List;
import java.util.Map;

import com.tarena.vo.DeptVO;

/**
 * ����ʵ�����ɾ�Ĳ鷽�� 
 */
@Mapper 
public interface DeptMapper {
	void addDept(Dept dept);
	void deleteDept(Dept dept);
	void updateDept(Dept dept);
	Dept findDeptById(Integer deptno);
	List<Dept> findAllDept();
	List<Map<String,Object>> findValue();
	List<DeptVO> findValues();
}









