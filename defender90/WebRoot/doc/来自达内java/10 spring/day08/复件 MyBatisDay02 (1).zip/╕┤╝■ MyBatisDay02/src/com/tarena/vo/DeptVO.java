package com.tarena.vo;

import java.io.Serializable;

public class DeptVO 
	implements Serializable{
	private String dname;
	private String loc;
	
	public DeptVO() {
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}
	
}
