package com.tarena.entity;

import java.util.List;

/** ��װDept �� CRUD */
public interface DeptMapper {
	void addDept(Dept dept);
	void deleteDept(Dept dept);
	void updateDept(Dept dept);
	Dept findDeptById(Integer deptno);
	List<Dept> findDeptAll();
}



