package com.tarena.entity;

public class EmptyParamException extends Exception {

	public EmptyParamException() {
		// TODO Auto-generated constructor stub
	}

	public EmptyParamException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmptyParamException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EmptyParamException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
