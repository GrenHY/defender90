package com.tarena.test;

import org.springframework.stereotype.Component;

@Component
public class DataBean {
	@Override
	public String toString() {
		return "DataBean";
	}
}
