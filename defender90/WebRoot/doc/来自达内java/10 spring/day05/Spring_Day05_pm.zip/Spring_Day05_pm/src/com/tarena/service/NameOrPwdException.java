package com.tarena.service;

public class NameOrPwdException extends Exception {

	public NameOrPwdException() {
	}

	public NameOrPwdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NameOrPwdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NameOrPwdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
