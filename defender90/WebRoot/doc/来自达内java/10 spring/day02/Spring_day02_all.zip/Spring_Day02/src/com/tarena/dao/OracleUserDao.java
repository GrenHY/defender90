package com.tarena.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tarena.entity.User;
/** ��Oralce���ݿ���ʵ�������û��ķ��� */
public class OracleUserDao 
	implements UserDao, Serializable {
	
	private DataSource dataSource;
	/** �����ڼ���Springע��dataSource���� */
	public void setDataSource(
			DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public Integer add(User user) {
		String sql = "insert into user_robin (" +
				"id, name, pwd, phone) values (" +
				"seq_user_robin.nextval, ?,?,?) ";
		//������ӣ�ps���󶨲�����ִ�в�ѯ�������ID
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = 
				conn.prepareStatement(sql, 
						new String[]{"id"});
			ps.setString(1, user.getName());
			ps.setString(2, user.getPwd());
			ps.setString(3, user.getPhone());
			ps.executeUpdate();
			//��ȡ����ID
			ResultSet rs = ps.getGeneratedKeys();
			Integer id = null;
			while(rs.next()){
				id = rs.getInt(1);
			}
			rs.close();
			ps.close();
			return id;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			dataSource.close(conn);
		}
	}
}





