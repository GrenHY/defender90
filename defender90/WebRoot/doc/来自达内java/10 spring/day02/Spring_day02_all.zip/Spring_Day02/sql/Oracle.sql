create table user_robin(
  id number(4),
  name varchar2(30),
  pwd varchar2(30),
  phone varchar2(30)
);
create sequence seq_user_robin;


