package com.tarena.test;

public class MobilePhone {
	private String cpu;
	private String sim;
	private String sdCard;
	/** �����ֻ�ʱ���������CPU */
	public MobilePhone(String cpu) {
		this.cpu = cpu;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	public void setSdCard(String sdCard) {
		this.sdCard = sdCard;
	}
	public String toString() {
		return cpu+","+sim+","+sdCard;
	}
}
