package com.tarena.test;

import java.io.Serializable;

public class ExampleBean implements Serializable{
	public ExampleBean() {
		System.out.println("Create Example Bean");
	}
	public void init(){
		System.out.println("Call init()");
	}
	public void destroy(){
		System.out.println("Call destroy()");
	}
	public String toString() {
		return "exampleBean";
	}
}





