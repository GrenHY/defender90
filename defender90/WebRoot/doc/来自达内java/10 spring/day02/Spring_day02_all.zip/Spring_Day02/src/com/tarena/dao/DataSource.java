package com.tarena.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/** ���ݿ����ӹ��� */
public class DataSource implements Serializable {
	private String driver;
	private String url;
	private String user;
	private String pwd;
	
	public void setDriver(String driver) {
		try {
			//ע�����ݿ�������ע��һ�μ���
			Class.forName(driver);
			this.driver = driver;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public String getDriver() {
		return driver;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUrl() {
		return url;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getUser() {
		return user;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPwd() {
		return pwd;
	}
	
	public Connection getConnection() 
		throws SQLException{
		//��setDriver�������Ѿ�ע��������,�����ٴ�ע��
		Connection conn = 
			DriverManager.getConnection(url,user,pwd);
		return conn;
	}
	public void close(Connection conn){
		try {
			if(conn!=null){ conn.close();	}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}












