package com.tarena.test;

import java.io.IOException;
import java.util.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCase {
	//@Test
	public void testScope(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		//���е�Bean date1
		Date d1 = ctx.getBean("date1", Date.class);
		Date d2 = ctx.getBean("date1", Date.class);
		System.out.println(d1==d2);//true
		//ԭ�͵�Bean���� date2
		Date d3 = ctx.getBean("date2", Date.class);
		Date d4 = ctx.getBean("date2", Date.class);
		System.out.println(d3==d4);//false
	}
	
	//@Test
	public void testCode() throws IOException{
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Code c1=ctx.getBean("code", Code.class);
		Code c2=ctx.getBean("code", Code.class);
		System.out.println(c1==c2);//false
		c1.init();
		c2.init();
		System.out.println(c1);
		System.out.println(c2);
		c1.save();
		c2.save();
	}
	//@Test//�Զ�����Bean�������ڵĳ�ʼ������
	public void testCode2() throws IOException{
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Code c1=ctx.getBean("code2", Code.class);
		Code c2=ctx.getBean("code2", Code.class);
		System.out.println(c1==c2);//false
		System.out.println(c1);
		System.out.println(c2);
		c1.save();
		c2.save();
	}
	//@Test
	public void testInitDestroy(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx =
			new ClassPathXmlApplicationContext(cfg);
		//���� ��������init()
		ExampleBean bean = ctx.getBean(
				"exampleBean", ExampleBean.class);
		System.out.println(bean);
		//�ر�Spring����
		AbstractApplicationContext c=
			(AbstractApplicationContext)ctx;
		c.close();//�ر�Spring������
		//�ر�����ʱ�򣬻��Զ�����destroy����
	}
	
	@Test
	public void testLazyInit(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx =
			new ClassPathXmlApplicationContext(cfg);
		//��һ�ε��� getBean ����ʱ��ų�ʼ��
		//ExampleBean2 
		ExampleBean bean = ctx.getBean(
				"exampleBean2", ExampleBean.class);		
		ExampleBean b2 = ctx.getBean(
						"exampleBean2", ExampleBean.class);
		System.out.println(bean);
	}
}
















