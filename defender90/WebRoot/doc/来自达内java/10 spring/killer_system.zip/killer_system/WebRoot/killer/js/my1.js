$(function(){
	var flag={shuru:false};
	var rose=$("#killer").val()!='';
//	var msg=$("#msg").val();

	if(rose){
//		document.getElementById("myrose").style.display='block';
		$("#logined").html("WELCOME "+$("#killer").val());
	}
	$("#search").focus(function(){
		$(this).val("");
	});
	$("#cencel").click(function(){
		document.getElementById("regist").style.display="none";
	});
	$("#shuru").blur(function(){
		var s=$(this).val();
		if(s.trim().length>0){
			flag.shuru=true;
			return;
		}
		alert("Content cannot be null");	
		
		
	});
	$("#saveMsg").click(function(){
		var killer=$("#killer").val();
		if(killer==""){
			document.getElementById("login").style.display='block';
			$("#msg1").html("请登录");
			return false;
		}
		return flag.shuru;
	});
	$("#regist_a").click(function(){
		document.getElementById("login").style.display='none';
		document.getElementById("regist").style.display='block';
	});
	var reFlag={user:false,pwd:false,nick:false,mail:false};
	var reg = /^[\w]{6,12}$/;
	$("#reuser").blur(function(){
		var username=$(this).val();
		if(!username.match(reg)){
			$("#errorMsg").html("用户名输入不满足要求");
			return;
		}
		$.post("checkUsername.from",{"reuser":username},function(data){
			if(data!='true'){
				$("#errorMsg").html("用户名已占用");
				return;
			}
			$("#errorMsg").html("");
			reFlag.user=true;
		});
	});
	$("#repwd").blur(function(){
		var pwd=$(this).val();
		if(!pwd.match(reg)){
			$("#errorMsg").html("密码输入不符合要求");
			return;
		}
		$("#errorMsg").html("");
	});
	$("#repwd1").blur(function(){
		var pwd=$("#repwd").val();
		var pwd1=$(this).val();
		if(pwd!=pwd1){
			$("#errorMsg").html("两次密码输入不一致☞");
			return;
		}
		reFlag.pwd=true;
		$("#errorMsg").html("");
	});
	$("#renick").blur(function(){
		var regx=/^(\w{1,12})|([\u0391-\uFFE5]{1,12})$/;
		var nick=$(this).val();
		if(!nick.match(regx)){
			$("#errorMsg").html("昵称不符合输入要求");
			return;
		}
		$.post("checkNick.from",{"renick":nick},function(data){
			if(data!='true'){
				$("#errorMsg").html("昵称已占用");
				return;
			}
			$("#errorMsg").html("");
			reFlag.nick=true;
		});
	});
	$("#mail").blur(function(){
		var mail=$(this).val();
		var regMail= /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(!mail.match(regMail)){
			$("#errorMsg").html("邮箱格式不正确");
			return;
		}
		$.post("sendCode.from",{"mail":mail},function(data){
			var length=data.length;
			if(length!=5){
				$("#errorMsg").html(data);
				return;
			}
		});
	});
	$("#code").blur(function(){
		var code=$(this).val();
		var regCode=/^(\w{5})$/;
		if(!code.match(regCode)){
			$("#errorMsg").html("验证码格式不正确");
			return;
		}
		$.post("checkCode.from",{"code":code},function(data){
			var flagCode=(data=='true');
			if(flagCode){
				$("#errorMsg").html("");
				reFlag.mail=true;
				return;
			}
			$("#errorMsg").html("验证码输入错误");
		});
	});
	$("#regist_wrap_a").click(function(){
		document.getElementById("login").style.display='none';
		document.getElementById("regist").style.display='block';
	});
	$("#resub").click(function(){
		return reFlag.user&&reFlag.pwd&&reFlag.nick&&reFlag.mail;
	});
});
function isGood(id,str){
	$.post("ajax.from",{"id":id},function(data){
		document.getElementById(str).innerHTML="贊:"+data;
	});
}