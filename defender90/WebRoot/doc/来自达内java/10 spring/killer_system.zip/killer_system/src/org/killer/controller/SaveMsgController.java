package org.killer.controller;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.killer.entity.Killer;
import org.killer.entity.ReMsg;
import org.killer.service.MessageService;
import org.killer.service.ReMsgService;
import org.killer.vo.MessageVo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * ������������
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/killer")
public class SaveMsgController {
	@Resource
	private MessageService dao;
	@Resource
	private ReMsgService service;
	

	/**
	 * ��������
	 * @param session
	 * @param vo
	 * @param req
	 * @return
	 */
	@RequestMapping("/saveMsg")
	public String execute(HttpSession session,
			MessageVo vo,HttpServletRequest req){
		Killer k=(Killer) session.getAttribute("killer");
		System.out.println(k.getNickname());
		try {
			dao.save(k, vo);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link","tomain.from");
			return "redirect:toError.from";
		}
		return "redirect:tomain.from";
	}
	/**
	 * �����е������л���
	 * @param session
	 * @param remsg
	 * @param msgId
	 * @param req
	 * @return
	 */
	@RequestMapping("/saveReMsg")
	public String execute(HttpSession session,
			@RequestParam("shuru")String remsg
			,@RequestParam("msgId")int msgId, 
			HttpServletRequest req){
		Killer k=(Killer) session.getAttribute("killer");
		Integer page=(Integer) session.getAttribute("page");
		ReMsg msg=new ReMsg();
		msg.setNickname(k.getNickname());
		msg.setGood(0);
		msg.setReMsg(remsg);
		msg.setMsgId(msgId);
		msg.setDate(new SimpleDateFormat("yyyy-MM-dd hh-mm-ss").format(new Date()));
		System.out.println(msg.getDate());
		try {
			service.save(msg);
			dao.updateReply(msgId);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link","redirect:findMsg.from?id="+msgId+"&page="+page);
			return "redirect:toError.from";
		}
		return "redirect:findMsg.from?id="+msgId+"&page="+page;
	}
}
