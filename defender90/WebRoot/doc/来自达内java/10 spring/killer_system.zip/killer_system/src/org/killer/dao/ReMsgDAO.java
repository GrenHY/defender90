package org.killer.dao;

import java.sql.SQLException;
import java.util.List;

import org.killer.entity.ReMsg;
import org.killer.util.MyBatisDao;
import org.killer.vo.Page;

@MyBatisDao
public interface ReMsgDAO {
	List<ReMsg>findByPage(Page p) throws SQLException;
	
	List<ReMsg>findByMsgId(int MsgId)throws SQLException;
	
	void save(ReMsg r)throws SQLException;
	
	void updateGood(int id)throws SQLException;
	
	ReMsg findById(int id)throws SQLException;
}
