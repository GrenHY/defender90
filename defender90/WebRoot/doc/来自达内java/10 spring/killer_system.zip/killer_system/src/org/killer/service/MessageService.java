package org.killer.service;

import java.io.Serializable;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.killer.dao.MessageDAO;
import org.killer.entity.Killer;
import org.killer.entity.Message;
import org.killer.vo.MessageVo;
import org.killer.vo.Page;
import org.springframework.stereotype.Service;
/**
 * message ������
 * @author Administrator
 *
 */
@Service
public class MessageService implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Resource
	private MessageDAO dao;
	/**
	 * ������лظ���ҳ��
	 * @return
	 * @throws SQLException
	 */
	public Integer getTotalPage() throws SQLException{
		Integer totalPage;
		Integer total=dao.findAll().size();
		if(total==0)
			totalPage=1;
		else if(total%10==0)
			totalPage=total/10;
		else
			totalPage=total/10+1;
		return totalPage;
	}
	/**
	 * ��ҳ��ѯ
	 * @param page
	 * @return
	 * @throws SQLException
	 */
	public List<Message>findByPage(Page page) throws SQLException{
		List<Message>message=dao.findByPage(page);
		return message;
	}
	/**
	 * ����ģ����ѯ
	 * @param title
	 * @return
	 * @throws SQLException
	 */
	public List<Message> findContentByTitle(String title) throws SQLException{
		return dao.findContentByTitle(title);
	}
	/**
	 * ����ID��ѯ
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public Message findMsgById(int id) throws SQLException {
		return dao.findMsgById(id);
	}
	/**
	 * ������Ϣ
	 * @param k
	 * @param vo
	 * @throws SQLException
	 */
	public void save(Killer k,MessageVo vo) throws SQLException {
		Message m=new Message();
		m.setNickname(k.getNickname());
		m.setDate(new SimpleDateFormat("yyyy-MM-dd hh-mm-ss").
				format(new Date()));
		m.setTitle(vo.getMyTitle());
		m.setContent(vo.getShuru());
		dao.save(m);
	}
	/**
	 * ���»ظ�����
	 * @param msgId
	 * @throws SQLException
	 */
	public void updateReply(int msgId) throws SQLException {
		dao.updateReply(msgId);
	}
}
