package org.killer.service;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.killer.dao.ReMsgDAO;
import org.killer.entity.ReMsg;
import org.killer.vo.Page;
import org.springframework.stereotype.Service;
@Service
public class ReMsgService implements Serializable {
	private static final long serialVersionUID = 1L;
	@Resource
	private ReMsgDAO dao;
	
	public Integer getTotalPage(int id) throws SQLException{
		Integer totalPage=0;
		Integer total=dao.findByMsgId(id).size();
		if(total==0)
			totalPage=1;
		else if(total%10==0)
			totalPage=total/10;
		else
			totalPage=total/10+1;
		return totalPage;
	}

	public List<ReMsg> findByPage(Page p) throws SQLException {
		return dao.findByPage(p);
	}

	public void save(ReMsg msg) throws SQLException {
		dao.save(msg);
	}
}
