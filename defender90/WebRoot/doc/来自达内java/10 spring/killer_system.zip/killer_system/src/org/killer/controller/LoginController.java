package org.killer.controller;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.killer.entity.Killer;
import org.killer.service.KillerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
/**
 * ��¼��Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/killer")
@SessionAttributes(value={"msg","killer"})
public class LoginController {
	@Resource
	private KillerService service;
	/**
	 * ����ҳ��ĵ�¼Action
	 * @param model
	 * @param username
	 * @param password
	 * @return
	 */
	@RequestMapping("/login")
	public String execute(Model model,
			String username,String password,HttpServletRequest req){
		System.out.println(username+":"+password);
		Killer killer=null;
		try {
			killer=service.loginKiller(username, password);
			createKiller(model, killer, password);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", "tomain.from");
			return "redirect:toError.from";
		}
		return "redirect:tomain.from";
	}
	/**
	 * ����ϸ����ҳ���Action
	 * @param model
	 * @param username
	 * @param password
	 * @param id
	 * @return
	 */
	@RequestMapping("/login1")
	public String execute(Model model,String username,
						String password, int id,
						HttpSession session,HttpServletRequest req){
		System.out.println(username+":"+password);
		Killer killer=null;
		Integer page=(Integer) session.getAttribute("page");
		try {
			killer=service.loginKiller(username, password);
			createKiller(model,killer,password);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", 
					"redirect:findMsg.from?id="+id+"&page="+page);
			return "redirect:toError.from";
		}
		return "redirect:findMsg.from?id="+id+"&page="+page;
	}
	/**
	 * �ı��Killer����
	 * @param model
	 * @param k
	 * @param password
	 * @throws SQLException
	 */
	private void createKiller( Model model,Killer k,String password) throws SQLException{
//		if(1==1)
//			throw new SQLException();
		if(k==null){
			model.addAttribute("msg", "Username Error");
		}else{
			if(!k.getPassword().equals(password)){
				model.addAttribute("msg","password Error");
			}else{
				model.addAttribute("msg","welcome");
				model.addAttribute("killer", k);
			}
		}
	}
}
