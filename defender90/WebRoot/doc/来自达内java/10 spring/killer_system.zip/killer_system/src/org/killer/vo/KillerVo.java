package org.killer.vo;

import java.io.Serializable;

import org.killer.entity.Killer;
/**
 * Killer��value Object��
 * @author Administrator
 *
 */
public class KillerVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String reuser;
	private String repwd;
	private String renick;
	private String mail;
	
	public KillerVo() {}

	public String getReuser() {
		return reuser;
	}

	public void setReuser(String reuser) {
		this.reuser = reuser;
	}

	public String getRepwd() {
		return repwd;
	}

	public void setRepwd(String repwd) {
		this.repwd = repwd;
	}

	public String getRenick() {
		return renick;
	}

	public void setRenick(String renick) {
		this.renick = renick;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public Killer toKiller(){
		return new Killer(this.getReuser(),this.getRepwd(),
				this.getRenick(),this.getMail());
	}
	
}
