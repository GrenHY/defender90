package org.killer.service;

import java.sql.SQLException;

import javax.annotation.Resource;

import org.killer.dao.KillerDAO;
import org.killer.entity.Killer;
import org.killer.vo.KillerVo;
import org.springframework.stereotype.Service;
/**
 * Killer�ķ�����
 * @author Administrator
 *
 */
@Service
public class KillerService {
	@Resource
	private KillerDAO dao;
	
	public Killer saveService(KillerVo vo) throws SQLException{
		Killer killer=vo.toKiller();
		dao.save(killer);
		return killer;
	}
	
	public Killer loginKiller(String username,String password)
			throws SQLException{
		Killer killer=dao.findByUsername(username);
		return killer;
	}
	
	public boolean ajaxFindByName(String username)throws SQLException{
		Killer killer=dao.findByUsername(username);
		return killer==null;
	}
	public boolean ajaxFindByNickName(String nickname)throws SQLException{
		Killer killer=dao.findByNickname(nickname);
		return killer==null;
	}
}
