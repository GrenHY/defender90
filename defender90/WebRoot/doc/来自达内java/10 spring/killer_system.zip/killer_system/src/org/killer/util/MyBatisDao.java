package org.killer.util;
/**
 * ɨ��MyBatis�Ľӿ�
 * @author Administrator
 *
 */
public @interface MyBatisDao {

}
