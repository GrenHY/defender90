package org.killer.vo;

import java.io.Serializable;
/**
 * Message��value Object
 * @author Administrator
 *
 */
public class MessageVo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String myTitle;
	private String shuru;
	
	public MessageVo() {
	}

	public String getMyTitle() {
		return myTitle;
	}

	public void setMyTitle(String myTitle) {
		this.myTitle = myTitle;
	}

	public String getShuru() {
		return shuru;
	}

	public void setShuru(String shuru) {
		this.shuru = shuru;
	}
	
	
}
