package org.killer.controller;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.killer.entity.Killer;
import org.killer.service.KillerService;
import org.killer.vo.KillerVo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
/**
 * ���暢����Ϣ
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/killer")
@SessionAttributes("killer")
public class SaveKillerController {
	@Resource
	private KillerService service;
	/**
	 * ������]����Ϣ
	 * @param model
	 * @param username
	 * @param password
	 * @param nickname
	 * @return
	 */
	@RequestMapping("/saveKiller")
	public String execute(Model model,
			KillerVo vo,HttpServletRequest req){
		Killer killer;
		try {
			killer = service.saveService(vo);
			model.addAttribute("killer", killer);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", "tomain.from?page=1");
			return "redirect:toError.from";
		}
		return "redirect:tomain.from";
	}
	/**
	 * ����ϸҳע���û�
	 * @param model
	 * @param username
	 * @param password
	 * @param nickname
	 * @param id
	 * @return
	 */
	@RequestMapping("/saveKiller1")
	public String execute(Model model,
			KillerVo vo,
			int reid,HttpSession session,HttpServletRequest req){
		Integer page=(Integer) session.getAttribute("page");
		try {
			Killer killer=service.saveService(vo);
			model.addAttribute("killer", killer);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", 
					"findMsg.from?id="+reid+"&page="+page);
			return "redirect:toError.from";
		}
		return "redirect:findMsg.from?id="+reid+"&page="+page;
	}
	
}
