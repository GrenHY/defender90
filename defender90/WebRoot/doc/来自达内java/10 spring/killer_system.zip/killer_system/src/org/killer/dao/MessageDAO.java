package org.killer.dao;

import java.sql.SQLException;
import java.util.List;

import org.killer.entity.Message;
import org.killer.util.MyBatisDao;
import org.killer.vo.Page;

@MyBatisDao
public interface MessageDAO {
	List<Message>findAll()throws SQLException;
	
	List<Message>findByPage(Page p)throws SQLException;
	
	List<Message> findContentByTitle(String title)throws SQLException;
	
	void updateReply(int id)throws SQLException;
	
	void save(Message m)throws SQLException;

	Message findMsgById(int id)throws SQLException;
}
