package org.killer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * �������ҳ��Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/killer")
public class MainController {
	@RequestMapping("tomain")
	public String execute(){
		return "redirect:main.from?page=1";
	}
	/**
	 * ����Error����
	 * @return
	 */
	@RequestMapping("toError")
	public String executeError(){
		return "error";
	}
}
