package org.killer.controller;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.killer.entity.Message;
import org.killer.service.MessageService;
import org.killer.vo.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@RequestMapping("/killer")
@SessionAttributes(value={"msg","message","page","totalPage"})
public class ToMainController {
	@Resource
	private MessageService service;
	@RequestMapping("/main")
	public String execute(Model model,@RequestParam("page") Integer page,
			HttpServletRequest req){
		if(page==null)
			page=0;
		int begin=(page-1)*10;
		try {
			Integer totalPage=service.getTotalPage();
			List<Message>message=service.findByPage(new Page(begin,10));
			model.addAttribute("message", message);
			model.addAttribute("msg","welcome");
			model.addAttribute("page", page);
			model.addAttribute("totalPage", totalPage);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link","tomain.from");
			return "redirect:toError.from";
		}
		return "main";
	}
	
}
