package org.killer.vo;
/**
 * page��Ϊ�˷�ҳ��ѯ������
 * @author Administrator
 *
 */
public class Page {
	private Integer begin;
	private Integer length=10;
	private String title;
	private Integer msgId;
	public Page() {}

	public Page(Integer begin, Integer length) {
		super();
		this.begin = begin;
		this.length = length;
	}

	public Page(Integer begin, Integer length, String title) {
		this(begin, length);
		this.title = title;
	}

	public Integer getBegin() {
		return begin;
	}

	public void setBegin(Integer begin) {
		this.begin = begin;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getMsgId() {
		return msgId;
	}

	public void setMsgId(Integer msgId) {
		this.msgId = msgId;
	}
	
	
}
