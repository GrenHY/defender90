package org.killer.controller;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.killer.dao.ReMsgDAO;
import org.killer.service.KillerService;
import org.killer.util.CreateCodeUtil;
import org.killer.util.CreateMailUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
@Controller
@RequestMapping("/killer")
@SessionAttributes("code")
/**
 * SpringMvc��ajax��֤
 * @author Administrator
 *
 */
public class AjaxController {
	@Resource
	private ReMsgDAO dao;
	
	@Resource
	private KillerService service;
	public ReMsgDAO getDao() {
		return dao;
	}
	public void setDao(ReMsgDAO dao) {
		this.dao = dao;
	}
	/**
	 * ���޹���ajax
	 * @param id
	 * @return
	 */
	@RequestMapping("/ajax")
	@ResponseBody
	public String execute(@RequestParam("id")int id){
		int goodNo=0;
		try {
			dao.updateGood(id);
			goodNo=dao.findById(id).getGood();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ""+goodNo;
	}
	/**
	 * ע���û���ajax��֤
	 * @param username
	 * @return
	 */
	@RequestMapping("/checkUsername")
	@ResponseBody
	public String checkUsername(@RequestParam("reuser")String username
			,HttpServletRequest req){
		boolean b;
		try {
			b = service.ajaxFindByName(username);
			return String.valueOf(b);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link","tomain.from");
			return "redirect:toError.from";
		}
	}
	/**
	 * ajax��֤nickname
	 * @param nickname
	 * @param req 
	 * @return
	 */
	@RequestMapping("/checkNick")
	@ResponseBody
	public String checkNick(@RequestParam("renick")String nickname, HttpServletRequest req){
		boolean b;
		try {
			b = service.ajaxFindByNickName(nickname);
			return String.valueOf(b);
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link","tomain.from");
			return "redirect:toError.from";
		}
	}
	/**
	 * ͨ��ajax����ϵͳ�ʼ�
	 * @param model
	 * @param mail
	 * @return
	 */
	@RequestMapping("/sendCode")
	@ResponseBody
	public String execute(Model model,@RequestParam("mail")String mail){
		String code=CreateCodeUtil.createCode();
		model.addAttribute("code", code);
		try {
			CreateMailUtil.sendTextEmail(mail, "�����֤��Ϊ:"+code+",����գ���");
		} catch (Exception e) {
			e.printStackTrace();
			return "ϵͳ��æ�����Ժ󡣡�������";
		}
		return code;
	}
	/**
	 * ͨ��ajax��֤ ��֤���Ƿ���ȷ
	 * @param session
	 * @param code
	 * @return
	 */
	@RequestMapping("/checkCode")
	@ResponseBody
	public String execute(HttpSession session,@RequestParam("code")String code){
		String code1=(String) session.getAttribute("code");
		if(code1.equalsIgnoreCase(code))
			return "true";
		return "false";
	}
}
