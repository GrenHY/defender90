package org.killer.util;

import java.util.Random;
/**
 * ������֤��
 * @author Administrator
 *
 */
public class CreateCodeUtil {
	public static String createCode(){
		String str="QWERTYUPASDFGHJKLZXCVBNM23456789";
		StringBuilder sb=new StringBuilder();
		for (int i = 0; i < 5; i++) {
			sb.append(str.charAt(new Random().nextInt(str.length())));
		}
		System.out.println(sb.toString());
		return sb.toString();
	}
}
