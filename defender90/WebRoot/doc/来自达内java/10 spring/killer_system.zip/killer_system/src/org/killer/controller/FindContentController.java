package org.killer.controller;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.killer.entity.Message;
import org.killer.entity.ReMsg;
import org.killer.service.MessageService;
import org.killer.service.ReMsgService;
import org.killer.vo.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
/**
 * ��ѯ���ӵ�Controller
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/killer")
@SessionAttributes(value={"message","perMsg","reMsgs","totalPage"})
public class FindContentController {
	@Resource
	private MessageService service;
	@Resource
	private ReMsgService rmservice; 
	/**
	 * �����ı������������ı�������ģ����ѯ����
	 * @param title
	 * @param model
	 * @return
	 */
	@RequestMapping("/findContent")
	public String execute(@RequestParam("search")String title,
			Model model,HttpServletRequest req){
		title="%"+title+"%";
		List<Message> msg;
		try {
			msg = service.findContentByTitle(title);
			model.addAttribute("message",msg);
			return "main";
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", "tomain.from");
			return "redirect:toError.from";
		}
	}
	/**
	 * ���ݵ����title�����ӵ���ϸ����
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping("/findMsg")
	public String execute(@RequestParam("id")int id,Model model,
			@RequestParam("page")Integer page,HttpServletRequest req){
		System.out.println(id+"--------------------------------------------");
		int begin=(page-1)*10;
		Page p=new Page(begin, 10);
		p.setMsgId(id);
		try {
			Message msg=service.findMsgById(id);
			List<ReMsg>reMsgs=rmservice.findByPage(p);
			Integer totalPage=rmservice.getTotalPage(id);
			System.out.println(reMsgs);
			model.addAttribute("perMsg",msg);
			model.addAttribute("reMsgs", reMsgs);
			model.addAttribute("page",page);
			model.addAttribute("totalPage",totalPage);
			return "per";
		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("link", "tomain.from");
			return "redirect:toError.from";
		}
	}
}
