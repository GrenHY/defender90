package org.killer.dao;

import java.sql.SQLException;

import org.killer.entity.Killer;
import org.killer.util.MyBatisDao;
@MyBatisDao
public interface KillerDAO {
	Killer findByUsername(String username)throws SQLException;
	
	void save(Killer k)throws SQLException;
	
	Killer findByNickname(String nickname)throws SQLException;
}
