package com.tarena.test;

public class DemoObj {
	public String getEname(){
		return "����͢";
	}
}

