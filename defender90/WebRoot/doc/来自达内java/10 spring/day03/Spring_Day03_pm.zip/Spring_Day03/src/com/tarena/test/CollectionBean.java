package com.tarena.test;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionBean implements Serializable {
	private List<Integer> scores;
	private List<Date> dateList;
	private Set<String> cities;
	// key=������value=�绰
	private Map<String, String> contacts;
	private Map<String, Date> date;
	private Properties config;
	public List<Integer> getScores() {
		return scores;
	}
	public void setScores(List<Integer> scores) {
		this.scores = scores;
	}
	public List<Date> getDateList() {
		return dateList;
	}
	public void setDateList(List<Date> dateList) {
		this.dateList = dateList;
	}
	public Set<String> getCities() {
		return cities;
	}
	public void setCities(Set<String> cities) {
		this.cities = cities;
	}
	public Map<String, String> getContacts() {
		return contacts;
	}
	public void setContacts(Map<String, String> contects) {
		this.contacts = contects;
	}
	public Map<String, Date> getDate() {
		return date;
	}
	public void setDate(Map<String, Date> date) {
		this.date = date;
	}
	public Properties getConfig() {
		return config;
	}
	public void setConfig(Properties config) {
		this.config = config;
	}
	@Override
	public String toString() {
		return "CallectionBean [scores=" + scores + ", dateList=" + dateList
				+ ", cities=" + cities + ", contects=" + contacts + ", date=" + date
				+ ", config=" + config + "]";
	}
	
}





