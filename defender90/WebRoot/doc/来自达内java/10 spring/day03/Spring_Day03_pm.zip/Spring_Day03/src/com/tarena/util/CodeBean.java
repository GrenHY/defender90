package com.tarena.util;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.imageio.ImageIO;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope("prototype") 
@Component 
public class CodeBean //codeBean
	implements Serializable {
	private String code;
	private BufferedImage image;
	
	/** ���������֤���ͼƬ */
	@PostConstruct //���������Ժ��������÷���
	public void genCode(){
		StringBuilder buf = new StringBuilder();
		String src = "ABCDEFGHIJKMNPX3abc";
		Random r = new Random();
		buf.append(
				src.charAt(r.nextInt(src.length())));
		buf.append(
				src.charAt(r.nextInt(src.length())));
		buf.append(
				src.charAt(r.nextInt(src.length())));
		buf.append(
				src.charAt(r.nextInt(src.length())));
		code = buf.toString();
		image = createImage();
	}
	private BufferedImage createImage() {
		image = new BufferedImage(
				80, 40, BufferedImage.TYPE_4BYTE_ABGR);
		Graphics2D g = image.createGraphics();
		g.setColor(Color.white);
		g.fillRect(0, 0, 80, 40);
		g.setColor(Color.blue);
		g.drawString(code, 5, 30);
		File file = new File(code+".png");
		try {
			ImageIO.write(image, "png", file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return image;
	}
	/** ��֤��֤�� */
	public boolean check(String code){
		return this.code.equalsIgnoreCase(code);
	}
	public String getCode() {
		return code;
	}
	public BufferedImage getImage() {
		return image;
	}	
	
	
}







