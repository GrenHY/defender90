package com.tarena.test;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.DataSource;

public class TestCase {
	//@Test
	public void testDemoBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		DemoBean bean = ctx.getBean(
				"demoBean", DemoBean.class);
		System.out.println(bean); 
	}
	//@Test
	public void testObjDemoBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		ObjDemoBean bean = 
			ctx.getBean("obj", ObjDemoBean.class);
		System.out.println(bean);
	}
	
	//@Test
	public void testCollectionBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		CollectionBean bean = ctx.getBean(
				"colBean", CollectionBean.class);
		System.out.println(bean);
		List<Date> list = bean.getDateList();
		System.out.println(
				list.getClass().getName());
		
	}
	//@Test
	public void testRefColBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		CollectionBean bean = ctx.getBean(
				"demo2", CollectionBean.class);
		System.out.println(bean);
	}

	//@Test
	public void testDemo(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Demo demo = ctx.getBean("demo", Demo.class);
		System.out.println(demo);
	}
	//@Test
	public void testProperties(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Properties jdbc = ctx.getBean(
				"jdbc", Properties.class);
		System.out.println(jdbc); 
		DataSource ds = ctx.getBean(
				"dataSource", DataSource.class);
		System.out.println(ds.getDriver()); 
	}
	@Test
	public void testExampleBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		ExampleBean bean = ctx.getBean(
				"exampleBean", ExampleBean.class);
		System.out.println(bean); 
	}
}

















