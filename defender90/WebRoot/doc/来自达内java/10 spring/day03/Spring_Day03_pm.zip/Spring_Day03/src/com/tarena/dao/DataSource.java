package com.tarena.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * ���ݿ�����ӹ��� 
 */
@Component 
public class DataSource 
	implements Serializable{
	
	private String driver;
	@Value("#{jdbc.url}") 
	private String url;
	@Value("#{jdbc.user}")
	private String user;
	@Value("#{jdbc.pwd}")
	private String pwd;
	
	@Value("#{jdbc.driver}")
	public void setDriver(String driver) {
		this.driver = driver;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getDriver() {
		return driver;
	}
	public String getUrl() {
		return url;
	}
	public String getUser() {
		return user;
	}
	public String getPwd() {
		return pwd;
	}
	public Connection getConnection(){
		try{
			Connection conn = DriverManager.
				getConnection(url, user, pwd);
			return conn;
		}catch(SQLException e){
			e.printStackTrace();
			throw new RuntimeException(e); 
		}
	}
	public void close(Connection conn){
		try {
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}







