package com.tarena.test;

import java.io.Serializable;

public class DemoBean implements Serializable{
	private int age;
	private String name;
	private double salary;
	private boolean isMarried;
	public DemoBean() {
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	//�������͵�Bean���Է�����isMarried 
	// Ҳ���� getMarried 
	// Bean ��������married
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	@Override
	public String toString() {
		return "DemoBean [age=" + age + ", name=" 
			  + name + ", salary=" + salary
				+ ", isMarried=" + isMarried + "]";
	}
}
