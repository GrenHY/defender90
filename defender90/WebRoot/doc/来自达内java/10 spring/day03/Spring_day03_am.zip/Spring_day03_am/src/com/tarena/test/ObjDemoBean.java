package com.tarena.test;

import java.io.Serializable;
import java.util.Date;

public class ObjDemoBean implements Serializable {
	private Date dayOfBirth;//birthday
	private Date dayOfMarry;
	
	public Date getDayOfBirth() {
		return dayOfBirth;
	}
	public void setDayOfBirth(Date dayOfBirth) {
		this.dayOfBirth = dayOfBirth;
	}
	public Date getDayOfMarry() {
		return dayOfMarry;
	}
	public void setDayOfMarry(Date dayOfMarry) {
		this.dayOfMarry = dayOfMarry;
	}
	@Override
	public String toString() {
		return "ObjDemoBean [dayOfBirth=" + dayOfBirth + ", dayOfMarry="
				+ dayOfMarry + "]";
	}
	
}
