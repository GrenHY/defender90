package com.tarena.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCase {
	//@Test
	public void testDemoBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		DemoBean bean = ctx.getBean(
				"demoBean", DemoBean.class);
		System.out.println(bean); 
	}
	//@Test
	public void testObjDemoBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		ObjDemoBean bean = 
			ctx.getBean("obj", ObjDemoBean.class);
		System.out.println(bean);
	}
	
	@Test
	public void testCollectionBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		CollectionBean bean = ctx.getBean(
				"colBean", CollectionBean.class);
		System.out.println(bean);
	}
	
}



