package com.tarena.test;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/** ���԰��� */
public class TestCase {
	//@Test //ע�⣬����JUnit����
	public void testHelloWorld(){
		System.out.println("Hello World!"); 
	}
	//@Test
	public void testFirstBean(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Date date = ctx.getBean("obj", Date.class);
		System.out.println(date); 
	}
	//...
	//@Test//��̬����ʵ����
	/*    <bean id="cal1" class="java.util.Calendar"
     factory-method="getInstance"/> */
	public void testFactoryMethod(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(cfg);
		Calendar cal = ctx.getBean("cal1", 
				Calendar.class);
		System.out.println(cal);//����
	}
	@Test//@ == at ʵ������ʵ��������
	public void testBeanFactory(){
		String cfg = "applicationContext.xml";
		ApplicationContext ctx =
			new ClassPathXmlApplicationContext(cfg);
		Date d = ctx.getBean("date2", Date.class);
		System.out.println(d); 
	}
}








