package day02;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * ʹ���ļ��������ļ�
 * @author Administrator
 *
 */
public class CopyDemo {
	public static void main(String[] args)throws IOException {
		FileInputStream fis
			= new FileInputStream("JAVASE01.pptx");
		
		FileOutputStream fos
			= new FileOutputStream("COPY2.pptx");
			
//		int d = -1;
//		while((d = fis.read())!=-1){
//			fos.write(d);
//		}
		
		int len = -1;
		byte[] buf = new byte[10240];
		while((len = fis.read(buf))!=-1){
			fos.write(buf,0,len);
		}
		
		System.out.println("�������");
		fis.close();
		fos.close();
	}
}





