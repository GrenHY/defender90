package day07;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * ʹ��·������ʽ����xml�е�����
 * @author Administrator
 *
 */
public class XPathDemo {
	public static void main(String[] args) {
		try {
			File file = new File("myemp.xml");
			SAXReader reader
					  = new SAXReader();
			Document doc = reader.read(file);
			/*
			 * ��ѯid����3��Ա���Ĺ���
			 */
			String path = "/list/emp[@id=3]/salary";
			List list = doc.selectNodes(path);
			for(Object o : list){
				Element e = (Element)o;
				System.out.println(e.getText());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
