package day04;
/**
 * ��ȡ�߳���Ϣ����ط���
 * @author Administrator
 *
 */
public class ThreadApiDemo {
	public static void main(String[] args) {
		//�鿴main�̵߳������Ϣ
		Thread t = Thread.currentThread();
		long id = t.getId();
		String name = t.getName();
		int prioirty = t.getPriority();
		System.out.println("id:"+id);
		System.out.println("name:"+name);
		
		System.out.println(
			"priority:"+prioirty);
		System.out.println(
			"isAlive:"+t.isAlive());
		System.out.println(
			"isDaemon:"+t.isDaemon());
		System.out.println(
			"isInterrupted:"+t.isInterrupted());
	}
}




