package day04;
/**
 * synchronized�ֳ�Ϊ������
 * @author Administrator
 *
 */
public class SyncDemo3 {
	public static void main(String[] args) {
		final SyncDemo3 demo = new SyncDemo3();
		Thread t1 = new Thread(){
			public void run(){
				demo.foo();
			}
		};
		Thread t2 = new Thread(){
			public void run(){
				demo.boo();
			}
		};
		t1.start();
		t2.start();
	}
	
	public void foo(){
		synchronized (this){
			System.out.println("foo start");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			}
			System.out.println("foo end");
		}
	}	
	public void boo(){
		synchronized (this){
			System.out.println("boo start");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			}
			System.out.println("boo end");
		}
	}
}
