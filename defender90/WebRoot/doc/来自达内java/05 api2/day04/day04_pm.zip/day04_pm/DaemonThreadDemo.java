package day04;
/**
 * �ػ��߳�
 * @author Administrator
 *
 */
public class DaemonThreadDemo {
	public static void main(String[] args) {
		/*
		 * rose�ı�����:ǰ̨�߳�
		 */
		Thread rose = new Thread(){
			public void run(){
				for(int i=0;i<10;i++){
					System.out.println(
						"rose:let me go!"
					);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}
				System.out.println(
					"rose:AAAAAAaaaaaa......");
				System.out.println(
					"�԰�:��ͨ��");		
			}
		};
		
		Thread jack = new Thread(){
			public void run(){
				while(true){
					System.out.println(
						"jack:you jump!i jump!");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}
			}
		};
		
		rose.start();
		/*
		 * ����Ϊ�ػ��߳�Ӧ����start()����֮
		 * ǰ������
		 */
		jack.setDaemon(true);
		
		jack.start();
	}
}







