package day03;

import java.awt.AWTException;
import java.io.IOException;

public class Father {
	public void dosome()throws IOException,AWTException{
		
	}
}
