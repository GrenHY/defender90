package day03;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * finallyӦ��
 * @author Administrator
 *
 */
public class ExceptionDemo3 {
	public static void main(String[] args) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("e.dat");
			fos.write("helloworld".getBytes());
		} catch (Exception e) {
			System.out.println("��������");
		} finally{
			try {
				if(fos != null){
					fos.close();
				}
			} catch (IOException e) {
			}
		}
			
		
	}
}
