package day01;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * ��������������д���ļ�
 * ���ȡ������������
 * @author Administrator
 *
 */
public class RandomAccessFileDemo4 {
	public static void main(String[] args)throws IOException {
		RandomAccessFile raf
			= new RandomAccessFile(
					"test.dat","rw");
		/*
		 * ��int���ֵд���ļ�
		 */
		int max = Integer.MAX_VALUE;		
		/*
		 *                            vvvvvvvv
		 * 01111111 11111111 11111111 11111111
		 */
//		raf.write(max>>>24);
//		raf.write(max>>>16);
//		raf.write(max>>>8);
//		raf.write(max);
		System.out.println(
				raf.getFilePointer());//0
		raf.writeInt(max);
		System.out.println(
				raf.getFilePointer());//4
		raf.writeDouble(1.1);
		
		raf.writeLong(100L);
		
		raf.seek(0);
		
		int i = raf.readInt();
		System.out.println(i);
		
		double d = raf.readDouble();
		System.out.println(d);
		
		long l = raf.readLong();
		System.out.println(l);
		
		raf.close();
		
	}
}


