package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SomeServlet extends HttpServlet{
	public SomeServlet(){
		System.out.println("SomeServlet's constructor...");
	}
	public void service(HttpServletRequest request,
			HttpServletResponse response) 
	throws ServletException,IOException{
		//���������Դ·��
		String uri = request.getRequestURI();
		System.out.println("uri:" + uri);
		String action = 
			uri.substring(uri.lastIndexOf("/"),
					uri.lastIndexOf("."));
		System.out.println("action:" + action);
		if(action.equals("/list")){
			System.out.println("list....");
		}else if(action.equals("/add")){
			System.out.println("add...");
		}
	}
}
