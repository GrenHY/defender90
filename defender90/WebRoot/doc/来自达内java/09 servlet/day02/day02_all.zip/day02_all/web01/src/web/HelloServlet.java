package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet{
	public HelloServlet(){
		System.out.println("HelloServlet's consturctor...");
	}
	public void service(HttpServletRequest request,
			HttpServletResponse response) 
	throws ServletException,IOException{
		//���������������ò���ֵ
		String uname = request.getParameter("uname");
		String[] interestes = 
			request.getParameterValues("interest");
		for(int i = 0;i < interestes.length; i ++){
			System.out.println(interestes[i]);
		}
		//����content-type��Ϣͷ
		response.setContentType("text/html");
		//���һ�������
		PrintWriter out = response.getWriter();
		//����������
		out.println("<h1 style='color:red;'>Hello " 
				+ uname + "</h1>");
		out.close();
	}
}
