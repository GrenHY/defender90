function getXhr(){
			var xhr = null;
			if(window.XMLHttpRequest){
				//��ie�����
				xhr = new XMLHttpRequest();
			}else{
				//ie
				xhr = new ActiveXObject('MicroSoft.XMLHttp');
			}
			return xhr;
		}