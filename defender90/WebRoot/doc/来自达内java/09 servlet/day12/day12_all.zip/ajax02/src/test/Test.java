package test;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import bean.Stock;

public class Test {
	/**
	 * {"code":"600015","name":"ɽ������",
	 * "price":20.12}
	 */
	public static void test1(){
		Stock s = new Stock();
		s.setCode("600015");
		s.setName("ɽ������");
		s.setPrice(20.12);
		JSONObject obj =
			JSONObject.fromObject(s);
		String jsonStr = obj.toString();
		System.out.println(jsonStr);
	}
	
	/**
	 * [{"code":"600011","name":"ɽ������1",
	 * "price":20.12},{"code":"600012","name":"ɽ������2",
	 * "price":21.12},{"code":"600013","name":"ɽ������3",
	 * "price":22.12}]
	 */
	public static void test2(){
		List<Stock> stocks = 
			new ArrayList<Stock>();
		for(int i = 0;i < 3;i ++){
			Stock s = new Stock();
			s.setCode("60001" + (i + 1));
			s.setName("ɽ������" + (i + 1));
			s.setPrice(20.12 + i);
			stocks.add(s);
		}
		//fromObjectҲ���Դ����顣
		JSONArray arr = 
				JSONArray.fromObject(stocks);
		String jsonStr = arr.toString();
		System.out.println(jsonStr);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		test2();
	}

}
