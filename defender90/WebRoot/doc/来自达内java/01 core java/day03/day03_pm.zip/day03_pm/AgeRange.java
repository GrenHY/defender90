package day03;
import java.util.Scanner;  //1.
//�����ж�
public class AgeRange {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);//2.
		
		System.out.println("����������:");
		int age = scan.nextInt();  //3.
		
		boolean b = age>=18 && age<=50;
		System.out.println(b);
	}
}
