package day03;

public class Dept {

}
