package day03;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderDAO {
	private static final String INSERT_ORDER=
		"insert into orders_zhangdong " +
		"(order_id,name) " +
		"values(order_seq_zhangdong.nextval,?)";
	private static final String INSERT_DETAIL=
		"insert into orderdetails_zhangdong " +
		"(id,product,count,unitprice,order_id) " +
		"values(detail_seq_zhangdong.nextval,?,?,?,?)";
	public void addOrder(){
		Connection conn=null;
		PreparedStatement pstmt=null;
		try{
			conn=DBUtils.getConnection();
			conn.setAutoCommit(false);
			/*��������*/
			pstmt=conn.prepareStatement(
					INSERT_ORDER
					,new String[]{"order_id"});
			pstmt.setString(1, "IRONMAN");
			pstmt.executeUpdate();
			/*ȡ�Զ����ɵ�����*/
			ResultSet rs=pstmt.getGeneratedKeys();
			//ֻ��һ��һ�С���һ����
			int order_id=0;
			if(rs.next()) order_id=rs.getInt(1);
			/*��ʱ��order_id�б������Զ����ɵ�����*/
			/*����ӱ�*/
			pstmt=conn.prepareStatement(INSERT_DETAIL);
			pstmt.setString(1, "��Ԫ��");
			pstmt.setInt(2, 5);
			pstmt.setDouble(3, 500);
			pstmt.setInt(4, order_id);
			pstmt.addBatch();
			//if(1==1) throw new Exception("����!");
			pstmt.setString(1, "��Ӧ��");
			pstmt.setInt(2, 1);
			pstmt.setDouble(3, 10000);
			pstmt.setInt(4, order_id);
			pstmt.addBatch();
			pstmt.executeBatch();
			conn.commit();
		}catch(Exception e){
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				conn.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			DBUtils.closeConnection(conn);
		}
	}
	
	public static void main(String[] args) {
		OrderDAO order=new OrderDAO();
		order.addOrder();
	}

}
