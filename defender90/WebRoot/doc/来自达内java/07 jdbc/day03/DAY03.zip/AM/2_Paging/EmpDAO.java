package day03.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class EmpDAO {
	public void findAll() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtils.getConnection();
			String sql="select empno, ename, sal, hiredate from emp_������ȫƴ";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getInt("empno") + ","
						+ rs.getString("ename") + "," + ","
						+ rs.getDouble("sal") + "," 
						+ rs.getDate("hiredate"));
			}
		} catch (SQLException e) {e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if (pstmt != null) pstmt.close();
				DBUtils.closeConnection(conn);
			} catch (SQLException e) {e.printStackTrace();}
		}
	}

	public void add(String ename,String job,Double sal) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int flag = -1;
		String sql = "insert into emp_������ȫƴ(empno, ename, job,sal) "
				+ "values(emp_seq.nextval,?,?,?)";
		try {
			conn = DBUtils.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,ename);
			pstmt.setString(2,job);
			pstmt.setDouble(3,sal);
			flag = pstmt.executeUpdate();
			if (flag > 0) System.out.println("���ӳɹ�!");
		} catch (SQLException e) { e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				DBUtils.closeConnection(conn);
			} catch (SQLException e) {e.printStackTrace();}
		}
	}

	public void update(Double sal,Double comm,int empno) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int flag = -1;
		String sql = "update emp_������ȫƴ set sal=?,comm=? where empno=?";

		try {
			conn = DBUtils.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setDouble(1, sal);
			pstmt.setDouble(2, comm);
			pstmt.setInt(3, empno);
			flag = pstmt.executeUpdate();
			if (flag > 0) System.out.println("�޸ĳɹ�!");
		} catch (SQLException e) { e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				DBUtils.closeConnection(conn);
			} catch (SQLException e) {e.printStackTrace();}
		}
	}

	@SuppressWarnings({ "resource"})
	public void findByPage(int page, int pageSize){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtils.getConnection();
			String sqlTotal="select count(*) from emp_������ȫƴ";
			//Oracle��ҳ
			/*String sql="select * from("
					+ "select row_number() over(order by ename) rn,"
					+ "empno,ename,sal,hiredate from emp_������ȫƴ) "
					+ "where rn>? and rn<=?";*/
			//MySQL��ҳ
			String sql="select empno,ename,sal,hiredate "
					+ "from emp_������ȫƴ order by ename limit ?,?";
			pstmt = conn.prepareStatement(sql);			
			pstmt.setInt(1, (page-1)*pageSize);
			//Oracle��ҳ
			//pstmt.setInt(2, page*pageSize);
			//MySQL��ҳ
			pstmt.setInt(2, pageSize);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getInt("empno") + ","
						+ rs.getString("ename") + "," 
						+ rs.getDouble("sal") + "," 
						+ rs.getDate("hiredate"));
			}
			//��ӡ����������ҳ��
			pstmt = conn.prepareStatement(sqlTotal);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				int total=rs.getInt(1);
				int pages=(int) Math.ceil((float)total/(float)pageSize);
				System.out.print("��"+page+"ҳ/��"+pages+"ҳ  ��"+total+"����¼");
			}
		} catch (SQLException e) {e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if (pstmt != null) pstmt.close();
				DBUtils.closeConnection(conn);
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
}
