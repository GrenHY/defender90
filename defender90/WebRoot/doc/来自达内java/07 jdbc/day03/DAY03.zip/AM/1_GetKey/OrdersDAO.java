package day03;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class OrdersDAO {

	public void addOrder() {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = null;

		try {
			con = DBUtils.getConnection();
			// �ر��Զ��ύ
			con.setAutoCommit(false);			
			// ��������
			sql = "insert into orders_������ȫƴ values(order_seq_������ȫƴ.nextval,?,?)";
			stmt = con.prepareStatement(sql, new String[] { "id" });
			stmt.setString(1, "������");
			stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));

			// ִ��SQL���
			stmt.executeUpdate();
			rs = stmt.getGeneratedKeys();
			int orderID = 0;
			if (rs.next()) orderID = rs.getInt(1);
			System.out.print("id:" + orderID);

			// ����ӱ�
			sql = "insert into orderDetails_������ȫƴ values(detail_seq_������ȫƴ.nextval,?,?,?,?)";	
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, orderID);
			stmt.setString(2, "��Ӧ��"); 
			stmt.setInt(3,2); 
			stmt.setDouble(4, 5000.0);
			stmt.executeUpdate();
			// �ύ
			con.commit();

		} catch (SQLException e) {e.printStackTrace();}
		finally {
			try {
				if (rs != null) rs.close();
				if (stmt != null) stmt.close();
				DBUtils.closeConnection(con);
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
}
