﻿use test;
drop table if exists orders_;
create table orders_(
  order_id int(4) primary key auto_increment,
  name varchar(20) not null,
  orderdate timestamp default now()
)default character set utf8;
drop table if exists orderDetails_;
create table orderDetails_(
  id int(4) primary key auto_increment,
  order_id int(4),
  product varchar(50) not null,
  count int(4) not null,
  unitprice float(7,2) not null
)default character set utf8;