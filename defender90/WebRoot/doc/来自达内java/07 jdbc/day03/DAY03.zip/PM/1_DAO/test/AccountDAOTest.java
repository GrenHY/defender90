package com.tarena.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import com.tarena.dao.*;
import com.tarena.entity.Account;
import com.tarena.idao.IAccount;

import org.junit.Test;

@SuppressWarnings("unused")
public class AccountDAOTest {

	@Test
	public void testFindAll() {
		IAccount account=new AccountDAO();		
		try {
			List<Account> list=account.findAll();
			for(Account a: list){
				a.toString();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
