package com.tarena.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;

public class DBUtils {
	private static BasicDataSource dataSource = null;
	
	static {
		try {
			Properties props=new Properties();
			props.load(DBUtils.class
					.getClassLoader()
					.getResourceAsStream("com/tarena/jdbc/db.properties")
					);
			dataSource = new BasicDataSource();
			dataSource.setDriverClassName(props.getProperty("driver"));
			dataSource.setUrl(props.getProperty("url"));
			dataSource.setUsername(props.getProperty("user"));
			dataSource.setPassword(props.getProperty("password"));
			
			dataSource.setInitialSize(Integer.parseInt(props.getProperty("initialSize")));
			dataSource.setMinIdle(Integer.parseInt(props.getProperty("minIdle")));
			dataSource.setMaxIdle(Integer.parseInt(props.getProperty("maxIdle")));
			dataSource.setMaxWaitMillis(Long.parseLong(props.getProperty("maxWait")));
			dataSource.setMaxIdle(Integer.parseInt(props.getProperty("maxTotal")));
		} catch (Exception e) { e.printStackTrace(); }
	}
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
	public static void closeConnection(Connection con) {
		if (con != null)
			try { con.close(); } 
			catch (SQLException e) {e.printStackTrace();}
	}
}

