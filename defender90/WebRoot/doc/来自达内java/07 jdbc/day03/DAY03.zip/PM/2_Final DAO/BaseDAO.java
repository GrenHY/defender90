package com.tarena.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tarena.jdbc.DBUtils;

public abstract class BaseDAO<T> {
	protected List<T> find(String sql,Object[] params) throws Exception{
		List<T> r=new ArrayList<T>();
		Connection conn=null;
		PreparedStatement pstmt= null;
		ResultSet rs=null;
		try{
			conn=DBUtils.getConnection();
			pstmt=conn.prepareStatement(sql);
			if(params != null)
				for(int i=0;i<params.length;i++)
					pstmt.setObject(i+1, params[i]);
			rs=pstmt.executeQuery();
			while(rs.next())
				r.add(toEntity(rs));
			return r;
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(rs!=null) rs.close();
			if(pstmt!=null) pstmt.close();
			DBUtils.closeConnection(conn);
		}		
	}
	public abstract T toEntity(ResultSet rs) throws SQLException;
}
	
