package com.tarena.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import com.tarena.entity.Account;
import com.tarena.idao.IAccount;
import com.tarena.jdbc.DBUtils;

public class AccountDAO extends BaseDAO<Account> implements IAccount {
	private static final String Find_BY_ID = "SELECT ACCOUNT_ID, RECOMMENDER_ID, LOGIN_NAME, LOGIN_PASSWD,"
			+ " STATUS, CREATE_DATE, PAUSE_DATE, CLOSE_DATE, REAL_NAME, IDCARD_NO, BIRTHDATE, GENDER, OCCUPATION,"
			+ "TELEPHONE,EMAIL,MAILADDRESS,ZIPCODE,QQ,LAST_LOGIN_TIME,LAST_LOGIN_IP "
			+ "FROM ACCOUNT WHERE ACCOUNT_ID=?";	
	private static final String FIND_ALL = "SELECT ACCOUNT_ID, RECOMMENDER_ID, LOGIN_NAME, LOGIN_PASSWD,"
			+ " STATUS, CREATE_DATE, PAUSE_DATE, CLOSE_DATE, REAL_NAME, IDCARD_NO, BIRTHDATE, GENDER, OCCUPATION,"
			+ "TELEPHONE,EMAIL,MAILADDRESS,ZIPCODE,QQ,LAST_LOGIN_TIME,LAST_LOGIN_IP "
			+ "FROM ACCOUNT";
	private static final String INSERT = "INSERT INTO ACCOUNT(ACCOUNT_ID, RECOMMENDER_ID, LOGIN_NAME, LOGIN_PASSWD,"
			+ " STATUS, CREATE_DATE, PAUSE_DATE, CLOSE_DATE, REAL_NAME, IDCARD_NO, BIRTHDATE, GENDER, OCCUPATION,"
			+ "TELEPHONE,EMAIL,MAILADDRESS,ZIPCODE,QQ,LAST_LOGIN_TIME,LAST_LOGIN_IP) "
 			+ " VALUES (ACCOUNT_SEQ.NEXTVAL,?, ?, ?, '0', SYSDATE, NULL, NULL,?, ?, to_date(?,'yyyy-mm-dd'), ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?)";
	private static final String MODIFY = "UPDATE ACCOUNT SET LOGIN_PASSWD = ?, REAL_NAME = ?,  GENDER = ?, OCCUPATION = ?,"
			+ "TELEPHONE = ?,EMAIL = ?,MAILADDRESS = ?,ZIPCODE = ?,QQ = ?"
			+ "WHERE ACCOUNT_ID=?";	
	private static final String UPDATE_STATUS = "UPDATE ACCOUNT SET STATUS = ? WHERE ACCOUNT_ID=?";

	public Account findById(Integer id) throws Exception {
		List<Account> l=find(Find_BY_ID,new Object[]{id});
		if(l.size()!=0) return l.get(0);
		else return null;
	}

	public List<Account> findAll() throws Exception {
		return find(FIND_ALL,null);
	}

	public Account add(Account account) throws SQLException {
		Connection conn = DBUtils.getConnection();
		String sql = INSERT;
		PreparedStatement ps = conn.prepareStatement(sql, new String[] { "account_id" });

		Calendar c = Calendar.getInstance();
		c.setTime(account.getBirthdate());
		String birth = c.get(Calendar.YEAR) + "-" + c.get(Calendar.MONTH) + "-" + c.get(Calendar.DATE); 
		
		ps.setInt(1, account.getRecommenderId());
		ps.setString(2, account.getLoginName());
		ps.setString(3, account.getLoginPasswd());
		ps.setString(4, account.getRealName());
		ps.setString(5, account.getIdcardNo());
		ps.setString(6, birth);
		ps.setString(7, account.getGender());
		ps.setString(8, account.getOccupation());
		ps.setString(9, account.getTelephone());
		ps.setString(10, account.getEmail());
		ps.setString(11, account.getMailaddress());
		ps.setString(12, account.getZipcode());
		ps.setString(13, account.getQq());
		ps.setString(14, account.getLastLoginIp());

		ps.executeUpdate();
		ResultSet rs = ps.getGeneratedKeys();
		rs.next();
		int id = rs.getInt(1);
		account.setId(id);
		
		return account;
	}

	public Account modify(Account account) throws Exception {
		Connection conn = DBUtils.getConnection();
		String sql = MODIFY; // Ԥ�ȶ���õ�SQL���

		//��������id�����ڣ�ֱ�ӷ���null
		Account account_fromdb = this.findById(account.getId());
		if (account_fromdb == null){
			return null;
		}
		
		PreparedStatement ps = conn.prepareStatement(sql);
		
		ps.setString(1, account.getLoginPasswd());// �������
		ps.setString(2, account.getRealName());
		ps.setString(3, account.getGender());
		ps.setString(4, account.getOccupation());
		ps.setString(5, account.getTelephone());
		ps.setString(6, account.getEmail());
		ps.setString(7, account.getMailaddress());
		ps.setString(8, account.getZipcode());
		ps.setString(9, account.getQq());
		ps.setInt(10, account.getId());
	
		int flag = ps.executeUpdate();
		
		return (flag > 0) ? account : null;
	}

	public Account modifyStatus(Account account) throws SQLException {
		Connection conn = DBUtils.getConnection();
		String sql = UPDATE_STATUS; // Ԥ�ȶ���õ�SQL���
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, account.getStatus());// �������
		ps.setInt(2, account.getId());
		
		int flag = ps.executeUpdate();
		return (flag > 0) ? account : null;
	}

	@Override
	public Account toEntity(ResultSet rs) throws SQLException {
		Account account = new Account();
		account.setId(rs.getInt("ACCOUNT_ID"));
		account.setRecommenderId(rs.getInt("RECOMMENDER_ID"));
		account.setLoginName(rs.getString("LOGIN_NAME"));
		account.setLoginPasswd(rs.getString("LOGIN_PASSWD"));
		account.setStatus(rs.getString("STATUS"));
		account.setCreateDate(rs.getDate("CREATE_DATE"));
		account.setPauseDate(rs.getDate("PAUSE_DATE"));
		account.setCloseDate(rs.getDate("CLOSE_DATE"));
		account.setRealName(rs.getString("REAL_NAME"));
		account.setIdcardNo(rs.getString("IDCARD_NO"));
		account.setBirthdate(rs.getDate("BIRTHDATE"));
		account.setGender(rs.getString("GENDER"));
		account.setOccupation(rs.getString("OCCUPATION"));

		account.setTelephone(rs.getString("TELEPHONE"));
		account.setEmail(rs.getString("EMAIL"));
		account.setMailaddress(rs.getString("MAILADDRESS"));
		account.setZipcode(rs.getString("ZIPCODE"));
		account.setQq(rs.getString("QQ"));
		account.setLastLoginTime(rs.getDate("LAST_LOGIN_TIME"));
		account.setLastLoginIp(rs.getString("LAST_LOGIN_IP"));
		return account;
	}
	
}
