drop table if exists bank;
create table bank(
  id int(4) primary key,
  name varchar(20) not null,
  balance double(7,2) not null
);
insert into bank values(1,'spiderman', 5000);
insert into bank values(2,'ironman', 5000);
commit;
