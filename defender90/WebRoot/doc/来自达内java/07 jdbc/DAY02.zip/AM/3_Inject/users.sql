exec proc_dropifexists('users_你名字全拼');
create table users_你名字全拼(
  id number(4,0),
  username varchar2(30),
  password varchar2(30)
);
insert into users_你名字全拼 values(1,'tarena','tarena123');
insert into users_你名字全拼 values(2,'syl','syl001');
commit;