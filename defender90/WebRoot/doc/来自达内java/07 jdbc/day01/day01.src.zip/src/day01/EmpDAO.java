package day01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class EmpDAO {
	public void findAll() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtils.getConnection();
			System.out.println(conn);
			// Step3����дSQL��䲢ִ��
			String findAll = "select id,name,salary from emp_zhangdong";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(findAll);
			// Step4:���������
			while (rs.next()) {
				// rs�еõ�һ������
				// *����һ��*
				System.out.println(rs.getInt(1) + "," + rs.getString("name")
						+ "," + rs.getDouble(3));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			DBUtils.closeConnection(conn);
		}
	}
	public static void main(String[] args) throws Exception {
		EmpDAO emp = new EmpDAO();
		emp.findAll();
	}

}
