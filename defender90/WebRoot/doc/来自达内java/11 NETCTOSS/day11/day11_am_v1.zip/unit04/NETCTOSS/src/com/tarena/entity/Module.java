package com.tarena.entity;

public class Module {
	
	private Integer module_id;
	private String name;
	
	public Integer getModule_id() {
		return module_id;
	}
	public void setModule_id(Integer moduleId) {
		module_id = moduleId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
