package com.tarena.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tarena.entity.Emp;

@Controller
@RequestMapping("/test")
public class JsonController {

	@RequestMapping("/test1.do")
	@ResponseBody
	public boolean test1() {
		//�������͵����ݣ�Springֱ�ӷ�����ֵ
		return true;
	}
	
	@RequestMapping("/test2.do")
	@ResponseBody
	public Map<String, Object> test2() {
		Map<String, Object> map = 
			new HashMap<String, Object>();
		map.put("name", "zhangsan");
		map.put("age", 23);
		//{"name":"zhangsan","age":23}
		return map;
	}
	
	@RequestMapping("/test3.do")
	@ResponseBody
	public List<Object> test3() {
		List<Object> list = 
			new ArrayList<Object>();
		list.add("zhangsan");
		list.add(23);
		//["zhangsan",23]
		return list;
	}
	
	@RequestMapping("/test4.do")
	@ResponseBody
	public Emp test4() {
		Emp e = new Emp();
		e.setEmpno(1);
		e.setEname("zhangsan");
		e.setJob("����Ա");
		e.setSal(6000.0);
		e.setDeptno(10);
		//{"empno":1,"ename":"zhangsan",...}
		return e;
	}
	
	@RequestMapping("/test5.do")
	@ResponseBody
	public List<Emp> test5() {
		List<Emp> list = 
			new ArrayList<Emp>();
		Emp e = new Emp();
		e.setEmpno(1);
		e.setEname("zhangsan");
		e.setJob("����Ա");
		e.setSal(6000.0);
		e.setDeptno(10);
		list.add(e);
		
		Emp e2 = new Emp();
		e2.setEmpno(2);
		e2.setEname("lisi");
		e2.setJob("����Ա");
		e2.setSal(70000.0);
		e2.setDeptno(20);
		list.add(e2);
		
		//[{"empno":1,"ename":"zhangsan",...},
		//{"empno":2,"ename":"lisi",...}]
		return list;
	}
	
}
