package com.tarena.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 *	�жϵ�ǰģ���������������жϵ�ǰ�û�
 *	���ʵ�ģ��
 */
public class CurrentModuleInterceptor 
	implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {

	}

	@Override
	public void postHandle(
			HttpServletRequest request, 
			HttpServletResponse response,
			Object arg2, ModelAndView arg3) throws Exception {
		System.out.println(
			"CurrentModuleInterceptor.postHandle");
	}

	@Override
	public boolean preHandle(
			HttpServletRequest request, 
			HttpServletResponse response,
			Object arg2) throws Exception {
		//��ȡurl
		String url = 
			request.getRequestURL().toString();
		//����url�жϵ�ǰ�û����ʵ�ģ��
		int currentModuleId = 0; //Ĭ��Ϊ0����ҳ
		if(url.contains("role")) {
			currentModuleId = 1;
		} else if (url.contains("admin")) {
			currentModuleId = 2;
		} else if (url.contains("cost")) {
			currentModuleId = 3;
		} else if (url.contains("account")) {
			currentModuleId = 4;
		} else if (url.contains("service")) {
			currentModuleId = 5;
		}
		//����ǰ���ʵ�ģ��ID����session
		request.getSession().setAttribute(
			"currentModuleId", currentModuleId);		
		
		System.out.println(
			"CurrentModuleInterceptor.preHandle");
		return true;
	}

}
