package com.tarena.aspect;

public class LoggerBean {
	
	public void log1() {
		System.out.println("��¼��־");
	}

}
