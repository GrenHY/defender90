package com.tarena.test;

import java.sql.Timestamp;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.CostMapper;
import com.tarena.entity.Cost;

public class TestCostMapper {

	@Test
	public void testSave() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		CostMapper mapper = 
			ctx.getBean(CostMapper.class);	
		//���Դ�����û��ҳ�棬���ģ��һ������
		Cost c = new Cost();
		c.setName("1408�ײ�");
		c.setBase_duration(80);
		c.setBase_cost(8.0);
		c.setUnit_cost(0.8);
		c.setStatus("0");
		
		mapper.save(c);
	}
	
	@Test
	public void testFindAll() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		CostMapper mapper = 
			ctx.getBean(CostMapper.class);
		List<Cost> list = mapper.findAll();
		for(Cost c : list) {
			System.out.println(
				c.getCost_id() + " " +
				c.getName() + " " +
				c.getDescr()
			);
		}
	}
	
}
