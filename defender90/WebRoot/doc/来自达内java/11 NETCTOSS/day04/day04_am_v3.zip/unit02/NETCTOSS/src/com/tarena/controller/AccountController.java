package com.tarena.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.AccountMapper;
import com.tarena.entity.Account;
import com.tarena.entity.page.AccountPage;

@Controller
@RequestMapping("/account")
@SessionAttributes("accountPage")
public class AccountController {
	
	@Resource
	private AccountMapper accMapper;

	@RequestMapping("/findAccount.do")
	public String find(AccountPage page, Model model) {
		//��ѯ����ǰҳ����
		List<Account> list = 
			accMapper.findByPage(page);
		model.addAttribute("accounts", list);
		//��ѯ�����������ڼ�����ҳ��
		int rows = accMapper.findRows(page);
		page.setRows(rows);
		model.addAttribute("accountPage", page);
		
		return "account/account_list";
	}
	
}
