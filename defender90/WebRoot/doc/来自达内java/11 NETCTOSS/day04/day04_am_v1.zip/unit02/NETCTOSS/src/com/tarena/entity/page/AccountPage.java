package com.tarena.entity.page;

public class AccountPage extends Page {

}
