package com.tarena.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tarena.dao.AdminMapper;
import com.tarena.entity.Admin;

/**
 *	��¼ģ��
 */
@Controller
@RequestMapping("/login")
public class LoginController 
	extends BaseController {
	
	// ��¼У��������
	public final static int SUCCESS = 0;
	public final static int ADMIN_CODE_ERROR = 1;
	public final static int PASSWORD_ERROR = 2;
	public final static int USER_CODE_ERROR = 3;
	
	@Resource
	private AdminMapper adminMapper;

	/**
	 * �򿪵�¼ҳ
	 */
	@RequestMapping("/toLogin.do")
	public String toLogin() {
		return "main/login";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex() {
		return "main/index";
	}
	
	@RequestMapping("/checkLogin.do")
	@ResponseBody
	public int checkLogin(String adminCode,
			String password) {
		//�����˺Ų�ѯ����Ա
		Admin admin = 
			adminMapper.findByCode(adminCode);
		//У���˺�
		if(admin == null) {
			//������ԱΪ�գ����˺Ų�����
			return ADMIN_CODE_ERROR;
		} else if (!admin.getPassword().equals(password)) {
			//���벻��
			return PASSWORD_ERROR;
		} else {
			return SUCCESS;
		}
	}
	
}
