package com.tarena.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.AdminMapper;
import com.tarena.dao.RoleMapper;
import com.tarena.entity.Admin;
import com.tarena.entity.Module;
import com.tarena.entity.page.AdminPage;

@Controller
@RequestMapping("/admin")
@SessionAttributes("adminPage")
public class AdminController extends BaseController {

	public static final String DEFAULT_PASSWORD = "123456";
	
	@Resource
	private AdminMapper adminMapper;
	
	@Resource
	private RoleMapper roleMapper;
	
	@RequestMapping("/findAdmin.do")
	public String find(AdminPage page, Model model) {
		//��ѯ��ȫ����ģ�飬���ڳ�ʼ������ѡ
		List<Module> modules = 
			roleMapper.findAllModule();
		model.addAttribute("modules", modules);
		//��ѯ��ǰҳ�Ĺ���Ա
		List<Admin> list = 
			adminMapper.findByPage(page);
		model.addAttribute("admins", list);
		//��ѯ������������������ҳ��
		int rows = adminMapper.findRows(page);
		page.setRows(rows);
		model.addAttribute("adminPage", page);
		return "admin/admin_list";
	}
	
	@RequestMapping("/resetPassword.do")
	@ResponseBody
	public Map<String, Object> updatePassword(String ids) {
		Map<String, Object> result = 
			new HashMap<String, Object>();
		if(ids == null || ids.length() == 0) {
			result.put("message", "��������Ϊ��.");
			return result;
		}
		
		List<Integer> idList = buildIdList(ids);
		Map<String, Object> map = 
			new HashMap<String, Object>();
		map.put("ids", idList);
		map.put("defaultPassword", DEFAULT_PASSWORD);
		
		adminMapper.updatePassword(map);
		
		result.put("message", "�������óɹ�.");
		return result;
	}

	/**
	 * Alt+Shift+M
	 */
	private List<Integer> buildIdList(String ids) {
		List<Integer> idList = 
			new ArrayList<Integer>();
		String[] idArray = ids.split(",");
		for(String id : idArray) {
			idList.add(Integer.valueOf(id));
		}
		return idList;
	}
	
}
