package com.tarena.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tarena.dao.AdminMapper;
import com.tarena.entity.Admin;
import com.tarena.entity.Module;
import com.tarena.util.ImageUtil;

/**
 *	��¼ģ��
 */
@Controller
@RequestMapping("/login")
public class LoginController 
	extends BaseController {
	
	// ��¼У��������
	public final static int SUCCESS = 0;
	public final static int ADMIN_CODE_ERROR = 1;
	public final static int PASSWORD_ERROR = 2;
	public final static int USER_CODE_ERROR = 3;
	
	@Resource
	private AdminMapper adminMapper;

	/**
	 * �򿪵�¼ҳ
	 */
	@RequestMapping("/toLogin.do")
	public String toLogin() {
		return "main/login";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex() {
		return "main/index";
	}
	
	@RequestMapping("/checkLogin.do")
	@ResponseBody
	public int checkLogin(String adminCode,
			String password, 
			String userCode,
			HttpSession session) {
		//У����֤��
		String imageCode = (String) 
			session.getAttribute("imageCode");
		if(userCode == null
				|| !userCode.equalsIgnoreCase(imageCode)) {
			//��֤�벻��
			return USER_CODE_ERROR;
		}
		//�����˺Ų�ѯ����Ա
		Admin admin = 
			adminMapper.findByCode(adminCode);
		//У���˺�
		if(admin == null) {
			//������ԱΪ�գ����˺Ų�����
			return ADMIN_CODE_ERROR;
		} else if (!admin.getPassword().equals(password)) {
			//���벻��
			return PASSWORD_ERROR;
		} else {
			//��¼�ɹ������û���Ϣ����session
			session.setAttribute("admin", admin);
			//��ѯ��ǰ�û����Է��ʵ�����ģ�飬����session
			List<Module> list = 
				adminMapper.findModuleByAdminId(
						admin.getAdmin_id());
			session.setAttribute("allModules", list);
			return SUCCESS;
		}
	}
	
	@RequestMapping("/createImage.do")
	public void createImage(
		HttpServletResponse response,
		HttpSession session) throws IOException {
		//������֤��ͼƬ
		Map<String, BufferedImage> map = 
			ImageUtil.createImage();
		//��ȡ��֤�룬����session
		String code = 
			map.keySet().iterator().next();
		session.setAttribute("imageCode", code);
		//��ȡͼƬ
		BufferedImage iamge = map.get(code);
		//��ͼƬ�����ҳ��
		response.setContentType("image/jpeg");
		OutputStream os = 
			response.getOutputStream();
		ImageIO.write(iamge, "jpeg", os);
		os.close();
	}
	
}
