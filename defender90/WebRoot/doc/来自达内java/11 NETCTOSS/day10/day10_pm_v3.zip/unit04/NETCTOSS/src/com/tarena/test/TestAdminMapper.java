package com.tarena.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.AdminMapper;
import com.tarena.entity.Admin;
import com.tarena.entity.Module;
import com.tarena.entity.Role;
import com.tarena.entity.page.AdminPage;

public class TestAdminMapper {
	
	@Test
	public void testFindModuleByAdminId() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AdminMapper mapper = 
			ctx.getBean(AdminMapper.class);
		List<Module> list = 
			mapper.findModuleByAdminId(5000);
		for(Module m : list) {
			System.out.println(
				m.getModule_id() + " " +
				m.getName()
			);
		}
	}
	
	@Test
	public void testUpdatePassword() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AdminMapper mapper = 
			ctx.getBean(AdminMapper.class);
		Map<String, Object> map = 
			new HashMap<String, Object>();
		List<Integer> ids = 
			new ArrayList<Integer>();
		ids.add(2000);
		ids.add(3000);
		map.put("ids", ids);
		map.put("defaultPassword", "abc");
		mapper.updatePassword(map);
	}
	
	@Test
	public void testFindRows() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AdminMapper mapper = 
			ctx.getBean(AdminMapper.class);
		AdminPage page = new AdminPage();
		page.setRoleName("S");
		page.setModuleId(7);
		int rows = mapper.findRows(page);
		System.out.println(rows);
	}
	
	@Test
	public void testFindByPage() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AdminMapper mapper = 
			ctx.getBean(AdminMapper.class);
		AdminPage page = new AdminPage();
		page.setRoleName("S");
		page.setModuleId(7);
		List<Admin> list = 
			mapper.findByPage(page);
		for(Admin a : list) {
			System.out.println(
				a.getAdmin_id() + " " 
				+ a.getAdmin_code());
			List<Role> roles = a.getRoles();
			for(Role r : roles) {
				System.out.println(
					r.getRole_id() + " " +
					r.getName()
				);
			}
			System.out.println("------------");
		}
	}

}
