package com.tarena.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tarena.dao.EmpMapper;
import com.tarena.entity.Emp;

@Controller
@RequestMapping("/emp")
public class EmpController {
	
	@Resource
	private EmpMapper empMapper;
	
	@Transactional(rollbackFor=Exception.class)
	public String add() throws ClassNotFoundException {
		Emp e = new Emp();
		e.setEname("������");
		e.setJob("˾��");
		e.setMgr(9);
		e.setSal(5000.0);
		e.setDeptno(10);
		empMapper.save(e);
		
//		Integer.valueOf("abc");
		Class.forName("LHH");
		
		return "";
	}

	/**
	 * ��ѯȫ����Ա��
	 */
	@RequestMapping("/findEmp.do")
	public String find(Model model) {
		System.out.println("EmpController.find()");
		//��ѯ
		List<Emp> list = empMapper.findAll();
//		model.addAttribute("emps", list);
		//ת��
		return "emp/emp_list";
	}
	
	@RequestMapping("/toUpdateEmp.do")
	public String toUpdate() {
		System.out.println("EmpController.toUpdate()");
		Integer.valueOf("abc");
		return "emp/update_emp";
	}
	
}
