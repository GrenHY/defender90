package com.tarena.annotation;

public @interface MyBatisRepository {

}
