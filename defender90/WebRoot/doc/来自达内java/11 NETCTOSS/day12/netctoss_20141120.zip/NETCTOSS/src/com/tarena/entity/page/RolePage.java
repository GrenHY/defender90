package com.tarena.entity.page;

public class RolePage extends Page {

}
