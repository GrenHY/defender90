--NETCTOSS
select * from cost;
select * from account;
select * from service;
select * from service_update_bak;
select * from module_info;
select * from role_info;
select * from role_module;
select * from admin_info;
select * from admin_role;
--DEMO
select * from t_dept;
select * from t_emp;
