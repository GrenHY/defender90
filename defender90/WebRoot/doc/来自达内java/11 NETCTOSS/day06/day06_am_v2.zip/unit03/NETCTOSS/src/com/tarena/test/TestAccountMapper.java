package com.tarena.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.AccountMapper;
import com.tarena.entity.Account;
import com.tarena.entity.page.AccountPage;

public class TestAccountMapper {

	@Test
	public void testStop() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AccountMapper mapper = 
			ctx.getBean(AccountMapper.class);
		mapper.stop(1005);
	}
	
	@Test
	public void testFindByPage() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AccountMapper mapper = 
			ctx.getBean(AccountMapper.class);
		AccountPage page = new AccountPage();
		page.setCurrentPage(1);
		page.setRealName("guojing");
		List<Account> list = 
			mapper.findByPage(page);
		for(Account a : list) {
			System.out.println(
				a.getAccount_id() + " " +
				a.getIdcard_no() + " " +
				a.getReal_name()
			);
		}
		System.out.println(mapper.findRows(page));
	}
	
}
