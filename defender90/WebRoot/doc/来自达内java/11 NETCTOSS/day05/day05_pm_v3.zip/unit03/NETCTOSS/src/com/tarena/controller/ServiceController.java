package com.tarena.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.ServiceMapper;
import com.tarena.entity.page.ServicePage;

@Controller
@RequestMapping("/service")
@SessionAttributes("servicePage")
public class ServiceController extends BaseController {

	@Resource
	private ServiceMapper serMapper;
	
	@RequestMapping("/findService.do")
	public String find(ServicePage page, Model model) {
		//��ѯ����ǰҳ��ҵ���˺�
		List<Map<String, Object>> list = 
			serMapper.findByPage(page);
		model.addAttribute("services", list);
		//��ѯ�����������ڼ�����ҳ��
		int rows = serMapper.findRows(page);
		page.setRows(rows);
		model.addAttribute("servicePage", page);
		return "service/service_list";
	}
	
}
