package com.tarena.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.RoleMapper;
import com.tarena.entity.Module;
import com.tarena.entity.Role;
import com.tarena.entity.page.RolePage;

@Controller
@RequestMapping("/role")
@SessionAttributes("rolePage")
public class RoleController extends BaseController {

	@Resource
	private RoleMapper roleMapper;
	
	@RequestMapping("/findRole.do")
	public String find(RolePage page, Model model) {
		//��ѯ����ǰҳ�Ľ�ɫ
		List<Role> list = 
			roleMapper.findByPage(page);
		model.addAttribute("roles", list);
		//��ѯ��������������ҳ��
		int rows = roleMapper.findRows();
		page.setRows(rows);
		model.addAttribute("rolePage", page);
		return "role/role_list";
	}
	
	@RequestMapping("/toAddRole.do")
	public String toAdd(Model model) {
		List<Module> list = 
			roleMapper.findAllModule();
		model.addAttribute("modules", list);
		return "role/add_role";
	}
	
	@RequestMapping("/addRole.do")
	public String add(Role role) {
		//������ɫ
		roleMapper.saveRole(role);
		//�����м��
		Integer roleId = role.getRole_id();
		List<Integer> moduleIds = 
			role.getModuleIds();
		if(moduleIds != null
				&& moduleIds.size()>0) {
			for(Integer moduleId : moduleIds) {
				Map<String, Object> rm = 
					new HashMap<String, Object>();
				rm.put("role_id", roleId);
				rm.put("module_id", moduleId);
				roleMapper.saveRoleModule(rm);
			}
		}
		return "redirect:findRole.do";
	}
	
	@RequestMapping("/checkRoleName.do")
	@ResponseBody
	public boolean checkRoleName(String name) {
		Role role = roleMapper.findByName(name);
		//�����жϽ���������ɫ���ظ�����true��
		//���򷵻�false
		if(role == null) {
			//��ɫΪ�գ�û�ظ�
			return false;
		} else {
			//��ɫ��Ϊ�գ��ظ���
			return true;
		}
	}
	
}
