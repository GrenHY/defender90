package com.tarena.dao;

import java.util.List;

import com.tarena.annotation.MyBatisRepository;
import com.tarena.entity.Cost;
import com.tarena.entity.page.CostPage;

@MyBatisRepository
public interface CostMapper {

	List<Cost> findAll();
	
	void save(Cost cost);
	
	Cost findById(int id);
	
	void update(Cost cost);
	
	void delete(int id);
	
	/**
	 * ��ҳ��ѯ�ʷ�����
	 */
	List<Cost> findByPage(CostPage page);
	
	/**
	 * ��ѯ�ʷѱ�������
	 */
	int findRows();
	
}
