package com.tarena.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.AdminMapper;
import com.tarena.entity.Admin;
import com.tarena.entity.Role;
import com.tarena.entity.page.AdminPage;

public class TestAdminMapper {
	
	@Test
	public void testFindByPage() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		AdminMapper mapper = 
			ctx.getBean(AdminMapper.class);
		AdminPage page = new AdminPage();
		page.setRoleName("S");
		page.setModuleId(7);
		List<Admin> list = 
			mapper.findByPage(page);
		for(Admin a : list) {
			System.out.println(
				a.getAdmin_id() + " " 
				+ a.getAdmin_code());
			List<Role> roles = a.getRoles();
			for(Role r : roles) {
				System.out.println(
					r.getRole_id() + " " +
					r.getName()
				);
			}
			System.out.println("------------");
		}
	}

}
