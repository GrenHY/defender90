package com.tarena.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.AdminMapper;
import com.tarena.dao.RoleMapper;
import com.tarena.entity.Admin;
import com.tarena.entity.Module;
import com.tarena.entity.page.AdminPage;

@Controller
@RequestMapping("/admin")
@SessionAttributes("adminPage")
public class AdminController extends BaseController {

	@Resource
	private AdminMapper adminMapper;
	
	@Resource
	private RoleMapper roleMapper;
	
	@RequestMapping("/findAdmin.do")
	public String find(AdminPage page, Model model) {
		//��ѯ��ȫ����ģ�飬���ڳ�ʼ������ѡ
		List<Module> modules = 
			roleMapper.findAllModule();
		model.addAttribute("modules", modules);
		//��ѯ��ǰҳ�Ĺ���Ա
		List<Admin> list = 
			adminMapper.findByPage(page);
		model.addAttribute("admins", list);
		//��ѯ������������������ҳ��
		int rows = adminMapper.findRows(page);
		page.setRows(rows);
		model.addAttribute("adminPage", page);
		return "admin/admin_list";
	}
}
