package com.tarena.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.AccountMapper;
import com.tarena.dao.CostMapper;
import com.tarena.dao.ServiceMapper;
import com.tarena.entity.Account;
import com.tarena.entity.Cost;
import com.tarena.entity.Service;
import com.tarena.entity.page.ServicePage;

@Controller
@RequestMapping("/service")
@SessionAttributes("servicePage")
public class ServiceController extends BaseController {

	@Resource
	private ServiceMapper serMapper;
	
	@Resource
	private AccountMapper accMapper;
	
	@Resource
	private CostMapper costMapper;
	
	@RequestMapping("/findService.do")
	public String find(ServicePage page, Model model) {
		//��ѯ����ǰҳ��ҵ���˺�
		List<Map<String, Object>> list = 
			serMapper.findByPage(page);
		model.addAttribute("services", list);
		//��ѯ�����������ڼ�����ҳ��
		int rows = serMapper.findRows(page);
		page.setRows(rows);
		model.addAttribute("servicePage", page);
		return "service/service_list";
	}
	
	@RequestMapping("/startService.do")
	@ResponseBody
	public Map<String, Object> updateToStart(int id) {
		System.out.println(1);
		Map<String, Object> result = 
			new HashMap<String, Object>();
		//�ж������˺��Ƿ�ͨ
		Service service = serMapper.findById(id);
		Account account = 
			accMapper.findById(service.getAccount_id());
		System.out.println(account.getStatus());
		if(account.getStatus().equals("0")) {
			//�����˺ſ�ͨ��ҵ���˺ſ��Կ�ͨ
			serMapper.start(id);
			result.put("success", true);
			result.put("message", "��ͨ�ɹ�.");
		} else {
			//�����˺�û��ͨ�����ܿ�ͨҵ���˺�
			result.put("success", false);
			result.put("message", "�����˺�δ��ͨ�����ܿ�ͨҵ���˺�.");
		}
		System.out.println(2);
		//{"success":true,"message":"��ͨ�ɹ�."}
		return result;
	}
	
	@RequestMapping("/toAddService.do")
	public String toAdd(Model model) {
		List<Cost> list = costMapper.findAll();
		model.addAttribute("costs", list);
		return "service/add_service";
	}
	
	@RequestMapping("/searchAccount.do")
	@ResponseBody
	public Account searchAccount(String idcardNo) {
		//{"account_id":1011,"login_name":"zs"...}
		return accMapper.findByIdcardNo(idcardNo);
	}
	
	@RequestMapping("/toUpdateService.do")
	public String toUpdate(int id, Model model) {
		//��ѯҪ�޸ĵ�����
		Service service = serMapper.findById(id);
		model.addAttribute("service", service);
		//��ѯȫ���ʷѣ����������ʷ�����ѡ
		List<Cost> list = costMapper.findAll();
		model.addAttribute("costs", list);
		return "service/update_service";
	}
	
}
