package com.tarena.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tarena.dao.RoleMapper;
import com.tarena.entity.Role;
import com.tarena.entity.page.RolePage;

@Controller
@RequestMapping("/role")
@SessionAttributes("rolePage")
public class RoleController extends BaseController {

	@Resource
	private RoleMapper roleMapper;
	
	@RequestMapping("/findRole.do")
	public String find(RolePage page, Model model) {
		//��ѯ����ǰҳ�Ľ�ɫ
		List<Role> list = 
			roleMapper.findByPage(page);
		model.addAttribute("roles", list);
		//��ѯ��������������ҳ��
		int rows = roleMapper.findRows();
		page.setRows(rows);
		model.addAttribute("rolePage", page);
		return "role/role_list";
	}
	
}
