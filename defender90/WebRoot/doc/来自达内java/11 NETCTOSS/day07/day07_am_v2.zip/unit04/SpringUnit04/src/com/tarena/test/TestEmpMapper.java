package com.tarena.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.EmpMapper;
import com.tarena.entity.Condition;
import com.tarena.entity.Emp;

public class TestEmpMapper {
	
	@Test
	public void testFindById() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		Emp e = mapper.findById(1);
		System.out.println(e.getEname());
		System.out.println(e.getDept().getDname());
	}
	
	@Test
	public void testSave() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		Emp e = new Emp();
		e.setEname("�����");
		e.setJob("������");
		e.setMgr(1);
		e.setSal(2000.0);
		e.setDeptno(10);
		mapper.save(e);
		System.out.println(e.getEmpno());
	}
	
	@Test
	public void testFindByIds() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		Condition cond = new Condition();
		List<Integer> ids = new ArrayList<Integer>();
		ids.add(1);
		ids.add(6);
		ids.add(9);
		cond.setEmpIds(ids);
		List<Emp> list = mapper.findByIds(cond);
		for(Emp e : list) {
			System.out.println(
				e.getEmpno() + " " +
				e.getEname() + " " +
				e.getSal() + " " +
				e.getDeptno()
			);
		}
	}
	
	@Test
	public void testUpdate() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		Emp e = new Emp();
		e.setEmpno(1);
		e.setEname("����ʦ");
		mapper.update(e);
	}
	
	@Test
	public void testFindByDeptAndSalary() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		Condition cond = new Condition();
		cond.setDeptId(20);
		cond.setSalary(2500.0);
		List<Emp> list = 
			mapper.findByDeptAndSalary(cond);
		for(Emp e : list) {
			System.out.println(
				e.getEmpno() + " " +
				e.getEname() + " " +
				e.getSal() + " " +
				e.getDeptno()
			);
		}
	}

	@Test
	public void testFindUpperSalary() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);		
		Condition cond = new Condition();
//		cond.setSalary(2500.0);//where sal>2500
		cond.setSalary(800.0);//where sal>1500
		List<Emp> list = mapper.findUpperSalary(cond);
		for(Emp e : list) {
			System.out.println(
				e.getEmpno() + " " +
				e.getEname() + " " +
				e.getDeptno()
			);
		}
	}	
	
	@Test
	public void testFindByDept() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);		
		Condition cond = new Condition();
		cond.setDeptId(10);
		List<Emp> list = mapper.findByDept(cond);
		for(Emp e : list) {
			System.out.println(
				e.getEmpno() + " " +
				e.getEname() + " " +
				e.getDeptno()
			);
		}
	}
	
	@Test
	public void testFindAll() {
		//����Spring����
		//�������ȡapplicationContext.xml��
		//��ʵ���������ļ���������bean��Ȼ��
		//����bean�е����ã��Զ�ɨ��ָ��·����
		//��mapper.xml���Զ�ɨ��ָ��·���µ�
		//����ע��Ľӿ�/�࣬�˴��Ľӿ�������
		//�Զ���Ľӿڡ�
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		//����������Mapper
		EmpMapper mapper = 
			ctx.getBean(EmpMapper.class);
		List<Emp> list = mapper.findAll();
		for(Emp e : list) {
			System.out.println(
				e.getEmpno() + " " +
				e.getEname() + " " +
				e.getDeptno()
			);
		}
	}
	
}
