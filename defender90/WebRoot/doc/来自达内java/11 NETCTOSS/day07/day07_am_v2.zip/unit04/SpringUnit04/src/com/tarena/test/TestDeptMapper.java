package com.tarena.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tarena.dao.DeptMapper;
import com.tarena.entity.Dept;
import com.tarena.entity.Emp;

public class TestDeptMapper {
	
	@Test
	public void testFindById() {
		ApplicationContext ctx = 
			new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		DeptMapper mapper = 
			ctx.getBean(DeptMapper.class);
		Dept dept = mapper.findById(10);
		System.out.println(dept.getDname());
		List<Emp> list = dept.getEmps();
		for(Emp e : list) {
			System.out.println(e.getEname());
		}
	}

}
