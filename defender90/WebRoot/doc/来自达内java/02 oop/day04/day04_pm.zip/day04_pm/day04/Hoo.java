package oo.day04;

public class Hoo {
	public int a;
	protected int b;
	int c;
	private int d;
	
	void test(){
		a = 1;
		b = 2;
		c = 3;
		d = 4;
	}
}
class Ioo{
	void say(){  //----private��ʾ
		Hoo o = new Hoo();
		o.a = 1;
		o.b = 2;
		o.c = 3;
		//o.d = 4; //privateֻ���ڱ����з���
	}
}






