package oo.day03;
//����̳���ʾ
public class ParentDemo {
	public static void main(String[] args) {
	}
}
class Aoo{
	int num;
	Aoo(int num){
		this.num = num;
	}
}
class Boo extends Aoo{
	Boo(){
		super(2);
		int num = 22;
	}
}





