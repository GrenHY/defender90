package oo.day02;
//��ҵ����
public class Homework {
	public static void main(String[] args) {
		Aoo o = new Aoo();
		o.a = 5;
		
		test(o);  //Aoo oo = o--���Կ��
		System.out.println(o.a); //8
		
		int num = 55;
		testNum(num); //int num2=num--����֤��ӡ��
		System.out.println(num);  //55
		
	}
	public static void testNum(int num2){
		num2 = 88;
	}
	public static void test(Aoo oo){
		oo.a = 8;
	}
}

class Aoo{
	int a;
}


