package com.tarena.tetris;

public class Test02 {
	public static void main(String[] args) {
		int index = 10000;
		System.out.println(index % 4);//0
		index++;
		System.out.println(index % 4);//1
		index++;
		System.out.println(index % 4);//2
		index++;
		System.out.println(index % 4);//3
		index++;
		System.out.println(index % 4);//0
		index++;
		System.out.println(index % 4);//1
		index++;
		System.out.println(index % 4);//2
		index++;
		System.out.println(index % 4);//3
		
		
	}

}
