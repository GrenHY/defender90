package com.tarena.tetris;

public class Test01 {
	public static void main(String[] args) {
		Tetromino t = Tetromino.randomOne();
		System.out.println(t); 
	}
}
