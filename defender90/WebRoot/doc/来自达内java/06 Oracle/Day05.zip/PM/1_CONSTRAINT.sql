/*************约束**************/
/*******NOT NULL********/
--创建和移除非常简单
--修改hiredate列不允许为空
alter table emp_你名字全拼 modify(
  hiredate date not null
);
--更改hiredate为Null：失败
update "EMP_你名字全拼" set hiredate=null where id=105;
--去除hiredate列上的非空约束
--强调：null必须写！
alter table emp_你名字全拼 modify(
  hiredate date null
);
--再执行更新语句，成功

/************UNIQUE*************/
--添加一个新列
alter table emp_你名字全拼 add(  email varchar2(100) );
--设置唯一约束
alter table emp_你名字全拼 add(constraint uk_emp_email_你名字全拼 unique(email));

--同一列上的唯一约束只能有一个。冲突了怎么办？
--Step1：查看现有表中的列上是否已有相同约束
select CONSTRAINT_NAME, column_name,CONSTRAINT_TYPE，SEARCH_CONDITION 
from user_cons_columns cu join user_constraints au using(constraint_name)
where au.table_name=upper('emp_你名字全拼');
--Step2：如果有，删除：
alter table emp_你名字全拼 drop constraint SYS_C0020987 ;
--Step3：再运行修改表，添加新约束

--虽然可简写为email varchar2(100) unique，但不建议使用，因为名字自动分配，很难找
--除not null约束外的其他约束，必须采用完整方式添加
--每个约束名必须见文知意

--测试：设置所有人的邮箱相同
update "EMP_你名字全拼" set email='xxx@tarena.com.cn';
--错误：违反唯一约束条件（约束名）

/***********主外键***********/
--在id上添加主键
alter table emp_你名字全拼 add constraint pk_emp_id_你名字全拼 primary key (id);
--出错：主键与唯一约束冲突
--Step1：查询并删除唯一约束
alter table emp_你名字全拼 drop constraint SYS_C0020932;
--Step2：再添加主键

--Why 外键：
select * from "EMP_你名字全拼" where deptno is null;
update "EMP_你名字全拼" set deptno=60 where deptno is null;
--现实中，无意义。因为部门表中没有60这个部门，所有员工表中deptno=60的员工都是无效数据
--为了约束外键的内容，必须在主键范围内选择——外键约束

--创建一个从员工表的deptno，指向部门表deptno列的外键约束
alter table "EMP_你名字全拼" add constraint fk_emp_dept_你名字全拼 foreign key (deptno)
references dept_你名字全拼(deptno);
--发现创建时，验证现在deptno列中，有违反约束的60，所以不允许创建
--解决：更新60为null，再添加外键
update "EMP_你名字全拼" set deptno=null where deptno=60;
--总结：外键中的值必须在主键中可以找到，但外键允许为空。

--删除部门表中的60：
delete from "DEPT_你名字全拼" where deptno=10;
--错误：违反完整约束条件(外键名)- 已找到子记录
--强调：如果主键值，在外键表中还有对应行，则该主键值不允许删除。
--        解决：清理或转移外键表中的对应行，确保没有关联，就可以删除

--面试：画表关系图
--如何查看主外键关系图
--文件->data modeler->导入->数据字典->
--选择链接，下一步->选择用户，下一步->选择主外键两个表，下一步->点击完成
--如果关掉了，如何打开：查看->Data Modeler->浏览器->展开关系模型->在连接名上点显示
--强调：P和F必须标，箭头必须有，外键表，指向主键表。

--主外键总结：
--主外键数据类型、长度必须一致！
--主键列名和外键列名可以不一致，但强烈建议一致！

/*************CHECK*************/
alter table emp_你名字全拼 add(
  CONSTRAINT ck_emp_sal_你名字全拼 CHECK (salary > 2000)
);
select salary from emp_你名字全拼;
--发现空置不验证！要验证，和not null配合使用
--修改一个员工的薪资为1500
update "EMP_你名字全拼" set salary=1500 where id=105;
--出错：违反检查约束条件(约束名)

--补充：CHECK与正则表达式
--验证性别只能是F或M
alter table emp_你名字全拼 add(
  constraint ck_emp_gender check(regexp_like(gender,'F|M'))
);
--尝试更新gender为a试试？

--验证身份证号：18位数字，或17位数字+x
alter table emp_你名字全拼 add(
  constraint ck_emp_pid check(regexp_like(pid,'^\d{18}|(\d{17}x)$'))
);

--添加一列座机：
--因为有-，不能用number；因为长度不一定，所以用varchar2
alter table emp_你名字全拼 add(
  telephone varchar2(13),
  constraint ck_emp_tel_你名字全拼 check(regexp_like(telephone,'\d{3,4}-\d{8}'))
);
