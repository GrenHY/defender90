/************视图**************/
--创建视图
CREATE OR REPLACE VIEW v_emp_10_你名字全拼
AS
SELECT id 员工编号 , name 姓名, salary 工资, deptno 部门编号 FROM emp_你名字全拼 WHERE deptno = 10
with read only;
--查看视图列名
desc v_emp_10_你名字全拼;
--查询视图——必须使用视图中的列名
SELECT 员工编号, 姓名, 工资 FROM v_emp_10_你名字全拼;

--插入数据
INSERT INTO v_emp_10_你名字全拼  VALUES(1236, 'DOCTOR', 4000, 10);
--不允许插入：
INSERT INTO v_emp_10_你名字全拼  VALUES(1235, 'JOHN', 4000, 20);
--删除示例数据
delete from "EMP_你名字全拼" where id>1200;commit;

/*************常用视图***************/
select object_name, object_type from user_objects;
select table_name from user_tables;
select view_name, text,read_only from user_views;
SELECT column_name, insertable, updatable, deletable FROM user_updatable_columns 
WHERE table_name = upper('v_emp_salary_你名字全拼');

/*************复杂视图**************/
create or replace view  v_emp_salary_你名字全拼
AS
SELECT d.dname, e.name,e.salary
FROM emp_你名字全拼 e join dept_你名字全拼 d
using(deptno);
--再查看哪些列可以更新

--向视图插入一行数据
insert into v_emp_salary_你名字全拼 (name,salary) values('张三',7000);

drop view v_emp_10 purge;
