﻿/**********INDEX***********/
--创建单列索引
CREATE INDEX idx_emp_name_你名字全拼 ON emp_你名字全拼(name);
--创建多列索引
CREATE INDEX idx_emp_job_sal_ ON emp_你名字全拼(job,salary);
--不走索引的查询
select * from "EMP_你名字全拼" where deptno=10;
--走索引的查询
select * from "EMP_你名字全拼" where job=upper('programmer');
--唯一和主键约束的列，自动创建索引
select * from "EMP_你名字全拼" where id=1001;