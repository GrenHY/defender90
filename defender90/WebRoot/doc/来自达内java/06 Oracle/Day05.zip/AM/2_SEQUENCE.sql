/**********序列************/
--Step1：创建一个100开始，每次递增1的序列
drop sequence emp_seq_你名字全拼;
create sequence emp_seq_你名字全拼
    START WITH 100
    INCREMENT BY 1;    
--Step2：从序列中取一个值，不管是什么
select emp_seq_你名字全拼.nextval from dual;
--再执行呢？
--每nextval一次，就增加1，不可逆，永不重复
--Step3：查看现在序列到几了？
select emp_seq_你名字全拼.currval from dual;
--再执行？
--currval，仅取值，不会前进。

--Step4：向表中连续插入5行，查询出来，看id值
insert into emp_你名字全拼 (id, name) values(emp_seq_你名字全拼.nextval, 'emp1');
insert into emp_你名字全拼 (id, name) values(emp_seq_你名字全拼.nextval, 'emp2');
insert into emp_你名字全拼 (id, name) values(emp_seq_你名字全拼.nextval, 'emp3');
insert into emp_你名字全拼 (id, name) values(emp_seq_你名字全拼.nextval, 'emp4');
insert into emp_你名字全拼 (id, name) values(emp_seq_你名字全拼.nextval, 'emp5');
select id,name from emp_你名字全拼 where name like 'emp%';

    

