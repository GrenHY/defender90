/*******GROUP BY*******/
--Step1:查询个部门分别有多少人
select deptno,count(*) from "MYEMP_你名字全拼"
group by deptno;
--强调：聚合函数不能与不参与聚合的列混用。但可以与group by中的列混用。
--     换句话说：要想和聚合函数同时显示的列，必须出现在group by中。
--Step2:每个部门的平均工资是：
select deptno,sum(salary),count(*),avg(nvl(salary,0)) from "MYEMP_你名字全拼"
group by deptno;

/*******HAVING*********/
--查询平均工资5000以上的部门
select deptno,avg(nvl(salary,0)) from "MYEMP_你名字全拼"
group by deptno having avg(nvl(salary,0))>5000;