﻿select dname,loc,deptno from "DEPT_你名字全拼" order by deptno;
select deptno,id,name,job from "MYEMP_你名字全拼" order by deptno;
/*********OLD 了解***********/
--Step1:先笛卡尔积
select dname,d.deptno,e.deptno,name from "MYEMP_你名字全拼" e,"DEPT_你名字全拼" d
--Step2:筛选主外键值相等的行
where d.deptno=e.deptno;
--Step3:去掉重复列
/**********JOIN************/
select dname,e.deptno,name 
from "MYEMP_你名字全拼" e join "DEPT_你名字全拼" d on e.deptno=d.deptno;
--简写：
select dname,deptno,name 
from "MYEMP_你名字全拼" e join "DEPT_你名字全拼" d using(deptno);

/*********outer join***********/
--查询所有员工,关联部门信息
select name,job,dname,deptno
from "MYEMP_你名字全拼" e left join "DEPT_你名字全拼" d using(deptno);
--交换join左右两个表，left改为right，效果一样
--希望哪个表数据全部显示，哪个表就是驱动表
--left/right永远指向驱动表
--查询所有部门，员工信息，包括没有部门的员工和没有员工的部门
select name,job,dname,deptno
from "DEPT_你名字全拼" d full join "MYEMP_你名字全拼" e using(deptno);

--相查所有没有部门的员工和所有没有员工的部门
select id,name,deptno,dname from emp_ full join dept_ using(deptno)
where deptno is null or id is null;

/**********自连接**********/
--查询部门10的员工上下级关系
select e.id 员工id,e.name 员工姓名,e.manager 上级id,m.NAME 上级姓名,e.deptno 部门
from "MYEMP_你名字全拼" e 
  left join "MYEMP_你名字全拼" m on e.MANAGER = m.id
where e.DEPTNO=10;
--强调：自连接时，尽量使用外连接。因为自连接很有可能出现顶级对象没有对应行的情况