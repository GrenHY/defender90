/*****Where字句*****/
--查询部门10下的所有员工
SELECT name,deptno FROM myemp_你名字全拼 WHERE deptno = 10;
--查询所有岗位为程序员的员工
SELECT name, salary, job FROM myemp_你名字全拼 WHERE job = 'PROGRAMMER';
--查询薪资小于5000的小程序员们
SELECT name, trim(to_char(salary,'L99,999.99')) FROM myemp_你名字全拼	WHERE salary < 5000;
--查询除部门10外的其他部门员工
SELECT name, salary, deptno,job FROM myemp_你名字全拼 WHERE deptno != 10;
--查询2002年以后入职的员工
SELECT name, salary, hireday FROM myemp_你名字全拼 WHERE hireday > to_date('2002-1-1','YYYY-MM-DD');
--简写：
SELECT name, salary, hireday FROM myemp_你名字全拼 WHERE Extract(year from hireday) >= 2002;

/*********And Or***********/
--查询工资5000以上的程序员（含5000）
SELECT name, salary, job FROM myemp_你名字全拼 WHERE salary >= 5000 AND job = 'PROGRAMMER';
--查询工资5000以上的员工以及以及岗位是程序员的员工
SELECT name, salary, job FROM myemp_你名字全拼 WHERE salary >= 5000 or job = 'PROGRAMMER';

/**********LIKE***********/
--查询所有省会城市的员工
select name,pid from myemp_你名字全拼 where pid like '__01%';
--查询北京地区的员工
select name,pid from myemp_你名字全拼 where pid like '11%';
--查询1988年2月出生的员工
select name,pid from "MYEMP_你名字全拼" where pid like '%198802%';

/******IN and NOT IN*******/
SELECT name, job FROM "MYEMP_你名字全拼"  WHERE job IN ('MANAGER', 'CLERK');
SELECT name, job FROM "MYEMP_你名字全拼" WHERE deptno NOT IN (10, 20);

/*******Between and********/
SELECT name, salary FROM "MYEMP_你名字全拼"  WHERE salary BETWEEN 4000 AND 6000;
select name,hireday from "MYEMP_你名字全拼" WHERE hireday BETWEEN add_months(sysdate,-60) AND sysdate;

/*******Any All********/
--10部门的经理说，我们部门有人的薪资可以秒杀你们部门的所有人
--Step1：先查所有部门20的人的工资：
select salary from myemp_你名字全拼 where deptno=20;
--Step2：再差所有部门10的人的工资
select name,salary from myemp_你名字全拼 where deptno=10;
--Step3：将Step1的查询结果，作为Step2查询的新条件
select name,salary from myemp_你名字全拼 
where deptno=10 and salary>all(
    select salary from myemp_你名字全拼 where deptno=20
);
--20部门的经理说，你们部门也有一个吊丝，我们部门所有人都比他高！
--Step4：将>all改为<all：
select name,salary from myemp_你名字全拼 
where deptno=10 and salary<all(
    select salary from myemp_你名字全拼 where deptno=20
);
--强调：这里不能使用<any，因为<any只要<任意一个即可，不必小于所有。

/*********DISTINCT***********/
--查询所有员工的姓名，岗位，去重复
select distinct name,job from "MYEMP_你名字全拼";
--对吗？
select distinct id,name,job,hireday from "MYEMP_你名字全拼";
--强调：只有每列都相同的两行才会合并。有任意一列不相同，都不会合并