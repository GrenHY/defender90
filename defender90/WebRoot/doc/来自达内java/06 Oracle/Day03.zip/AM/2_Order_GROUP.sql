/******Order by******/
--Step1：查询职员表中，有绩效的员工姓名、薪资和绩效，并按工资倒序排列
select name, salary, comm From myemp_你名字全拼 where comm is not null
order by  salary desc;
--Step2：查询工资大于3000的员工信息，结果按入职时间排列，早入职排在前面，晚入职排在后面。
select name,  salary, hireday from myemp_你名字全拼 where  salary > 3000 order by hireday;

/*******聚合*******/
/****MAX MIN****/
SELECT max(salary)  max_sal, min(salary)  min_sal, max(hireday) max_hire, min(hireday) min_hire
FROM myemp_你名字全拼;
/*******AVG SUM*******/
--所有员工的平均绩效
SELECT AVG(comm)   avg_comm, SUM(comm)   sum_comm  FROM myemp_你名字全拼;
--对吗？把Null换成0，再试
select avg(nvl(comm,0)) avg_comm, SUM(nvl(comm,0))   sum_comm  FROM myemp_你名字全拼;
--现象：sum不受影响，因为null忽略就忽略了，不参与求和。
-- 但avg变小了，说明原来值为null的行未参与平均计算。
--结论：avg计算时，需要用0替换null，才是真正所有行的平均
/*******COUNT********/
--员工总数
select count(*) FROM myemp_你名字全拼;
--有绩效的员工总数
select count(comm) from myemp_你名字全拼;
--相当于：
select count(*) FROM myemp_你名字全拼 where comm is not null;
--这里虽然无所谓对错，但还是要考虑空值的影响。
