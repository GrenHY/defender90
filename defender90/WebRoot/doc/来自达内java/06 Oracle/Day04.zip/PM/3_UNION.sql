/***********UNION INTERSECT**************/
--查询所有程序员，以及工资6000以上的员工
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE job = 'PROGRAMMER'
UNION ALL
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE salary > 6000;
--有重复：
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE job = 'PROGRAMMER'
UNION
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE salary > 6000;
--发现按首列排序
--找到既是程序员，工资又高于6000的员工
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE job = 'PROGRAMMER'
intersect
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE salary > 6000;
--找到工资高于6000的员工中，不是程序员的
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE salary > 6000
minus
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE job = 'PROGRAMMER';
--如果颠倒呢？
--找到工资不高于6000的程序员
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE job = 'PROGRAMMER'
minus
SELECT id,name, job, salary FROM emp_你名字全拼 WHERE salary > 6000;



