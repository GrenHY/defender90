/*******排序函数*******/
/*****简化分页*******/
--Step1:先排序，再发号
SELECT row_number() over(order by salary desc) 行号,id, name, salary 
FROM "EMP_你名字全拼";
--Step2:用父查询做分页
select * from(
SELECT row_number() over(order by salary desc) 行号,id, name, salary 
FROM "EMP_你名字全拼")
where 行号 between 4 and 6;

/*******组内排序排号********/
--各部门内按入职时间排名
SELECT deptno, id,name, hiredate,
    ROW_NUMBER() OVER (PARTITION BY deptno ORDER BY hiredate) 部门内排名
FROM "EMP_你名字全拼"
where deptno is not null;
--此时李四和scott会产生矛盾，入职时间一样，排名却一前一后
--如何解决？
/***********RANK***********/
SELECT deptno, id,name, hiredate,
    rank() OVER (PARTITION BY deptno ORDER BY hiredate) 部门内排名
FROM "EMP_你名字全拼"
where deptno is not null;
--假设公司只给每个部门安排了2套房，不可能有第三套
--公司又追加政策，同一天入职的，按年龄大小排名
SELECT deptno, id,name, hiredate,birth,
    rank() OVER (PARTITION BY deptno ORDER BY hiredate,birth) 部门内排名
FROM "EMP_你名字全拼"
where deptno is not null;
--公司房子还有富余，为了照顾大多数人，让计算机按排名划线。每部门编号<=3的都可以分房
--rose看了榜单，也有一件了！如果按照顺序编号，2完了应该是3。那么rose就业应有一套房
/********DENSE_RANK*******/
select * from(
SELECT deptno, id,name, hiredate,
    dense_rank() OVER (PARTITION BY deptno ORDER BY hiredate) 部门内排名
FROM "EMP_你名字全拼"
where deptno is not null) where 部门内排名<=3;