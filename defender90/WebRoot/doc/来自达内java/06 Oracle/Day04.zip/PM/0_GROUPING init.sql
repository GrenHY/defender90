﻿/***********高级分组统计初始化数据*************/
/************准备存储过程****************/
--使用orale的存储过程实现table的drop if exists的效果
create or replace procedure proc_dropifexists(p_table in varchar2) 
	is v_count number(10);   
begin   
   select count(*)   
   into v_count   
   from user_tables 
   where table_name = upper(p_table);
   if v_count > 0 then   
      execute immediate 'drop table ' || p_table ||' cascade constraint PURGE'; 
   end if;   
end proc_dropifexists;
/
/*********建表***********/
exec proc_dropifexists('sales_你名字全拼');
CREATE TABLE sales_你名字全拼 (
  year   NUMBER NOT NULL,
  month   NUMBER NOT NULL,
  day   NUMBER NOT NULL,
  value NUMBER(10,2) NOT NULL
);
/***********初始化数据*************/
INSERT INTO sales_你名字全拼
SELECT TRUNC(DBMS_RANDOM.value(2010, 2012)) AS year,
       TRUNC(DBMS_RANDOM.value(1, 13)) AS month,
       TRUNC(DBMS_RANDOM.value(1, 32)) AS day,
       ROUND(DBMS_RANDOM.value(1, 100), 2) AS value
FROM   dual
CONNECT BY level <= 1000;
commit;
