/*******UNION ALL********/
--Step1：查询部门10的员工的工资明细
select id,name,salary from "EMP_你名字全拼" where deptno=10;
--Step2：查询部门10员工工资总和
select sum(salary) from "EMP_你名字全拼" where deptno=10 group by deptno;
--Step3：将两个结果罗列起来
select id,name,salary from "EMP_你名字全拼" where deptno=10
union all
select null,null,sum(salary) from "EMP_你名字全拼" where deptno=10 group by deptno;
--Step4：试着拼接部门20，并计算总计：
select id,name,salary from "EMP_你名字全拼" where deptno=10
union all
select null,'部门10工资小计：',sum(salary) from "EMP_你名字全拼" where deptno=10 group by deptno
union all
select id,name,salary from "EMP_你名字全拼" where deptno=20
union all
select null,'部门20工资小计：',sum(salary) from "EMP_你名字全拼" where deptno=20 group by deptno
union all
select null,'两部门工资总计：',sum(salary) from "EMP_你名字全拼" where deptno=20 or deptno=10;

/*********执行0_GROUPING init.sql**********/
/************复习**************/
--查询总销售额
SELECT SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼;
--查询每年总销售额
SELECT year_id, COUNT(*) AS num_rows,SUM(sales_value) AS sales_value
FROM sales_tab_你名字全拼 GROUP BY year_id ORDER BY year_id;
--查询，每年，每月的销售额
SELECT year_id, month_id,COUNT(*) AS num_rows,SUM(sales_value) AS sales_value
FROM sales_tab_你名字全拼 GROUP BY year_id, month_id ORDER BY year_id, month_id;

/*********增加小计和总计*********/
--Step1：增加每年小计：
SELECT year_id, month_id,COUNT(*) AS num_rows,SUM(sales_value) AS sales_value
FROM sales_tab_你名字全拼 GROUP BY year_id, rollup(month_id) ORDER BY year_id, month_id;
--Step2：继续增加总计：
SELECT year_id, month_id,COUNT(*) AS num_rows,SUM(sales_value) AS sales_value
FROM sales_tab_你名字全拼 GROUP BY rollup(year_id, month_id) ORDER BY year_id, month_id;

--Step3：增加每天销售量
SELECT year_id, month_id,day_id,COUNT(*) AS num_rows,SUM(sales_value) AS sales_value
FROM sales_tab_你名字全拼 GROUP BY rollup(year_id, month_id,day_id) ORDER BY year_id, month_id;

/**********CUBE************/
--二维统计
SELECT year_id, month_id, SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼
GROUP BY CUBE (year_id, month_id) ORDER BY year_id, month_id;
--三维统计
SELECT year_id, month_id, day_id,SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼
where month_id in (1,2) and day_id in (1,2)
GROUP BY CUBE (year_id, month_id,day_id) ORDER BY year_id, month_id;

/***********GROUPING SET***********/
SELECT year_id, month_id, SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼
GROUP BY GROUPING SETS (year_id, month_id) ORDER BY 1, 2;

SELECT year_id, month_id, day_id,SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼
where month_id in (1,2) and day_id in (1,2)
GROUP BY GROUPING SETS (year_id, month_id,day_id) ORDER BY year_id, month_id;

SELECT year_id, month_id, day_id,SUM(sales_value) AS sales_value FROM sales_tab_你名字全拼
where month_id in (1,2) and day_id in (1,2)
GROUP BY GROUPING SETS (year_id, (month_id,day_id)) ORDER BY year_id, month_id;