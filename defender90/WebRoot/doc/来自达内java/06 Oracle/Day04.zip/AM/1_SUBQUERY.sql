/**********in WHERE***********/
--查询和scott同职位的员工
--Step1:先查询不确定的：Scott的员工的职位
SELECT job FROM emp_你名字全拼 WHERE upper(name) = 'SCOTT';
--Step2:再查询全体员工信息
SELECT name, job FROM emp_你名字全拼;
--Step3:将Step1中得到的结果，作为Step2的比较条件
--Step2的SQL
--WHERE job=(Step1的SQL);
SELECT name, job FROM emp_你名字全拼
WHERE job=(SELECT job FROM emp_你名字全拼 WHERE upper(name) = 'SCOTT');
--出错，因为等于、大于、小于后的子查询，只能返回1个值
--改为按id查,编号1005(Scott)这个员工的岗位
SELECT id, name, job, deptno FROM emp_你名字全拼
WHERE job=(SELECT job FROM emp_你名字全拼 WHERE id=1005);

--查询高于公司平均工资的员工
--Step1:先查不确定的：平均工资
--Step2：再查全体员工信息
--Step3：拼接父子查询
SELECT deptno, name, salary FROM emp_你名字全拼
WHERE salary > (SELECT AVG(nvl(salary,0)) FROM emp_你名字全拼);

--查询出部门中有SALESMAN但职位不是SALESMAN的员工的信息：
--Step1：先查不确定的：哪些部门有销售人员？
SELECT deptno FROM emp_你名字全拼 WHERE job = 'SALESMAN';
--Step2：查询所有非销售人员
SELECT id, name, job, deptno
FROM emp_你名字全拼 where job != 'SALESMAN';
--Step3：将Step1的结果作为Step2的筛选条件之一。
--强调：因为Step1查询返回值，所以需要使用in
--Step2SQL and deptno in (step2SQL)
SELECT id, name, job, deptno FROM emp_你名字全拼 where job!='SALESMAN' 
and deptno in (SELECT deptno FROM emp_你名字全拼 WHERE job='SALESMAN');

--查询有员工的部门信息
--Step1:查询任意一个部门(如部门10)的员工
select id,name from "EMP_你名字全拼" where deptno=10;
--Step2:查询所有部门信息
select deptno,dname from "DEPT_你名字全拼";
--Step3:让Step1在Step2的结果中每一行都查询一次，判断每个部门是否包含员工
select deptno,dname from "DEPT_你名字全拼" d
where exists(select id,name from "EMP_你名字全拼" e where e.deptno=d.deptno);
--强调：exists会在表dept中的每一行之行exists判断。
--     子查询要使用父查询的列时，用别名区分。
--Extends:有没有其它办法？
select deptno,dname from "DEPT_你名字全拼" d
where deptno in (select distinct deptno from "EMP_你名字全拼");

/*******in HAVING********/
--查询列出最低薪水高于部门20的最低薪水的部门
--Step1:查询部门20的最低工资
SELECT MIN(salary) FROM "EMP_你名字全拼" WHERE deptno=20;
--Step2:查询每个部门的最低工资，排除部门20;
SELECT deptno, MIN(salary) min_sal FROM "EMP_你名字全拼"
where deptno!=20 GROUP BY deptno;
--Step3:将Step1的查询作为Step2查询的条件。
--因为有聚合函数，所以必须用HAVING
--Step2SQL having min(salary)>(Step1SQL)
SELECT deptno, dname,MIN(salary) min_sal FROM "EMP_你名字全拼"
where deptno!=20 GROUP BY deptno
having min(salary)>(SELECT MIN(salary) FROM "EMP_你名字全拼" WHERE deptno=20);
--按照原则，先筛选再聚合，性能更高

/*******in FROM*******/
--查询出薪水比本部门平均薪水高的员工信息
--Step1:所有部门平均薪水(没有部门的员工不参与统计)
SELECT deptno, AVG(nvl(salary,0)) avg_sal FROM "EMP_你名字全拼"
where deptno is not null GROUP BY deptno ;
--Step2：查询所有员工的薪水
SELECT id,name, salary,deptno FROM "EMP_你名字全拼";
--Step3：按部门编号，内连接两个表（可以去空值），起别名
SELECT id,name, salary,deptno,avg_sal
FROM "EMP_你名字全拼" e join (
    SELECT deptno, AVG(nvl(salary,0)) avg_sal FROM "EMP_你名字全拼"
    where deptno is not null GROUP BY deptno) x using(deptno)
--Step4：添加where筛选条件
where salary>avg_sal;
--说明：这里没有发生两个表列名冲突，所以不起别名也行。

/**********in SELECT**********/
--查询员工信息同时，补充显示部门名称
--强调:可能发生列名冲突，需要对父子查询的表均其别名
SELECT name, salary,
  (SELECT d.dname FROM "DEPT_你名字全拼" d 
   WHERE d.deptno = e.deptno) dname
FROM "EMP_你名字全拼" e;
--相当于，外连接查询！不等于内连接！
SELECT name, salary,dname
FROM "EMP_你名字全拼" e 
  left join "DEPT_你名字全拼" d using(deptno);
