/********DECODE********/
--查询员工信息，显示男女
select id,name,decode(gender,--判断gender的值
                      'F','女',--如果是F，则显示女
                      '男')--默认显示男
from "EMP_你名字全拼";
--根据职员的职位计算奖励金额
SELECT name, job, salary,DECODE(job, 
                                'MANAGER',salary*1.2,
                                'ANALYST',salary * 1.1,
                                'SALESMAN',salary * 1.05,
                                salary
                                ) bonus
FROM "EMP_你名字全拼";

/********CASE WHEN**********/
--标准写法：
SELECT name, job, salary,case when job='MANAGER' then salary*1.2 
                              when job='ANALYST' then salary * 1.1
                              when job='SALESMAN' then salary * 1.05
                              else salary
                         end bonus
FROM "EMP_你名字全拼";
--当都是等于判断时，可简写为：
SELECT name, job, salary,case job when 'MANAGER' then salary*1.2 
                              when 'ANALYST' then salary * 1.1
                              when 'SALESMAN' then salary * 1.05
                              else salary
                         end bonus
FROM "EMP_你名字全拼";
--强调：简写方法只能做等于比较。规范写法更灵活，可以将等号改为任意比较运算符

--加练：等级划分：
SELECT name, salary,case when salary>=6000 then '土豪' 
                         when salary<4000 then '吊丝'
                         else '一般人'
                    end class
FROM "EMP_你名字全拼";

/*********分组中的CASE*********/
--统计6000以上的多少人，6000到4000的多少人，4000以下的多少人
--Step1:增加不存在的分组列
select name,case when salary>=6000 then '6000以上'
              when salary<4000 then '4000以下'
              else '4000到6000'
         end 分组 
from "EMP_你名字全拼";
--Step2:按自定义的分组列值分组
--去掉不参与统计的列name，添加聚合函数count(*)
--因为group by比select先执行，所以给列起别名，也用不上。只能再把分组列抄一遍。
select case when salary>=6000 then '6000以上'
              when salary<4000 then '4000以下'
              else '4000到6000'
         end 分组, count(*)人数 
from "EMP_你名字全拼"
group by case when salary>=6000 then '6000以上'
              when salary<4000 then '4000以下'
              else '4000到6000'
         end;
--那么长的判断要重复写两遍？
--step3:利用子查询，简化查询代码
--子查询只做判断，外层做分组统计
select 分组,count(*) 人数 from(
select case when salary>=6000 then '6000以上'
              when salary<4000 then '4000以下'
              else '4000到6000'
         end 分组 
from "EMP_你名字全拼")
group by 分组;

/******排序中的DECODE*******/
--Dept表中按”OPERATIONS”、“ACCOUNTING”、“SALES”排序
--无法按照字面数据排序
SELECT deptno, dname, loc
FROM "DEPT_你名字全拼"
ORDER BY DECODE(dname, 'OPERATIONS',1,'ACCOUNTING',2,'SALES',3);

