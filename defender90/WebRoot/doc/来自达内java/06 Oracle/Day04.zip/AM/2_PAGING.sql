/*******Paging********/
/******ROWNUM******/
--Step1：显示行号
SELECT ROWNUM, id, name, salary FROM "EMP_你名字全拼";

/******分页******/
--Step2：第一页,取前三行
SELECT ROWNUM, id, name, salary FROM "EMP_你名字全拼" where rownum<=3;
--Step3：第二页,取3-6行
SELECT ROWNUM, id, name, salary FROM "EMP_你名字全拼" 
where rownum>3 and rownum<=6;
--现象：不会出错，但没有值！
--Why：因为这个逻辑，最终只会得到3行，但rownum是查询后才发号
--so：无论如何也发布到3以上的号
--结论：rownum所在的查询不支持rownum>比较，只支持小于比较
--解决:父子查询:让子查询先领到号,然后父查询再对已领到的号做>比较！
--Step4：先拿到6以前的所有号,起别名
--必须起别名,起了别名,rownum在父级查询中才能看作是普通列
SELECT ROWNUM 行号, id, name, salary FROM "EMP_你名字全拼" 
where rownum<=6;
--step5：用父查询包裹子查询，父查询中用“行号”列判断>3的判断
select *
from (SELECT ROWNUM 行号, id, name, salary FROM "EMP_你名字全拼" 
where rownum<=6)
where 行号>3;

/*******分页+排序********/
--Step0：发号，并按薪资降序排列
SELECT ROWNUM 行号, id, name, salary FROM "EMP_你名字全拼" order by salary desc;
--现象：发号顺序错乱，必然影响后续的分页
--Why：同一查询中的Order by永远最后执行，也就是先了号，再排序！
--解决：先排序再发号，只能靠子查询，因为子查询总是比父查询先执行！
--Step1:先排序,不发号
SELECT id, name, salary FROM "EMP_你名字全拼" order by salary desc;
--Step2：在父查询中再发号
select rownum 行号,e.*
from (SELECT id, name, salary FROM "EMP_你名字全拼" order by salary desc) e;
--Step3：再包裹一级父查询做分页
select * from
(select rownum 行号,e.*
from (SELECT id, name, salary FROM "EMP_你名字全拼" order by salary desc) e
where rownum<=6)
where 行号>3;

