/*****Concat and ||*****/
--Step1：只查询姓名和工资两列
select name,salary from "MYEMP_你名字全拼";
--Step2：按字符串拼接每一行的姓名和工资
select concat(name,salary) from "MYEMP_你名字全拼";
--问题：想再拼接分隔符或更多字符，concat无能为力
--Step3：Oracle中||拼接字符更灵活！
select name||':'||salary from "MYEMP_你名字全拼";

/*****length and lengthb******/
--Step1：示例数据
insert into "MYEMP_你名字全拼" (id,name) values(1004,'马里奥');
commit;
--Step2：同时查询字符个数和字节数
select name, length(name),lengthb(name) from "MYEMP_你名字全拼";

/*****UPPER LOWER INITCAP******/
--Step1：使用dual
--说明：dual，空表，不用创建就有。专门用于程序调试和打印输出的一个特殊表。只能select，不能DML
select 'Welcome to dual' from dual;
--Step2：使用dual测试大小写转换函数
SELECT UPPER('hello world'), LOWER('HELLO WORLD'), INITCAP('hello world') FROM DUAL;
--Step3：如果我想注册一个新员工，姓名为Rose，行不行？
--Step3.1：使用Where条件
--  when:不是每次都把表的所有行通篇查询出来。客户总要按条件筛选感兴趣的。
--  如：查询现在是否有叫rose的员工？
select * from "MYEMP_你名字全拼" where name='rose';
--问题：如果使用Rose，却查不出来
--原因：字符串本身比较时，区分大小写，而现实中要求rose和Rose是重名的！
select * from "MYEMP_你名字全拼" where name='Rose';
--解决：查询时，就将条件统一转换为大写或小写再比较！
select * from "MYEMP_你名字全拼" where upper(name)=upper('Rose');

/******SUBSTR*******/
--Step0：示例数据
alter table myemp_你名字全拼 add(pid char(18));
update "MYEMP_你名字全拼" set pid='130104198206291111' where id=1001;
commit;
--Step1：从身份证号取生日
select name, substr(pid,7,8) from "MYEMP_你名字全拼" where id=1001;
--Step2：从身份证号鉴别性别
select name, substr(pid,-4,3) from "MYEMP_你名字全拼" where id=1001;