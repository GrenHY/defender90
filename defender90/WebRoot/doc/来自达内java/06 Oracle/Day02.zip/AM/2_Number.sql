/******ROUND CEIL FLOOR******/
--Step0：实例数据：
alter table myemp_你名字全拼 add(hireday date default sysdate);
update "MYEMP_你名字全拼" set hireday='8-5月-14' where id=1001;
commit;
--Step1：查看1001员工入职几天？
select sysdate,hireday, sysdate-hireday from "MYEMP_你名字全拼" where id=1001;
--问题：时间竟然是一个很精确的小数，Why?
--Step2：查看完整时间格式：
--to_char(列名, 'RR-MM-DD HH24:MI:SS')
select to_char(sysdate,'RR-MM-DD HH24:MI:SS')
          ,to_char(hireday,'RR-MM-DD HH24:MI:SS')
          ,sysdate-hireday
from "MYEMP_你名字全拼" where id=1001;
--18/24=.75xxx。所以，Oracle中日期相减，是以天为单位，不足一天的小时部分/24，转为小数
--而现实中，没有人这么说话
--解决：将计算出的时间，四舍五入
select round(sysdate-hireday) from "MYEMP_你名字全拼" where id=1001;
--如果公司说，不足一天的部分，不能按一天算，差一分钟也不行！
select floor(sysdate-hireday) from "MYEMP_你名字全拼" where id=1001;

