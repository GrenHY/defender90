/************准备存储过程****************/
--使用orale的存储过程实现table的drop if exists的效果
create or replace procedure proc_dropifexists(p_table in varchar2) 
	is v_count number(10);   
begin   
   select count(*) 
   into v_count
   from user_tables 
   where table_name = upper(p_table);
   if v_count > 0 then   
      execute immediate 'drop table ' || p_table ||' cascade constraint PURGE'; 
   end if;   
end proc_dropifexists;
/
--使用orale的存储过程实现sequence的drop if exists的效果
create or replace procedure proc_dropifexists_sequence(p_sequence in varchar2) 
	is v_count number(10);   
begin   
   select count(*)   
   into v_count   
   from user_sequences 
   where sequence_name = upper(p_sequence);
   if v_count > 0 then   
      execute immediate 'drop sequence ' || p_sequence; 
   end if;   
end proc_dropifexists_sequence;
/
--使用orale的存储过程实现index的drop if exists的效果
create or replace procedure proc_dropifexists_index(p_index in varchar2) 
	is v_count number(10);   
begin   
   select count(*)   
   into v_count   
   from user_indexes 
   where index_name = upper(p_index);
   if v_count > 0 then   
      execute immediate 'drop index ' || p_index; 
   end if;   
end proc_dropifexists_index;
/
/************emp_你名字全拼************/
exec proc_dropifexists('emp_你名字全拼');
exec proc_dropifexists('emp_你名字全拼');
CREATE TABLE emp_你名字全拼(
	id NUMBER(4) unique not null,
	name VARCHAR2(20)  NOT NULL,
	gender CHAR(1) DEFAULT 'M',
	birth DATE,
  hiredate DATE DEFAULT sysdate,
 salary NUMBER(7,2),
 comm NUMBER(7,2),
 job VARCHAR2(40) DEFAULT 'CLERK',
 pid char(18),
 manager NUMBER(4),
 deptno NUMBER(2),
 rest char(5)
);
INSERT INTO emp_你名字全拼 (id, name, job, salary) VALUES(1001, 'rose', 'PROGRAMMER', 5500);
INSERT INTO emp_你名字全拼 (id, name, job,birth) VALUES(1002, 'martha', 'ANALYST', '01-9月-89');
INSERT INTO emp_你名字全拼 (id, name, job, birth) VALUES(1003, 'donna', 'MANAGER', TO_DATE('1978-09-01', 'YYYY-MM-DD'));
insert into emp_你名字全拼 (id,name) values(1004,'马里奥');
DELETE FROM emp_你名字全拼 WHERE job is null;
update emp_你名字全拼 set pid='130104198206291111' where id=1001;
update emp_你名字全拼 set hiredate=sysdate where id=1001;
update emp_你名字全拼 set hiredate=to_date('00-3-27','rr-mm-dd') where id=1002;
update emp_你名字全拼 set hiredate=to_date('01-3-27','rr-mm-dd') where id=1003;
update emp_你名字全拼 set hiredate=to_date('02-3-27','rr-mm-dd') where id=1004;
update emp_你名字全拼 set rest='12:20' where id=1001;
update emp_你名字全拼 set comm=null where id=1003 or id=1004;
UPDATE emp_你名字全拼 SET salary = 8500 WHERE name = 'rose';
UPDATE emp_你名字全拼 SET salary = 6500, job = 'ANALYST' WHERE id = 1003;
update emp_你名字全拼 set deptno=10 where id=1001 or id=1002;
update emp_你名字全拼 set salary=6500 where id=1001;
update emp_你名字全拼 set salary=3500,pid='110105198802211121' where id=1002;
update emp_你名字全拼 set deptno=11,hiredate='10-5月-05',gender='F' where id=1003;
update emp_你名字全拼 set deptno=20, salary=4000,hiredate='25-6月-10',pid='110107199002211131' where id=1004;
delete from emp_你名字全拼 where id=1005;
insert into emp_你名字全拼(id,name,salary,comm,job,deptno,hiredate)
values(1005,'scott',4500,2500,'SALESMAN',20,'21-10月-11');
delete from emp_你名字全拼 where id=1006;
insert into emp_你名字全拼(id,name,salary,comm,job,deptno,hiredate,birth)
values(1006,'scott',4200,1000,'SALESMAN',10,'11-11月-12','20-7月-79');
update emp_你名字全拼 set manager=1006,gender='F' where id=1002;
update emp_你名字全拼 set manager=1001 where id=1006;
update emp_你名字全拼 set manager=1005 where id=1004;
insert into emp_你名字全拼 (id,name,birth,hiredate,salary,job)
values (1007,'eric','26-12月-83','27-3月-02',2500,'CLERK');
insert into emp_你名字全拼 (id,name,birth,hiredate,salary,job,deptno)
values (1008,'李四','10-2月-85','11-11月-12',4500,'PROGRAMMER',10);
insert into emp_你名字全拼 (id,name,birth,hiredate,salary,job,deptno)
values (1009,'王五','11-5月-80','11-11月-12',6000,'MANAGER',20);
commit;
select * from emp_你名字全拼;
/******dept_你名字全拼*******/
exec proc_dropifexists('dept_你名字全拼');
create table dept_你名字全拼(
  deptno number(4) unique not null,
  dname nvarchar2(20) not null,
  loc nvarchar2(20) not null
);
insert into dept_你名字全拼 values(10,'RESEARCH','DALLAS');
insert into dept_你名字全拼 values(11,'ACCOUNTING','NEW YORK');
insert into dept_你名字全拼 values(20,'SALES','CHICAGO');
insert into dept_你名字全拼 values(51,'OPERATIONS','BOSTON');
commit;
select * from dept_你名字全拼;