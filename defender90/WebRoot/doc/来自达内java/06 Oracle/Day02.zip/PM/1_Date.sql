select name,hireday from "MYEMP_你名字全拼";
/*******to_date*******/
--Step0：示例数据：
update "MYEMP_你名字全拼" set hireday=to_date('00-3-27','rr-mm-dd') where id=1002;
update "MYEMP_你名字全拼" set hireday=to_date('01-3-27','rr-mm-dd') where id=1003;
update "MYEMP_你名字全拼" set hireday=to_date('02-3-27','rr-mm-dd') where id=1004;
commit;
--Step1：查询02年1月1日后入职的员工
SELECT name, hireday from "MYEMP_你名字全拼"  
WHERE hireday >TO_DATE('2002-01-01',  'YYYY-MM-DD');

/******to_char******/
--Step1：查询结果
--Step2：为列起别名：select 列名 别名,...
SELECT  name, TO_CHAR(hireday, 'yyyy-mm-dd') hiredate, 
TO_CHAR(hireday, 'yyyy"年"mm"月"dd')  review 
FROM "MYEMP_你名字全拼";

/*****last_day(日期) add_months(日期,间隔)*****/
--Step1：假设，是装修公司，按天算钱。查询rose到这个月底总共工作多少天
select last_day(hireday)-hireday from "MYEMP_你名字全拼" where id=1001;
--小心：rose来找你理论！说少算了一天！
select last_day(hireday)+1-hireday from "MYEMP_你名字全拼" where id=1001;
--Step2：假设rose入职3个月转正
SELECT name, ADD_MONTHS(hireday, 3) 转正 FROM myemp_你名字全拼 where id=1001;

/*******months_between(日期1，日期2)*******/
--Step1：查询所有员工入职的月数
select name,hireday,months_between(sysdate,hireday) from "MYEMP_你名字全拼";
--Step2：四舍五入取整
select name,hireday,round(months_between(sysdate,hireday)) from "MYEMP_你名字全拼";
--Step3：计算入职年份，四舍五入
select name,hireday,round(months_between(sysdate,hireday)/12) from "MYEMP_你名字全拼";

/********Extract(单位 from 日期)*********/
SELECT EXTRACT(year FROM SYSDATE) CURRENT_YEAR 
FROM DUAL;
SELECT EXTRACT(hour FROM systimestamp) CURRENT_YEAR 
FROM DUAL;

/*******interval '整数' 单位*******/
--Why：月份加减，有函数，年份也可以用月份*12，勉强计算
--        但天，时，分，秒就没那么现成了
--看今天可以购买到哪天的火车票
select sysdate+(interval '19' day) from dual;
--可简写：日期类型可以和数字直接做加减，单位为天
select sysdate+19 from dual;
--12点20下课，午休1小时40分，看几点上课
--Step0：准备
alter table myemp_你名字全拼 add(rest char(5));
update myemp_你名字全拼 set rest='12:20' where id=1001;
commit;
--Step1：查询rose的下班时间
select name,rest from "MYEMP_你名字全拼"  where id=1001;
--Step2：计算上班时间
select name,rest,
to_char(
  to_date(rest,'HH24:MI')+interval '1' hour+interval '40' minute
  ,'HH24:MI')
from "MYEMP_你名字全拼"  where id=1001;
