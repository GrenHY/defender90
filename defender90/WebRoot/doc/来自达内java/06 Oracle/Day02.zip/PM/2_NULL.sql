/******null与Number*******/
--Step0：准备
select * from "MYEMP_你名字全拼";
update "MYEMP_你名字全拼" set comm=null where id=1003 or id=1004;
commit;
--Step1：查询姓名、工资、绩效
--Why：如果不替换，null值就可能进入将来的程序，造成异常！
--强调：实际存储的值，仍为null；空值替换函数只临时影响查询结果
SELECT name, salary, comm FROM myemp_你名字全拼;
--Step2：替换绩效列中的Null为空
SELECT name, salary, nvl(comm,0) FROM myemp_你名字全拼;
--Step3：计算每人应发合计
SELECT name, salary, nvl(comm,0),(salary+comm) total
    FROM myemp_你名字全拼;
--问题：null+number=null；不用到程序中，Oracle本身就计算出错了！
--解决：只有不为null，才相加；为null，直接=sallary
SELECT name, salary, nvl(comm,0),
    nvl2(comm, salary + comm, salary) total
    FROM myemp_你名字全拼;
--说明：null和字符列拼接（||）不受影响，会转换为空字符再串拼接。

/******null与其他类型******/
--查询姓名和生日，如果没有生日，替换为NA
--Step1：查询姓名和生日，并格式化日期
select name,to_char(birth,'RR-MM-DD') from "MYEMP_你名字全拼";
--现象：虽然to_char可以将日期格式化成字符串，但空值却依然是Null
--Step2：替换null为NA
select name,nvl(to_char(birth,'RR-MM-DD'),'NA') from "MYEMP_你名字全拼";
--强调：birth虽然是日期类型，但经过to_char转换后，查询结果中实际为字符串，则可以用NA替换
--        如果brith不to_char，则不能使用'NA'，替换，因为数据类型不一致