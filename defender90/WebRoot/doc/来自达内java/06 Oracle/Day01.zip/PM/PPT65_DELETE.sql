DELETE FROM myemp_你名字全拼 WHERE job is null;

DELETE FROM myemp_你名字全拼 WHERE name ='ROSE';

--删除完成后，检查数据
SELECT * FROM myemp_你名字全拼 WHERE name ='ROSE';
