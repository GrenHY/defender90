﻿INSERT INTO myemp_你名字全拼 (id, name, job, salary) 
VALUES(1001, 'rose', 'PROGRAMMER', 5500);

--使用默认日期格式插入记录
INSERT INTO myemp_你名字全拼 (id, name, job,birth) 
VALUES(1002, 'martha', 'ANALYST', '01-9月-89');

--使用自定义日期格式插入记录
--to_date(字符串,‘格式’)：用于按照自己习惯的格式，将字符串转换为日期或时间。
--仅临时转换，存储时，依然使用默认格式。
INSERT INTO myemp_你名字全拼 (id, name, job, birth) 
VALUES(1003, 'donna', 'MANAGER', 
TO_DATE('1978-09-01', 'YYYY-MM-DD'));
commit;
select * from myemp_你名字全拼;
