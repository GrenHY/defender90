﻿ALTER TABLE myemp_你名字全拼 ADD (hiredate DATE DEFAULT sysdate);
ALTER TABLE myemp_你名字全拼 DROP (hiredate);
ALTER TABLE myemp_你名字全拼
MODIFY(job VARCHAR2(40) DEFAULT 'CLERK' );
desc myemp_你名字全拼;

alter table myemp_你名字全拼 modify(
  salary number(7,2) default 5000,
  comm number(7,2) default 1000
);

alter table myemp_你名字全拼 add(
  qq varchar2(10),
  email varchar2(50)
);
alter table myemp_你名字全拼 drop(qq,email);