create table student2_你名字全拼(
	name varchar2(15),
  gender char,
  pid char(18),
  address varchar2(300)
);
