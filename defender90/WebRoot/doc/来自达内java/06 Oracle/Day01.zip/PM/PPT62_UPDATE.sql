UPDATE myemp_你名字全拼 SET salary = 8500 WHERE name = 'rose';

UPDATE myemp_你名字全拼 SET salary = 6500, job = 'ANALYST' 
WHERE id = 1003;

--更新完成后，检查数据
SELECT * FROM myemp_你名字全拼;

--没有Where条件！全员工资统一为15000！
UPDATE myemp_你名字全拼 SET salary = 15000;