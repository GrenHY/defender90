﻿CREATE TABLE employee_你名字全拼(
	id NUMBER(4) unique not null,
	name VARCHAR2(20)  NOT NULL,
	gender CHAR(1) DEFAULT 'M',
	birth DATE,
 salary NUMBER(6,2),
 comm NUMBER(6,2),
 job VARCHAR2(30),
 manager NUMBER(4),
 deptno NUMBER(2)
);
