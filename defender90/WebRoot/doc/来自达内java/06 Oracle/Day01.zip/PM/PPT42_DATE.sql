select sysdate from dual;
create table student3_你名字全拼(
  birthday date,
  hireday date
);