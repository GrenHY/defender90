package com.tarena.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import com.tarena.entity.Emp;
import com.tarena.util.HibernateUtil;

public class TestEmp {
	
	/**
	 * ����ID��ѯԱ��
	 */
	@Test
	public void test1() {
		//����Session
		Session session = 
			HibernateUtil.getSession();
		//ִ�в�ѯ
		Emp e = (Emp) session.get(Emp.class, 1);
		System.out.println(
			e.getId() + " " +
			e.getName() + " " +
			e.getSalary()
		);
		//�ر�Session
		session.close();
	}

}
