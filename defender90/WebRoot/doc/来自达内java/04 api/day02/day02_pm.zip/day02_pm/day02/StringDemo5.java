package day02;
/**
 * ��г����demo
 * @author Administrator
 *
 */
public class StringDemo5{
	public static void main(String[] args) {
		String regex 
			= "(wqnmlgb|cnm|dsb|rnmb|sb|db|djb)";
		String message
			= "wqnmlgb!����ô��ôsb!cnm!���dsb";
		message  
			= message.replaceAll(
					regex, "***");
		System.out.println(message);
	}
}


