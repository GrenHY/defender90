package day02;

public class ObjectDemo1 {
	public static void main(String[] args) {
		StringBuilder sb
			= new StringBuilder("helloworld");
		System.out.println(sb);
		
	}
	
	public static void println(Object o){
		;
		System.out.println();
	}
}
