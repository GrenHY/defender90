package com;

import com.pro.base.World;

public class Game {
	public static void main(String[] args) {
		World world = World.getWorld(800,400);
		world.setFps(60);
		world.start();
		
		BackGroud bg = new BackGroud();
		world.putDrawablePic(1, bg);
		
		Fish fish = new Fish();
		world.putDrawablePic(2, fish);
	}
}
