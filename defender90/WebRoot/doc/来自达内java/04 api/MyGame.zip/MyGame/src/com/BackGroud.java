package com;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.pro.base.World;
import com.pro.base.graphics.Bitmap;
import com.pro.base.graphics.Canvas;
import com.pro.base.graphics.Paint;
import com.pro.base.model.Drawable;

public class BackGroud implements Drawable{
	private Bitmap bg;
	
	public BackGroud(){
		try {
			bg = new Bitmap(ImageIO.read(new File("img/bg.jpg")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void onLoop(Canvas canvas, Paint paint, World world) {
		canvas.drawBitmap(bg, 0,0, paint);
		
	}

	@Override
	public void onPause(Canvas canvas, Paint paint, World world) {
		// TODO Auto-generated method stub
		
	}

}
