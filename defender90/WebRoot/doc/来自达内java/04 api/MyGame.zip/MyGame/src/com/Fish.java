package com;

import java.io.File;

import javax.imageio.ImageIO;

import com.pro.base.World;
import com.pro.base.graphics.Bitmap;
import com.pro.base.model.Spirit;

public class Fish extends Spirit{
	private int x =800;
	private int angle = 0;
	private Bitmap[] acts = new Bitmap[10];
	public Fish(){
		try {
			acts[0] = new Bitmap(ImageIO.read(new File("img/fish04_01.png")));
			acts[1] = new Bitmap(ImageIO.read(new File("img/fish04_02.png")));
			acts[2] = new Bitmap(ImageIO.read(new File("img/fish04_03.png")));
			acts[3] = new Bitmap(ImageIO.read(new File("img/fish04_04.png")));
			acts[4] = new Bitmap(ImageIO.read(new File("img/fish04_05.png")));
			acts[5] = new Bitmap(ImageIO.read(new File("img/fish04_06.png")));
			acts[6] = new Bitmap(ImageIO.read(new File("img/fish04_07.png")));
			acts[7] = new Bitmap(ImageIO.read(new File("img/fish04_08.png")));
			acts[8] = new Bitmap(ImageIO.read(new File("img/fish04_09.png")));
			acts[9] = new Bitmap(ImageIO.read(new File("img/fish04_10.png")));
			this.setAnimation(acts, 100);
			this.playAnimation(true);
		} catch (Exception e) {
			
		}
	}
	
	
	@Override
	public void onLoop(World world) {
		if(x<-50){
			x=850;
		}
		this.setLocal(x--, 200);
		this.setRotate(angle++, 46, 16);
		this.playAnimation(true);
		
	}

	@Override
	public void onPause(World world) {
		this.playAnimation(false);
		
	}
	

}
