package day01;
/**
 * �ַ�����ת
 * @author Administrator
 *
 */
public class StringBuilderDemo2 {
	public static void main(String[] args){
		String str = "�Ϻ�����ˮ���Ժ���";
		StringBuffer builder 
			= new StringBuffer(str);
		builder.reverse();
		String str2 = builder.toString();
		if(str.equals(str2)){
			System.out.println("yes");	
		}else{
			System.out.println("no");
		}
		
	}
}
