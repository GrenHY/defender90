package day01;

import java.util.Random;
import java.util.Scanner;

/**
 * ����ǰ�ַ����е�Ӣ�Ĳ���ת��Ϊȫ��д��ȫСд
 * String toUpperCase()
 * String toLowerCase()
 * @author Administrator
 *
 */
public class StringDemo8 {
	public static void main(String[] args) {
		String str = "�Ұ�Java";
		
		String upper = str.toUpperCase();
		System.out.println(upper);
		
		String lower = str.toLowerCase();
		System.out.println(lower);
		
//		String s = "WA38yZde";
//		System.out.println("��������֤��:"+s);
//		Scanner scanner = new Scanner(System.in);
//		String input = scanner.nextLine();
//		s = s.toLowerCase();
//		input = input.toLowerCase();
//		if(s.equals(input)){
//			System.out.println("��֤�ɹ�");
//		}else{
//			System.out.println("��֤ʧ��");
//		}
		
		Random random = new Random();
		String ran = "";
		for(int i=0;i<5;i++){
			int num = random.nextInt(3);	
			switch(num){
			case 0:
				char r = (char)(random.nextInt(26)+'a');
				ran+=r;
				break;
			case 1:
				char r1 = (char)(random.nextInt(26)+'A');
				ran+=r1;
				break;
			case 2:
				ran+=random.nextInt(10);
				break;
			}
		}
		System.out.print(ran);
	}
}
