package day01;
/**
 * ȥ���ַ������ߵĿհ�
 * String trim()
 * @author Administrator
 *
 */
public class StringDemo5 {
	public static void main(String[] args) {
		String str = "   fanchuanqi			";
		String trim = str.trim();
		System.out.println(str);
		System.out.println(trim);
		
		
		
	}
}
